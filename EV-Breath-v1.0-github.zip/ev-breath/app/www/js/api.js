// Talks to the EV Breath server. With no server set, it answers from the bundled demo snapshot.
import { DEMO } from './demo-data.js';

const K = { server: 'evb.server', token: 'evb.token' };
const store = {
  get(k) { try { return localStorage.getItem(k) || ''; } catch { return ''; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch { /* storage unavailable */ } },
};

export const cfg = {
  get server() { return store.get(K.server).replace(/\/+$/, ''); },
  get token() { return store.get(K.token); },
  save(server, token) { store.set(K.server, server.trim()); store.set(K.token, token.trim()); },
  get demo() { return !this.server; },
};

const demoDraft = { changes: {} };

function demoGet(path) {
  if (path.startsWith('/api/scanner')) {
    const u = new URL('http://x' + path); const preset = u.searchParams.get('preset') || 'breath';
    const base = DEMO[`/api/scanner?preset=${preset}`] || DEMO['/api/scanner?preset=breath'];
    const q = (u.searchParams.get('q') || '').toLowerCase();
    return q ? { ...base, rows: base.rows.filter(r => r.symbol.toLowerCase().includes(q)) } : base;
  }
  const hit = DEMO[path];
  if (hit) return hit;
  if (path.startsWith('/api/check/') || path.startsWith('/api/alert/')) throw new Error('Not in the demo market. Connect your server for any NSE/BSE stock.');
  if (path.startsWith('/api/multibagger')) return DEMO['/api/multibagger?stage=Early'];
  throw new Error('Not available in demo mode');
}

function demoPost(path, body) {
  if (path === '/api/orders') return { status: 'SIMULATED', order_no: 'DEMO-' + Date.now(), note: 'Demo mode: nothing was sent to a broker', ...body };
  if (path === '/api/rules/draft') { Object.assign(demoDraft.changes, body.changes); return { diff: demoDraft.changes }; }
  if (path === '/api/rules/reset') { demoDraft.changes = {}; return { ok: true }; }
  if (path.startsWith('/api/rules/backtest')) return DEMO.__backtest;
  if (path === '/api/rules/publish') throw new Error('Demo mode: connect your server to save rule versions');
  if (path.startsWith('/api/brokers/')) return { saved: false, note: 'Demo mode: set your server address first' };
  if (path === '/api/datasource/test') return DEMO['/api/datasource'];
  throw new Error('Not available in demo mode');
}

export async function api(path, { method = 'GET', body } = {}) {
  if (cfg.demo) return method === 'GET' ? demoGet(path) : demoPost(path, body || {});
  const res = await fetch(cfg.server + path, {
    method,
    headers: { 'Content-Type': 'application/json', 'X-App-Token': cfg.token },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Server error ${res.status}`);
  return data;
}

// Live stream (server-sent events): ticks, alerts, feed changes, score refreshes.
let es = null;
export function connectStream(handlers) {
  if (cfg.demo) return demoTicker(handlers);
  if (es) es.close();
  es = new EventSource(`${cfg.server}/api/stream?token=${encodeURIComponent(cfg.token)}`);
  for (const ev of ['tick', 'alert', 'feed', 'scores']) {
    es.addEventListener(ev, e => handlers[ev] && handlers[ev](JSON.parse(e.data)));
  }
  es.onerror = () => handlers.status && handlers.status('reconnecting');
  es.onopen = () => handlers.status && handlers.status('live');
  return () => es && es.close();
}

function demoTicker(handlers) {
  const rows = DEMO['/api/scanner?preset=breath'].rows;
  const base = Object.fromEntries(rows.map(r => [r.symbol, r.price]));
  const t = setInterval(() => {
    const r = rows[Math.floor(Math.random() * rows.length)];
    const ltp = +(base[r.symbol] * (1 + (Math.random() - 0.5) * 0.002)).toFixed(2);
    handlers.tick && handlers.tick({ symbol: r.symbol, ltp, feed: 'demo' });
  }, 700);
  handlers.status && handlers.status('demo');
  return () => clearInterval(t);
}
