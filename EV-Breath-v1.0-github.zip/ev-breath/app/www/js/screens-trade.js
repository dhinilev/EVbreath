// Stock Check and Buzz Alert + Quick Buy
import { api, cfg } from './api.js';
import { band, bar, cls, demoRibbon, dnaTiles, esc, icon, inr, sgn, toast, verdictBadge } from './ui.js';

const RECENT_KEY = 'evb.recent';
const recent = () => { try { return JSON.parse(localStorage.getItem(RECENT_KEY) || '[]'); } catch { return []; } };
const remember = s => { try { localStorage.setItem(RECENT_KEY, JSON.stringify([s, ...recent().filter(x => x !== s)].slice(0, 6))); } catch { /* ignore */ } };

const PARTS = [['trend', 'Trend', 25], ['rs', 'Rel. strength', 20], ['participation', 'Participation', 20], ['oi', 'OI confirm', 15], ['entry', 'Entry setup', 20]];
const VWHY = { 'Calm Buy Zone': 'Trend, money and news agree', 'Wait for the Breath': 'Good stock · let the entry come', 'Not yet': 'Rules not lined up', 'Avoid': 'Blocked by a safety gate' };

export async function check(params) {
  const sym = (params[0] || '').toUpperCase();
  let r = null, err = null;
  if (sym) {
    try { r = await api(`/api/check/${encodeURIComponent(sym)}`); remember(sym); } catch (e) { err = e; }
  }
  const rec = recent().length ? recent() : ['CORALPH', 'AARAVSTL', 'SAGARCEM', 'RAVIPOLY'];
  return {
    tab: 'home',
    html: `${demoRibbon()}${band('Stock Check', 'Enter any NSE / BSE stock · full EV Breath report')}
    <div class="page">
      <form class="row" id="chk"><label class="search grow">${icon('scan', 18)}<input id="sym" value="${esc(sym)}" placeholder="Symbol, e.g. RELIANCE" autocapitalize="characters" style="text-transform:uppercase"></label><button class="btn">Check</button></form>
      <div class="chips"><span class="small muted" style="align-self:center">Recent</span>${rec.map(s => `<a class="chip" href="#/check/${s}" style="display:inline-flex;align-items:center">${s}</a>`).join('')}</div>
      ${err ? `<div class="warn">${esc(err.message)}</div>` : ''}
      ${r ? report(r) : (sym ? '' : '<div class="empty">Type a symbol and tap Check</div>')}
    </div>`,
    mount(root) {
      root.querySelector('#chk').onsubmit = e => { e.preventDefault(); const v = root.querySelector('#sym').value.trim().toUpperCase(); if (v) location.hash = `#/check/${v}`; };
    },
  };
}

function report(r) {
  const b = r.breath, f = r.fundamentals || {};
  const ring = b.score >= 75 ? 'var(--green)' : b.score >= 60 ? 'var(--gold)' : 'var(--muted)';
  const checks = [
    ['Delivery vs 20-day avg', r.delivery_x ? r.delivery_x + '×' : '—', (r.delivery_x || 0) >= 1.2 ? 'up' : ''],
    ['OI (latest session)', b.oi_signal || 'Cash only', ['LB', 'SC'].includes(b.oi_signal) ? 'up' : b.oi_signal === 'SB' ? 'dn' : ''],
    ['ASM / GSM list', r.asm ? 'LISTED' : 'NOT LISTED', r.asm ? 'dn' : 'up'],
    ['Promoter pledge', (r.pledge_pct ?? 0) + '%', (r.pledge_pct ?? 0) > 20 ? 'dn' : 'up'],
    ['Next results', r.results_in_days == null ? '—' : `in ${r.results_in_days} days`, r.gates.entry_blocked ? 'orange' : ''],
  ];
  return `
  <div class="card">
    <div class="between" style="align-items:flex-start"><div class="col"><span class="b" style="font-size:20px">${r.symbol}</span><span class="small muted">${esc(r.sector)} · MCAP ₹${inr(r.mcap_cr, 0)}cr · ${r.fno ? 'F&amp;O' : 'Cash only'}</span></div>
      <div class="col" style="align-items:flex-end"><span class="b" style="font-size:18px" data-ltp="${r.symbol}">₹${inr(r.price)}</span><span class="small ${cls(r.chg_pct)}">${sgn(r.chg_pct)}%</span><span class="xs up">● LIVE</span></div></div>
    <div class="between inner" style="background:${{ 'Calm Buy Zone': 'var(--green)', 'Wait for the Breath': 'var(--gold)', 'Avoid': 'var(--red)' }[r.verdict] || 'var(--muted)'};color:#1A1020"><b>${esc(r.verdict.toUpperCase())}</b><span class="small">${esc(r.gates.pass ? VWHY[r.verdict] : r.gates.fails[0])}</span></div>
  </div>
  <div class="card row" style="flex-direction:row;align-items:center;gap:14px">
    <div class="ring" style="border-color:${ring}"><b>${b.score}</b><span>BREATH</span></div>
    <div class="col grow" style="gap:6px">${PARTS.map(([k, l, max]) => `<div style="display:grid;grid-template-columns:92px 1fr 40px;gap:6px;align-items:center" class="xs"><span class="muted">${l}</span>${bar(b.parts[k] == null ? 0 : b.parts[k] / max * 100)}<span style="text-align:right">${b.parts[k] == null ? '—' : b.parts[k]}/${max}</span></div>`).join('')}
    <span class="xs muted">${esc(b.setup.note)}</span></div>
  </div>
  <div class="grid2">
    <div class="card" style="gap:8px"><span class="xs gold sb">MULTIBAGGER DNA</span>${dnaTiles(r.dna.tests)}<span class="small">${r.dna.passed}/6 pass${r.dna.stage ? ' · ' + r.dna.stage : ''}</span></div>
    <div class="card" style="gap:8px"><span class="xs orange sb">BLAST FUSE</span>${bar(r.fuse.score, 'orange')}<span class="small orange">${r.fuse.score}% · ${esc(r.fuse.status)}</span></div>
  </div>
  ${r.penny ? `<div class="card"><span class="xs muted sb">BUZZ VS SUBSTANCE</span><div style="display:grid;grid-template-columns:74px 1fr 34px;gap:8px;align-items:center" class="xs"><span class="orange">BUZZ</span>${bar(r.penny.buzz, 'orange')}<span>${r.penny.buzz}</span><span class="blue">SUBSTANCE</span>${bar(r.penny.substance, 'blue')}<span>${r.penny.substance}</span></div>${verdictBadge(r.penny.verdict)}</div>` : ''}
  <div class="card list" style="gap:0">${checks.map(([k, v, c]) => `<div class="between" style="padding:9px 0"><span class="dim small">${k}</span><span class="small ${c}">${esc(v)}</span></div>`).join('')}</div>
  <div class="card hl"><span class="xs gold sb">PLAN BEFORE YOU BUY</span><div class="grid3">
    <div class="col"><span class="xs muted">Entry</span><b>₹${inr(r.plan.entry)}</b></div><div class="col"><span class="xs muted">Stop-loss</span><b class="dn">₹${inr(r.plan.stop)}</b></div><div class="col"><span class="xs muted">Qty (rules)</span><b>${r.plan.qty}</b></div></div>
    <span class="xs muted">Risk ₹${inr(r.plan.risk_rupees, 0)} (${r.plan.risk_pct_of_capital}% of capital)</span></div>
  ${r.filings.length ? `<div class="card"><span class="xs muted sb">LATEST FILINGS</span>${r.filings.map(x => `<div class="row small"><span class="muted">${esc(x.time || '')}</span><span>${esc(x.subject)}</span></div>`).join('')}</div>` : ''}
  <div class="grid2"><button class="btn ghost" data-watch>+ Watchlist</button><a class="btn" href="#/alert/${r.symbol}" style="display:flex;align-items:center;justify-content:center">Plan &amp; Buy</a></div>
  <div class="xs muted" style="text-align:center">A screen, not a recommendation.</div>`;
}

export async function alert(params) {
  const sym = (params[0] || '').toUpperCase();
  const d = await api(`/api/alert/${encodeURIComponent(sym)}`);
  const a = d.alert, r = d.row;
  const rk = (await api('/api/rules')).live.risk;
  const capital = rk.capital;
  const buyState = a ? a.buy : (r.gates.pass ? 'risky' : 'none');
  let qty = r.plan.qty, product = 'CNC';
  const limit = r.price, stop = r.plan.stop;
  return {
    tab: 'news',
    html: `${demoRibbon()}${band(a ? '<span class="dn">●</span> Buzz Alert' : 'Quick Buy', a ? esc(a.time || '') + ' · ' + esc(a.kind) : r.symbol)}
    <div class="page">
      ${a ? `<div class="card"><div class="row"><span class="tag" style="border-color:var(--green);color:var(--green)">${esc(a.kind.toUpperCase())}</span><span class="tag">${a.material ? 'MATERIAL' : 'NOT MATERIAL'}</span></div>
        <div class="b" style="font-size:16px;line-height:1.35">${esc(a.subject)}</div><div class="small muted">${esc(a.reason)}</div></div>` : ''}
      <div class="card">
        <div class="between"><span><b style="font-size:16px">${r.symbol}</b> <span data-ltp="${r.symbol}">₹${inr(r.price)}</span> <span class="${cls(r.chg_pct)}">${sgn(r.chg_pct)}%</span></span>${verdictBadge(r.penny ? r.penny.verdict : r.verdict)}</div>
        ${r.penny ? `<div style="display:grid;grid-template-columns:74px 1fr 34px;gap:8px;align-items:center" class="xs"><span class="orange">BUZZ</span>${bar(r.penny.buzz, 'orange')}<span>${r.penny.buzz}</span><span class="blue">SUBSTANCE</span>${bar(r.penny.substance, 'blue')}<span>${r.penny.substance}</span></div>` : ''}
        <div class="chips">${(r.penny ? r.penny.flags : [r.verdict, `BREATH ${r.breath.score}`, `FUSE ${r.fuse.score}`]).map(x => `<span class="tag">${esc(x)}</span>`).join('')}${r.gates.fails.map(x => `<span class="tag" style="border-color:var(--red);color:var(--red)">${esc(x)}</span>`).join('')}</div>
        <a class="small" href="#/check/${r.symbol}">Full Stock Check →</a>
      </div>
      ${buyState === 'none' ? `<div class="warn">No Buy button: ${esc(a ? a.reason : r.gates.fails.join('; '))}</div>` : `
      <div class="sheet" style="position:static;border-radius:20px">
        <div class="between"><b style="font-size:17px">Quick buy</b><span class="xs up sb">● LIVE PRICE · ${cfg.demo ? 'DEMO' : 'BROKER'}</span></div>
        <div class="seg"><button class="on" data-prd="CNC">Delivery (CNC)</button><button data-prd="MIS">Intraday (MIS)</button></div>
        <div class="grid3">
          <div class="field"><label>Quantity</label><div class="row" style="height:44px;border:1px solid var(--line);border-radius:14px;justify-content:space-between"><button class="back" data-q="-1" aria-label="Less" style="margin:0">−</button><b id="qty">${qty}</b><button class="back" data-q="1" aria-label="More" style="margin:0">+</button></div></div>
          <div class="field"><label>Limit price</label><input id="lim" inputmode="decimal" value="${limit.toFixed(2)}"></div>
          <div class="field"><label>Stop-loss</label><input id="stp" inputmode="decimal" value="${stop.toFixed(2)}" style="border-color:var(--red);color:var(--red)"></div>
        </div>
        <div class="between inner small"><span id="val"></span><span id="risk"></span></div>
        ${buyState === 'risky' ? `<label class="row small orange"><input type="checkbox" id="riskack"> I understand this is a risky alert</label>` : ''}
        <div id="res"></div>
        <div class="grid2"><button class="btn ghost" data-back>Dismiss</button><button class="btn" id="go">Confirm buy</button></div>
        <span class="xs muted" style="text-align:center">You confirm every order. Limit + stop-loss only. Nothing buys automatically.</span>
      </div>`}
    </div>`,
    mount(root) {
      if (buyState === 'none') return;
      const $ = s => root.querySelector(s);
      const step = Math.max(1, Math.round(r.plan.qty / 10) || 1);
      const upd = () => {
        const l = parseFloat($('#lim').value) || 0, s = parseFloat($('#stp').value) || 0;
        $('#qty').textContent = qty;
        $('#val').textContent = `Value ₹${inr(qty * l, 0)}`;
        const risk = qty * Math.max(0, l - s);
        $('#risk').innerHTML = `Risk ₹${inr(risk, 0)} <span class="${risk > r.plan.risk_rupees * 1.01 && risk > 0 ? 'dn' : 'up'}">(${(risk / capital * 100).toFixed(2)}% of capital)</span>`;
      };
      root.querySelectorAll('[data-q]').forEach(b => b.onclick = () => { qty = Math.max(1, qty + step * +b.dataset.q); upd(); });
      root.querySelectorAll('[data-prd]').forEach(b => b.onclick = () => { product = b.dataset.prd; root.querySelectorAll('[data-prd]').forEach(x => x.classList.toggle('on', x === b)); });
      $('#lim').oninput = upd; $('#stp').oninput = upd; upd();
      $('#go').onclick = async () => {
        $('#go').disabled = true;
        try {
          const res = await api('/api/orders', { method: 'POST', body: { symbol: r.symbol, qty, limit: parseFloat($('#lim').value), stop: parseFloat($('#stp').value), product, confirm: true, risky_ack: !!(root.querySelector('#riskack') || {}).checked } });
          $('#res').innerHTML = `<div class="okbox">Order ${esc(res.status)} · ${esc(res.order_no || '')}${res.note ? '<br><span class="xs">' + esc(res.note) + '</span>' : ''}</div>`;
          toast(`<b>${r.symbol}</b> order ${esc(res.status)}`);
        } catch (e) {
          $('#res').innerHTML = `<div class="warn">${esc(e.message)}</div>`;
          $('#go').disabled = false;
        }
      };
    },
  };
}
