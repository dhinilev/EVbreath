// Settings, API Hub, Market Data, Rules, About
import { api, cfg } from './api.js';
import { band, demoRibbon, esc, icon, inr, LOGO, toast } from './ui.js';
import { state } from './state.js';

export function openExternal(url) {
  const B = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Browser;
  if (B) B.open({ url }); else window.open(url, '_blank');
}

const GROUPS = { mine: 'YOUR ACCOUNTS', disc: 'DISCOUNT BROKERS', full: 'FULL-SERVICE BROKERS' };

export async function settings() {
  const [b, rules] = await Promise.all([api('/api/brokers'), api('/api/rules')]);
  const brokers = b.brokers;
  let open = false, sel = null, q = '';
  const rk = rules.live.risk;
  return {
    tab: 'home',
    html: `${demoRibbon()}${band('Settings', 'Server, broker, rules and data')}
    <div class="page">
      <div class="card">
        <h3>EV Breath server</h3>
        <div class="field"><label for="srv">Server address</label><input id="srv" placeholder="https://your-server:8000" value="${esc(cfg.server)}"></div>
        <div class="field"><label for="tok">App token</label><input id="tok" type="password" placeholder="EVB_APP_TOKEN from the server" value="${esc(cfg.token)}"></div>
        <div class="xs muted">Leave the address empty to use the demo market. Orders need the server: it holds the static IP SEBI requires.</div>
        <div class="grid2"><button class="btn ghost sm" id="demo">Use demo</button><button class="btn sm" id="savesrv">Save &amp; test</button></div>
        <div id="srvres"></div>
      </div>
      <div class="col">
        <span class="xs muted" style="letter-spacing:2px">BROKER &amp; API · ${brokers.length} AVAILABLE</span>
        <button class="card between" id="ddbtn" style="flex-direction:row;color:var(--text);text-align:left"><span class="col"><b id="ddtitle">Choose your demat / broker</b><span class="xs muted" id="ddsub">${brokers.length} broker APIs · search or scroll</span></span>${icon('down', 18)}</button>
        <div id="dd"></div>
        <div id="bpage"></div>
      </div>
      <div class="card list" style="gap:0">
        <a class="between" href="#/rules" style="padding:12px 0;color:var(--text)"><span>Stock selection rules</span><span class="xs gold b">v${esc(rules.live_version)} · edit →</span></a>
        <a class="between" href="#/apihub" style="padding:12px 0;color:var(--text)"><span>API Hub · all connections</span><span class="xs gold b">93 APIs →</span></a>
        <a class="between" href="#/datasource" style="padding:12px 0;color:var(--text)"><span>Market data</span><span class="xs up b">● ${cfg.demo ? 'DEMO' : 'LIVE'} →</span></a>
        <div class="between" style="padding:12px 0"><span>Capital</span><span>₹${inr(rk.capital, 0)}</span></div>
        <div class="between" style="padding:12px 0"><span>Risk per trade</span><span>${rk.risk_pct}%</span></div>
        <a class="between" href="#/about" style="padding:12px 0;color:var(--text)"><span>About EV Breath</span><span class="gold">→</span></a>
      </div>
    </div>`,
    mount(root, rerender) {
      const $ = s => root.querySelector(s);
      $('#savesrv').onclick = async () => {
        cfg.save($('#srv').value, $('#tok').value);
        try { const h = await api('/api/health'); $('#srvres').innerHTML = `<div class="okbox">Connected · ${esc(h.mode)} mode · rules v${esc(h.rules)}</div>`; window.dispatchEvent(new Event('evb-reconnect')); }
        catch (e) { $('#srvres').innerHTML = `<div class="warn">Could not reach the server: ${esc(e.message)}</div>`; }
      };
      $('#demo').onclick = () => { cfg.save('', ''); toast('Demo market on'); window.dispatchEvent(new Event('evb-reconnect')); rerender(); };
      const drawList = () => {
        if (!open) { $('#dd').innerHTML = ''; return; }
        const ql = q.toLowerCase();
        const groups = Object.entries(GROUPS).map(([g, t]) => [t, brokers.filter(x => x.group === g && (!ql || (x.name + x.product).toLowerCase().includes(ql)))]).filter(([, l]) => l.length);
        $('#dd').innerHTML = `<div class="ddlist"><div style="padding:10px"><label class="search" style="height:40px">${icon('scan', 16)}<input id="bq" value="${esc(q)}" placeholder="Search broker"></label></div><div class="scroll">
          ${groups.map(([t, l]) => `<div class="ddgroup">${t} · ${l.length}</div>${l.map(x => `<button class="dditem" data-b="${x.id}"><span class="col"><b class="small">${esc(x.name)}</b><span class="xs muted">${esc(x.product)}</span></span><span class="xs ${x.connected ? 'up' : x.saved ? 'gold' : 'muted'}">${x.connected ? 'CONNECTED' : x.saved ? 'SAVED' : '›'}</span></button>`).join('')}`).join('') || '<div class="empty">No broker matches</div>'}</div></div>`;
        const inp = $('#bq'); inp.oninput = () => { q = inp.value; drawList(); const n = $('#bq'); n.focus(); n.setSelectionRange(q.length, q.length); };
        root.querySelectorAll('[data-b]').forEach(btn => btn.onclick = () => { sel = brokers.find(x => x.id === btn.dataset.b); open = false; drawList(); drawPage(); });
      };
      const drawPage = () => {
        if (!sel) { $('#bpage').innerHTML = ''; return; }
        $('#ddtitle').textContent = sel.name; $('#ddsub').textContent = sel.product + ' · tap to switch';
        $('#bpage').innerHTML = `<div class="card" style="margin-top:8px">
          <div class="between"><span class="col"><b>${esc(sel.name)}</b><span class="xs muted">${esc(sel.product)}</span></span><span class="badge ${sel.connected ? 'green' : 'grey'}">${sel.connected ? 'CONNECTED' : sel.saved ? 'SAVED' : 'NOT CONNECTED'}</span></div>
          ${sel.fields.map((f, i) => `<div class="field"><label for="bf${i}">${esc(f)}</label><input id="bf${i}" data-f="${esc(f)}" ${/secret|key|token/i.test(f) ? 'type="password"' : ''} placeholder="${sel.saved ? '•••••••• saved' : 'Enter ' + esc(f.toLowerCase())}"></div>`).join('')}
          <div class="inner xs"><span class="muted">Static IP (SEBI rule · orders only from this IP)</span><br><b>${esc(cfg.server ? new URL(cfg.server).hostname : 'your server')}</b></div>
          <div class="xs muted">${esc(sel.note)}${sel.adapter ? '' : ' · Live orders for this broker are on the roadmap; keys are stored on your server.'}</div>
          <div class="grid2"><button class="btn ghost sm" id="bdocs">API docs</button><button class="btn sm" id="bsave">${sel.adapter ? 'Save &amp; log in' : 'Save keys'}</button></div>
          <div id="bres"></div></div>`;
        $('#bdocs').onclick = () => openExternal('https://www.google.com/search?q=' + encodeURIComponent(sel.name + ' ' + sel.product + ' documentation'));
        $('#bsave').onclick = async () => {
          const body = {}; root.querySelectorAll('[data-f]').forEach(i => { if (i.value) body[i.dataset.f] = i.value; });
          try {
            const res = await api(`/api/brokers/${sel.id}`, { method: 'POST', body });
            if (res.login_url) { $('#bres').innerHTML = `<div class="okbox">Keys saved. Approve EV Breath on the Flattrade page that opens.</div>`; openExternal(res.login_url); }
            else $('#bres').innerHTML = `<div class="okbox">${esc(res.note || 'Keys saved on your server')}</div>`;
          } catch (e) { $('#bres').innerHTML = `<div class="warn">${esc(e.message)}</div>`; }
        };
      };
      $('#ddbtn').onclick = () => { open = !open; drawList(); };
    },
  };
}

// ------------------------------------------------------------------ API Hub
const FREE = 'FREE', FM = 'FREEMIUM', PAID = 'PAID';
const HUB = [
  ['data', 'Live data', 'REAL-TIME DATA VENDORS', 'NSE-authorised', [
    ...['TrueData', 'Global Financial Datafeeds (GDFL)', 'TradingView', 'Vtrender Charts', 'Spider Software', 'Market Pulse Technologies', 'Quantsapp', 'Reliable Software Systems', 'Ticker Data'].map(n => [n, 'RETAIL · TICK DATA · NSE/BSE', PAID]),
    ...['Bloomberg', 'Refinitiv (LSEG)', 'FactSet', 'ICE Data Services', 'Morningstar', 'Cogencis Information Services', 'Activ Financial', 'SIX Financial Information', 'FIS Global', 'Fidessa', 'Imagine Software', 'Instinet', 'Liquidnet', 'Trading Technologies', 'Transaction Network Services', 'Virtu ITG', 'Xignite'].map(n => [n, 'INSTITUTIONAL · ENTERPRISE FEED', PAID])]],
  ['exch', 'Exchange', 'EXCHANGE & PUBLIC DATA', 'Built into the server', [
    ['NSE equity bhavcopy + delivery', 'EOD PRICES · DELIVERY %', FREE, 1], ['NSE F&O bhavcopy', 'EOD OI · BUILDUP', FREE, 1], ['NSE corporate announcements', 'FILINGS FEED', FREE, 1],
    ['BSE corporate announcements', 'BSE-ONLY STOCKS', FREE, 1], ['NSE ASM / GSM / F&O ban', 'SAFETY FLAGS', FREE, 1], ['NSE FII / DII + bulk & block deals', 'FLOWS', FREE, 1],
    ['BSE / NSE XBRL results', 'QUARTERLY FINANCIALS', FREE], ['AMFI mutual fund NAV & holdings', 'MF DATA', FREE], ['RBI DBIE', 'MACRO', FREE]]],
  ['fund', 'Fundamentals', 'FUNDAMENTALS & GLOBAL', 'Market data APIs', [['EODHD', 'NSE/BSE EOD · FUNDAMENTALS', PAID], ['Twelve Data', 'NSE QUOTES · INDICATORS', FM], ['Alpha Vantage', 'BSE QUOTES', FM], ['Finnhub', 'GLOBAL NEWS', FM], ['Yahoo Finance (unofficial)', 'TESTING ONLY', FREE]]],
  ['news', 'News', 'NEWS', 'Headlines', [['Google News RSS', 'MEDIA COVERAGE', FREE], ['NewsAPI.org', 'HEADLINES', FM], ['GNews', 'HEADLINES', FM], ['Economic Times Markets RSS', 'MARKET NEWS', FREE], ['Moneycontrol RSS', 'MARKET NEWS', FREE], ['Business Standard / Mint RSS', 'MARKET NEWS', FREE]]],
  ['social', 'Sentiment', 'SOCIAL SENTIMENT', 'Buzz score', [['X (Twitter) API', 'MENTIONS', PAID], ['Reddit API', 'RETAIL CHATTER', FM], ['YouTube Data API', 'VIDEO MENTIONS', FREE], ['Telegram Bot API', 'YOUR CHANNELS', FREE]]],
  ['alert', 'Alerts', 'ALERTS & MESSAGING', 'Notify you', [['Android notifications', 'BUZZ ALERTS', FREE, 1], ['Telegram Bot API', 'ALERTS', FREE], ['WhatsApp Business Cloud API', 'ALERTS', PAID], ['Twilio SMS', 'SMS', PAID], ['Gmail API / SMTP', 'EMAIL DIGEST', FREE]]],
  ['chart', 'Charts & AI', 'CHARTS & AI', 'Display and explain', [['TradingView Lightweight Charts', 'CHART LIBRARY', FREE], ['TradingView Charting Library', 'ADVANCED CHARTS', FREE], ['Claude API (Anthropic)', 'AI NEWS SUMMARY', PAID]]],
];
const PC = { FREE: 'var(--green)', FREEMIUM: 'var(--blue2)', PAID: 'var(--orange)' };

export async function apihub() {
  const { brokers } = await api('/api/brokers');
  const cats = [['broker', 'Brokers', 'BROKER APIs', 'Orders + live data', brokers.map(b => [b.name, b.product.toUpperCase() + ' · ORDERS + DATA', FREE, b.connected ? 1 : 0])], ...HUB];
  const all = cats.flatMap(c => c[4]);
  const cat = state.hubCat, q = (state.hubQ || '').toLowerCase();
  const groups = cats.filter(c => cat === 'all' || cat === c[0]).map(c => [c, c[4].filter(a => !q || (a[0] + a[1]).toLowerCase().includes(q))]).filter(([, l]) => l.length);
  return {
    tab: 'home',
    html: `${band('API Hub', 'Every API EV Breath can connect to')}
    <div class="page">
      <div class="stats"><div class="stat"><span class="k">Available</span><span class="v">${all.length}</span></div><div class="stat"><span class="k">Connected</span><span class="v up">${all.filter(a => a[3]).length}</span></div><div class="stat"><span class="k">Free</span><span class="v gold">${all.filter(a => a[2] === FREE).length}</span></div></div>
      <label class="search">${icon('scan', 18)}<input id="hq" value="${esc(state.hubQ || '')}" placeholder="Search any API"></label>
      <div class="chips"><button class="chip ${cat === 'all' ? 'on' : ''}" data-c="all">All ${all.length}</button>${cats.map(c => `<button class="chip ${cat === c[0] ? 'on' : ''}" data-c="${c[0]}">${c[1]} ${c[4].length}</button>`).join('')}</div>
      ${groups.map(([c, l]) => `<div class="col"><div class="between" style="padding-top:6px"><span class="xs gold" style="letter-spacing:2px">${c[2]} · ${l.length}</span><span class="xs muted">${c[3]}</span></div>
        <div class="list">${l.map(a => `<div class="between" style="padding:10px 0"><span class="col"><b class="small">${esc(a[0])}</b><span class="xs muted">${esc(a[1])}</span></span><span class="row">${a[3] ? '<span class="badge green">ON</span>' : ''}<span class="tag" style="border-color:${PC[a[2]]};color:${PC[a[2]]}">${a[2]}</span></span></div>`).join('')}</div></div>`).join('') || '<div class="empty">No API matches</div>'}
      <div class="xs muted">FREE / FREEMIUM / PAID is a guide; check each provider’s current plan. Broker data is for your own account; showing live prices to other users needs a licensed vendor.</div>
    </div>`,
    mount(root, rerender) {
      root.querySelectorAll('[data-c]').forEach(b => b.onclick = () => { state.hubCat = b.dataset.c; rerender(); });
      const i = root.querySelector('#hq'); let t; i.oninput = () => { clearTimeout(t); t = setTimeout(() => { state.hubQ = i.value; rerender(true); }, 300); };
    },
  };
}

// ------------------------------------------------------------------ Market data
export async function datasource() {
  const d = await api('/api/datasource');
  const active = d.feeds.find(f => f.id === d.active);
  const C = { ACTIVE: 'var(--green)', STANDBY: 'var(--blue2)', DOWN: 'var(--red)', 'NOT CONNECTED': 'var(--muted)' };
  return {
    tab: 'home',
    html: `${demoRibbon()}${band('Market Data', 'Real-time feed · auto failover')}
    <div class="page">
      <div class="card" style="border-color:${active ? '#1F4A37' : 'var(--red)'}"><div class="between"><b class="${active ? 'up' : 'dn'}"><span class="dot ${active ? '' : 'off'}"></span> ${active ? 'LIVE · ' + esc(active.name.toUpperCase()) : 'NO LIVE FEED'}</b><span class="xs muted">${cfg.demo ? 'DEMO' : esc(d.mode).toUpperCase()}</span></div>
        <div class="grid3"><div class="col"><span class="xs muted">TICKS</span><b>${active ? inr(active.ticks, 0) : '—'}</b></div><div class="col"><span class="xs muted">LAST TICK</span><b>${active && active.age_s != null ? active.age_s + 's ago' : '—'}</b></div><div class="col"><span class="xs muted">SYMBOLS</span><b>${d.last_prices ?? '—'}</b></div></div></div>
      <span class="xs muted" style="letter-spacing:2px">FEED PRIORITY · ALL REAL-TIME</span>
      <div class="list">${d.feeds.map((f, i) => `<div class="between" style="padding:12px 0"><span class="row"><span class="tag" style="border-color:${C[f.state]};color:${C[f.state]}">${i + 1}</span><span class="col"><b class="small">${esc(f.name)}</b><span class="xs muted">${esc(f.kind)}${f.error ? ' · ' + esc(f.error) : ''}</span></span></span>
        <span class="row"><span class="tag" style="border-color:${C[f.state]};color:${C[f.state]}">${f.state}</span>${f.state === 'ACTIVE' || f.state === 'DOWN' ? `<button class="btn sm ghost" data-t="${f.id}" data-down="${f.state === 'ACTIVE' ? 1 : 0}">${f.state === 'ACTIVE' ? 'Test drop' : 'Restore'}</button>` : ''}</span></div>`).join('')}</div>
      <div class="xs muted">Auto failover switches to the next live feed within 2 seconds. Broker data is for your own account only.</div>
      <span class="xs muted" style="letter-spacing:2px">WHAT RUNS LIVE</span>
      <div class="list small">${[['Prices, ticker, Stock Check', 'TICK-BY-TICK'], ['Buzz Alert & Quick Buy', 'TICK-BY-TICK'], ['Scanner LTP, OI, volume', 'LIVE'], ['NSE / BSE announcements', 'PUSHED'], ['Breath / Fuse / DNA scores', 'EVERY 5 MIN'], ['Delivery % & fundamentals', 'AFTER CLOSE']].map(([a, b], i) => `<div class="between" style="padding:9px 0"><span class="dim">${a}</span><span class="xs ${i < 5 ? 'up' : 'muted'}">${b}</span></div>`).join('')}</div>
    </div>`,
    mount(root, rerender) {
      root.querySelectorAll('[data-t]').forEach(b => b.onclick = async () => { await api('/api/datasource/test', { method: 'POST', body: { feed: b.dataset.t, down: b.dataset.down === '1' } }); setTimeout(() => rerender(), 1500); });
    },
  };
}

// ------------------------------------------------------------------ Rules
const RULES_UI = [
  ['Safety gates', 'Fail = no Buy button', [['gates.main.min_price', 'Minimum price', 20, 500, 10, v => '₹' + v], ['gates.main.min_turnover_cr', 'Minimum daily turnover', 1, 100, 1, v => '₹' + v + ' cr'], ['gates.main.max_pledge_pct', 'Maximum promoter pledge', 0, 50, 1, v => v + '%']]],
  ['Market filter', 'Breath Meter 0–100', [['market.panic_below', 'Panic below', 10, 50, 1, String], ['market.euphoria_above', 'Euphoria above', 60, 95, 1, String]]],
  ['Breath Score', 'Scanner and Stock Check', [['breath.calm_from', 'Calm Buy Zone from', 50, 95, 1, String], ['breath.wait_from', 'Wait for the Breath from', 40, 80, 1, String], ['breath.no_chase_pct', 'No chasing above entry by', 1, 15, 1, v => v + '%']]],
  ['Multibagger DNA', 'Reviewed quarterly', [['dna.tests_to_pass', 'Tests to pass', 3, 6, 1, v => v + ' of 6'], ['dna.growth_pct', 'Sales & profit growth (3Y)', 10, 40, 1, v => v + '%'], ['dna.roce_pct', 'Minimum ROCE', 10, 30, 1, v => v + '%']]],
  ['Blast Fuse', 'Coiled stocks', [['fuse.lit_from', 'Fuse lit from', 40, 90, 1, String], ['fuse.ignite_volume_ratio', 'Ignite on volume', 1, 3, 0.1, v => (+v).toFixed(1) + '×']]],
  ['Penny Buzz', 'Buzz vs Substance', [['penny.real_from', 'Real trigger from Substance', 40, 90, 1, String], ['penny.pump_buzz_from', 'Pump risk from Buzz', 50, 95, 1, String], ['penny.risk_pct', 'Risk per penny trade', 0.1, 1, 0.1, v => (+v).toFixed(1) + '%']]],
  ['Plan and risk', 'Every buy', [['risk.capital', 'Capital', 10000, 5000000, 10000, v => '₹' + inr(v, 0)], ['risk.risk_pct', 'Risk per trade', 0.25, 3, 0.25, v => v + '%'], ['risk.max_positions', 'Maximum open positions', 2, 15, 1, String], ['risk.time_stop_sessions', 'Time stop', 5, 40, 1, v => v + ' sessions']]],
];
const getp = (o, p) => p.split('.').reduce((a, k) => a[k], o);

export async function rules() {
  const d = await api('/api/rules');
  const live = d.live;
  const draft = {};
  for (const [p, ch] of Object.entries(d.draft_diff || {})) draft[p] = ch.new;
  let bt = null;
  return {
    tab: 'home',
    html: `${demoRibbon()}${band('Rules', 'Every number the app uses to pick stocks', { right: `<span class="pill" style="color:var(--gold)" id="ver">v${esc(d.live_version)} · live</span>` })}
    <div class="page">
      ${RULES_UI.map(([t, sub, items]) => `<div class="card"><div class="between"><h3>${t}</h3><span class="xs muted">${sub}</span></div>
        ${items.map(([p, label, min, max, step, fmt]) => { const v = draft[p] ?? getp(live, p); return `<div class="col" style="gap:6px;padding:8px 0;border-top:1px solid var(--line2)">
          <div class="between"><label for="${p}" class="small">${label}</label><span class="row"><span class="badge" data-ed="${p}" style="display:${p in draft ? 'inline' : 'none'};font-size:10px">EDITED</span><b class="gold" data-v="${p}">${fmt(v)}</b></span></div>
          <input type="range" id="${p}" data-p="${p}" min="${min}" max="${max}" step="${step}" value="${v}"></div>`; }).join('')}</div>`).join('')}
      <div id="bt"></div>
      ${d.changelog && d.changelog.length ? `<div class="card"><h3>Change log</h3>${d.changelog.map(c => `<div class="small"><b>v${esc(c.version)}</b> · ${esc(c.date)} · ${Object.keys(c.changes).length} change(s)${c.reason ? ' · ' + esc(c.reason) : ''}</div>`).join('')}</div>` : ''}
      <div class="sheet"><span class="xs muted" id="status" style="text-align:center"></span>
        <div class="grid2"><button class="btn ghost" id="reset">Reset to v${esc(d.live_version)}</button><button class="btn" id="cta"></button></div></div>
    </div>`,
    mount(root, rerender) {
      const $ = s => root.querySelector(s);
      const fmtOf = Object.fromEntries(RULES_UI.flatMap(g => g[2]).map(r => [r[0], r[5]]));
      const refresh = () => {
        const n = Object.keys(draft).length;
        $('#ver').textContent = n ? `v${d.live_version} → draft` : `v${d.live_version} · live`;
        $('#status').textContent = n === 0 ? `Live rules: v${d.live_version}` : bt ? `${n} change(s) backtested · ready to save` : `${n} unsaved change(s) · backtest before going live`;
        $('#cta').textContent = n === 0 ? 'Run backtest' : bt ? 'Save new version' : 'Backtest changes';
      };
      let timer;
      root.querySelectorAll('[data-p]').forEach(inp => inp.oninput = () => {
        const p = inp.dataset.p, v = parseFloat(inp.value);
        if (Math.abs(v - getp(live, p)) < 1e-9) delete draft[p]; else draft[p] = v;
        root.querySelector(`[data-v="${p}"]`).textContent = fmtOf[p](v);
        root.querySelector(`[data-ed="${p}"]`).style.display = p in draft ? 'inline' : 'none';
        bt = null; $('#bt').innerHTML = ''; refresh();
        clearTimeout(timer);
        timer = setTimeout(async () => {
          try { await api('/api/rules/reset', { method: 'POST' }); if (Object.keys(draft).length) await api('/api/rules/draft', { method: 'PUT', body: { changes: draft } }); }
          catch (e) { toast(esc(e.message)); }
        }, 400);
      });
      $('#reset').onclick = async () => { await api('/api/rules/reset', { method: 'POST' }); rerender(); };
      $('#cta').onclick = async () => {
        const n = Object.keys(draft).length;
        if (n && bt) {
          const reason = prompt('Why this change? (saved in the change log)', '') || '';
          try { const res = await api('/api/rules/publish', { method: 'POST', body: { reason } }); toast(`Rules v${esc(res.live_version)} are live`); rerender(); }
          catch (e) { toast(esc(e.message)); }
          return;
        }
        $('#cta').disabled = true; $('#cta').textContent = 'Backtesting…';
        try {
          const r = await api('/api/rules/backtest?days=250', { method: 'POST' });
          bt = r;
          const row = (k, x) => `<div class="grid3 small"><span class="sb">${k}</span><span>${x.trades} trades · ${x.hit_rate_pct ?? '—'}% hit</span><span>avg ${x.avg_r ?? '—'} R</span></div>`;
          $('#bt').innerHTML = `<div class="card hl"><h3>Backtest · last 250 sessions</h3>${row('Live v' + d.live_version, r.live)}${n ? row('Your draft', r.draft) : ''}<span class="xs muted">Past results do not promise future ones.</span></div>`;
        } catch (e) { toast(esc(e.message)); }
        $('#cta').disabled = false; refresh();
      };
      refresh();
    },
  };
}

// ------------------------------------------------------------------ About
export async function about() {
  const steps = [['Scan', 'Every evening after close, the whole universe is checked against the rules.'], ['Check substance', 'Is there real news, delivery and OI behind the move, or only buzz?'],
    ['Wait for the breath', 'Enter on a calm pullback or a clean base breakout. Never chase.'], ['Plan before you buy', 'Entry, stop-loss and quantity at 1% risk are set first.'], ['You confirm', 'Nothing buys automatically. Every order is your decision.']];
  return {
    tab: 'home',
    html: `${band('About', '')}
    <div class="page" style="align-items:stretch">
      <div class="col" style="align-items:center;gap:8px;padding:8px 0"><div class="logo" style="width:84px;height:84px;border-radius:20px">${LOGO.replace(/width="28" height="28"/, 'width="64" height="64"')}</div>
        <span class="brand" style="font-size:34px">EV <span>Breath</span></span><span class="small muted" style="letter-spacing:5px">TRADE CALM.</span><span class="xs muted">An Erulenkattil Veettil Group · v1.0</span></div>
      <div class="card row" style="flex-direction:row"><span class="ring" style="width:52px;height:52px;border-width:2px"><b style="font-size:20px" class="gold">V</b></span><span class="col"><span class="xs muted">Created by</span><b>Valerian</b><span class="small dim">12+ years in the market</span></span></div>
      <div class="small dim" style="line-height:1.55">EV Pulse reads the options market. <b style="color:var(--text)">EV Breath reads equity stocks</b>: trend, delivery, OI, fundamentals and real news. The market always moves for a reason. Breath helps you find it calmly, and plan every buy before you take it.</div>
      <span class="xs muted" style="letter-spacing:2px">THE PLAN TO BUY</span>
      <div class="list">${steps.map(([t, s], i) => `<div class="row" style="padding:9px 0;align-items:flex-start"><b class="gold small" style="width:24px">0${i + 1}</b><span class="col"><b class="small">${t}</b><span class="xs muted">${s}</span></span></div>`).join('')}</div>
      <div class="col" style="align-items:center;gap:4px"><b class="gold">No luck. Only information.</b><span class="xs muted">Sister app: EV Pulse (options) · An information tool, not investment advice.</span></div>
    </div>`,
  };
}
