// Router, live updates and alert notifications.
import { connectStream } from './api.js';
import { about, apihub, datasource, rules, settings } from './screens-settings.js';
import { alert, check } from './screens-trade.js';
import { blast, home, multibagger, news, penny, scanner } from './screens-main.js';
import { state } from './state.js';
import { errorBox, esc, inr, loading, nav, toast } from './ui.js';

const ROUTES = { home, scanner, multibagger, blast, news, penny, check, alert, settings, apihub, datasource, rules, about };
const root = document.getElementById('app');
let seq = 0;

async function render(keepFocus = false) {
  const [name, ...params] = (location.hash.replace(/^#\/?/, '') || 'home').split('/');
  const screen = ROUTES[name] || home;
  const my = ++seq;
  const focusedId = keepFocus && document.activeElement && document.activeElement.id;
  const caret = focusedId && document.activeElement.selectionStart;
  if (!keepFocus) root.innerHTML = loading();
  try {
    const view = await screen(params.map(decodeURIComponent));
    if (my !== seq) return;
    root.innerHTML = view.html + nav(view.tab);
    if (view.mount) view.mount(root, kf => render(kf));
    if (focusedId) { const el = document.getElementById(focusedId); if (el) { el.focus(); try { el.setSelectionRange(caret, caret); } catch { /* not a text input */ } } }
    if (!keepFocus) window.scrollTo(0, 0);
  } catch (e) {
    if (my === seq) root.innerHTML = errorBox(e) + nav('home');
  }
}

root.addEventListener('click', e => {
  const go = e.target.closest('[data-go]');
  if (go) { location.hash = go.dataset.go; return; }
  if (e.target.closest('[data-back]')) { if (history.length > 1) history.back(); else location.hash = '#/home'; }
});
window.addEventListener('hashchange', () => render());

// Live: update every price on screen as ticks arrive; surface Buzz Alerts.
let stop = null;
function startLive() {
  if (stop) stop();
  stop = connectStream({
    tick(t) {
      document.querySelectorAll(`[data-ltp="${t.symbol}"]`).forEach(el => {
        el.textContent = (el.textContent.trim().startsWith('₹') ? '₹' : '') + inr(t.ltp);
        el.classList.remove('flash'); void el.offsetWidth; el.classList.add('flash');
      });
    },
    alert(a) {
      toast(`<b>● Buzz Alert · ${esc(a.symbol)}</b><br><span class="small">${esc(a.subject)}</span><br><a href="#/alert/${esc(a.symbol)}" class="sb">${a.buy === 'buy' ? 'Open · Buy' : 'Open'}</a>`, 10000);
      notify(a);
    },
    scores() { const n = location.hash.split('/')[1] || 'home'; if (['home', 'scanner', 'blast', 'multibagger'].includes(n)) render(true); },
    status(s) {
      state.live = s;
      const p = document.querySelector('[data-live-pill]');
      if (p) p.innerHTML = `<span class="dot ${s === 'live' ? '' : s === 'demo' ? 'warn' : 'off'}"></span>${s === 'live' ? 'LIVE' : s === 'demo' ? 'DEMO' : 'RECONNECTING'}`;
    },
  });
}

let notifId = 1;
async function notify(a) {
  const LN = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications;
  if (!LN) return;
  try {
    const perm = await LN.requestPermissions();
    if (perm.display !== 'granted') return;
    await LN.schedule({ notifications: [{ id: notifId++, title: `Buzz Alert · ${a.symbol}`, body: a.subject, extra: { symbol: a.symbol } }] });
  } catch { /* notifications optional */ }
}
const LN = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications;
if (LN) LN.addListener('localNotificationActionPerformed', ev => { const s = ev.notification.extra && ev.notification.extra.symbol; if (s) location.hash = `#/alert/${s}`; });

window.addEventListener('evb-reconnect', startLive);
startLive();
render();
