// Shared UI pieces: formatting, icons, header band, bottom menu.
import { cfg } from './api.js';

export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const inr = (n, dp = 2) => n == null || isNaN(n) ? '—' : Number(n).toLocaleString('en-IN', { minimumFractionDigits: dp, maximumFractionDigits: dp });
export const sgn = (n, dp = 2) => n == null ? '—' : (n >= 0 ? '+' : '−') + Math.abs(n).toFixed(dp);
export const cls = n => (n ?? 0) >= 0 ? 'up' : 'dn';

const P = {
  home: '<path d="M3 11 12 4l9 7v9H3z"/>',
  scan: '<circle cx="11" cy="11" r="7"/><path d="m16 16 5 5"/>',
  mb: '<path d="M3 18l6-6 4 3 8-9"/><path d="M15 6h6v6"/>',
  blast: '<path d="M12 3c1 4 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-4-1-6 1-9z"/>',
  news: '<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 9h8M8 13h8M8 17h5"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1 7 17M17 7l2.1-2.1"/>',
  back: '<path d="M15 5l-7 7 7 7"/>',
  down: '<path d="M6 9l6 6 6-6"/>', up: '<path d="M6 15l6-6 6 6"/>',
};
export const icon = (name, size = 22) => `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[name]}</svg>`;

export const LOGO = `<svg width="28" height="28" viewBox="0 0 200 200" fill="none" aria-hidden="true"><circle cx="100" cy="100" r="30" stroke="#4F8EF7" stroke-width="16"/><circle cx="100" cy="100" r="62" stroke="#4F8EF7" stroke-opacity=".55" stroke-width="14"/><circle cx="100" cy="100" r="92" stroke="#4F8EF7" stroke-opacity=".28" stroke-width="12"/><path d="M30 140 L72 108 L98 120 L168 54" stroke="#E8B84A" stroke-width="20" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

export function band(title, sub, { back = true, right = '' } = {}) {
  return `<div class="band"><div class="row">
    ${back ? `<button class="back" data-back aria-label="Back">${icon('back', 20)}</button>` : ''}
    <div class="col grow"><span class="title">${title}</span>${sub ? `<span class="sub">${sub}</span>` : ''}</div>${right}
  </div></div>`;
}

export function livePill(state) {
  const label = state === 'demo' ? 'DEMO' : state === 'live' ? 'LIVE' : 'RECONNECTING';
  return `<a class="pill" href="#/datasource" data-live-pill><span class="dot ${state === 'live' ? '' : state === 'demo' ? 'warn' : 'off'}"></span>${label}</a>`;
}

const TABS = [['home', 'Home', 'home'], ['scanner', 'Scanner', 'scan'], ['multibagger', 'Multibagger', 'mb'], ['blast', 'Blast', 'blast'], ['news', 'News', 'news']];
export function nav(active) {
  return `<nav class="nav" aria-label="Main">${TABS.map(([id, label, ic]) =>
    `<a href="#/${id}" class="${active === id ? 'on' : ''}">${icon(ic)}${label}</a>`).join('')}</nav>`;
}

export const demoRibbon = () => cfg.demo ? `<div class="demo-ribbon">Demo market · sample data · set your server in Settings</div>` : '';

export function bar(pct, kind = '') {
  return `<div class="bar ${kind}"><i style="width:${Math.max(0, Math.min(100, pct))}%"></i></div>`;
}

export function dnaTiles(tests) {
  return `<div class="dna">${['G', 'R', 'D', 'P', 'S', 'T'].map(l => `<span class="${tests && tests[l] ? 'on' : ''}">${l}</span>`).join('')}</div>`;
}

export function verdictBadge(v) {
  const k = { 'Calm Buy Zone': 'green', 'Wait for the Breath': '', 'Not yet': 'grey', 'Avoid': 'red',
    'Real trigger': 'green', 'Watch': '', 'Pump risk': 'red' }[v] ?? 'grey';
  return `<span class="badge ${k}">${esc(v)}</span>`;
}

let toastTimer;
export function toast(html, ms = 5000) {
  let t = document.querySelector('.toast');
  if (!t) { t = document.createElement('div'); t.className = 'toast'; document.body.appendChild(t); }
  t.innerHTML = html;
  t.style.display = 'block';
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.style.display = 'none'; }, ms);
  t.onclick = () => { t.style.display = 'none'; };
}

export const loading = () => `<div class="empty">Loading…</div>`;
export const errorBox = e => `<div class="page"><div class="warn">${esc(e.message || e)}</div></div>`;
