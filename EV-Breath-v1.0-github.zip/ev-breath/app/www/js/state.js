// In-memory app state shared across screens.
export const state = {
  live: 'demo',      // demo | live | reconnecting
  exch: 'NSE',
  scanPreset: 'breath', scanQ: '',
  mbStage: 'Early', blastTab: 'lit', newsTab: 'mb',
  pennyHide: true, pennyBand: '',
  hubCat: 'all', hubQ: '',
};
