# EV Breath · Trade Calm.

Equity stock app by **Erulenkattil Veettil Group**. Sister app of EV Pulse (options).

- **App** (`app/`): Android app (Capacitor). Home, Scanner, Multibagger Radar, Blast Watch, News, Penny Buzz,
  Buzz Alert + Quick Buy, Stock Check, Settings (35 broker APIs), API Hub, Market Data, Rules, About.
- **Server** (`server/`): Python. Runs the rulebook (Breath Score, Multibagger DNA, Blast Fuse, Penny Buzz vs
  Substance, Buzz Alerts, plan and risk), downloads NSE/BSE data, streams live prices, and relays your
  Flattrade orders from a static IP.

The app works on its own in **demo mode** (sample market, fictional companies) until you connect a server.

---

## 1. Put it on GitHub

1. Create a new **private** repository on GitHub, for example `ev-breath`.
2. Unzip this folder and upload everything (keep the `.github` folder; it is hidden on some computers).
   - Website: repo page › **Add file › Upload files** › drag all files and folders › **Commit**.
   - Or with git: `git init && git add . && git commit -m "EV Breath v1.0" && git branch -M main && git remote add origin https://github.com/<you>/ev-breath.git && git push -u origin main`

## 2. Get the APK

1. Open the repo's **Actions** tab. **Build EV Breath APK** starts on every push (or press **Run workflow**).
2. When it finishes (about 6–8 minutes), open the run › **Artifacts** › download **EV-Breath-APK**.
3. Unzip it, copy the `.apk` to your phone and install it (allow "Install unknown apps" for your file manager).

This is a debug build for your own phone. A Play Store release needs a signing key (see section 6).

## 3. Run the server

The server needs a machine with a **static public IP** (SEBI rule for API orders): any small cloud VM works.

```bash
cd server
cp .env.example .env            # set EVB_APP_TOKEN to a long random password
pip install -r requirements.txt
EVB_MODE=demo python run.py     # sample market, to try it first
EVB_MODE=live python run.py     # real NSE data + your broker feed
```

Or with Docker: `docker build -t evbreath server && docker run -d -p 8000:8000 -v evb:/data -e EVB_MODE=live -e EVB_APP_TOKEN=... evbreath`

Put HTTPS in front of it (for example Caddy: `caddy reverse-proxy --from your.domain --to :8000`).

In the app: **Settings › EV Breath server** › enter `https://your.domain` and the app token › **Save & test**.

### Live mode

- On first start it downloads about a year of NSE daily files (price, delivery %, F&O OI, NIFTY). This takes a while.
- After that: filings every minute in market hours, and the day's files after 7 PM IST.
- **Fundamentals** for Multibagger DNA: fill `server/data_template/fundamentals_template.csv` (one row per
  company) and save it as `<EVB_DATA>/fundamentals.csv`. It is imported at start-up.

## 4. Connect Flattrade

1. In the Flattrade developer portal (wall.flattrade.in › Pi), create an API key with:
   - **Redirect URL:** `https://your.domain/callback/flattrade`
   - **Static IP:** your server's public IP
2. In the app: **Settings › Broker & API › Flattrade** › enter User ID, API key, API secret › **Save & log in**.
3. Approve on the Flattrade page. The token lasts for the day: log in again each morning.

Orders: the app sends a limit buy; once it fills, the server places a stop-loss-limit sell. Only LMT and SL-LMT
order types are used (SEBI / Flattrade API v2). Every order needs your confirmation, and the server re-checks
the safety gates, the no-chasing limit and the 1% risk limit before sending it. With no broker connected,
orders are simulated.

The other 34 brokers are listed in Settings and their keys are stored on your server; live order code for
them is not written yet. Flattrade's API details are from its Pi API: verify them against pi.flattrade.in/docs
before trading real money.

## 5. Rules

All numbers live in `server/rules/v1.0.json` (copied to `<EVB_DATA>/rules/` on first start). Change them in
the app (**Settings › Stock selection rules**): move a slider → **Backtest changes** → **Save new version**.
A change cannot go live without a backtest, and every version is kept in the change log.

Run the rule tests: `cd server && python -m unittest discover -s tests -v`

## 6. Notes

- **Signed release APK:** create a keystore, add it as GitHub secrets, and change `assembleDebug` to
  `assembleRelease` with signing config.
- **Fonts:** the app uses Inter from Google Fonts when online, and the phone's font offline.
- **Data use:** NSE/BSE files and broker data are for your own use. Showing live prices to other people needs
  a licensed data vendor.
- EV Breath is an information tool, not investment advice. You confirm every trade.

## Layout

```
app/                 Android app (Capacitor 7)
  www/               the app itself (HTML, CSS, JavaScript; no build step)
  assets/            icon and splash source images
server/
  evbreath/          rule engine, data jobs, broker adapter, API
  rules/v1.0.json    rulebook numbers
  tests/             rule tests
.github/workflows/   APK build and server tests
```
