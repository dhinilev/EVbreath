"""Start the EV Breath server:  python run.py   (env: EVB_MODE=demo|live, EVB_APP_TOKEN, EVB_PORT)"""
import os
import sys

import uvicorn

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

if __name__ == "__main__":
    uvicorn.run("evbreath.api:app", host="0.0.0.0", port=int(os.environ.get("EVB_PORT", "8000")))
