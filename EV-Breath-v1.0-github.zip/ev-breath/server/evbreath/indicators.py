"""Plain-Python technical indicators. Every function takes oldest-first lists.

A "bar" is a dict with keys: date, open, high, low, close, volume.
"""
from __future__ import annotations

from typing import Optional, Sequence


def sma(xs: Sequence[float], n: int) -> Optional[float]:
    if n <= 0 or len(xs) < n:
        return None
    return sum(xs[-n:]) / n


def sma_series(xs: Sequence[float], n: int) -> list[Optional[float]]:
    out: list[Optional[float]] = []
    run = 0.0
    for i, x in enumerate(xs):
        run += x
        if i >= n:
            run -= xs[i - n]
        out.append(run / n if i >= n - 1 else None)
    return out


def ema_series(xs: Sequence[float], n: int) -> list[Optional[float]]:
    out: list[Optional[float]] = []
    k = 2 / (n + 1)
    e: Optional[float] = None
    for i, x in enumerate(xs):
        if i < n - 1:
            out.append(None)
            continue
        if e is None:
            e = sum(xs[i - n + 1:i + 1]) / n
        else:
            e = x * k + e * (1 - k)
        out.append(e)
    return out


def ema(xs: Sequence[float], n: int) -> Optional[float]:
    s = ema_series(xs, n)
    return s[-1] if s else None


def true_ranges(bars: Sequence[dict]) -> list[float]:
    trs = []
    for i, b in enumerate(bars):
        if i == 0:
            trs.append(b["high"] - b["low"])
        else:
            pc = bars[i - 1]["close"]
            trs.append(max(b["high"] - b["low"], abs(b["high"] - pc), abs(b["low"] - pc)))
    return trs


def atr_series(bars: Sequence[dict], n: int = 14) -> list[Optional[float]]:
    """Wilder's ATR."""
    trs = true_ranges(bars)
    out: list[Optional[float]] = []
    a: Optional[float] = None
    for i, tr in enumerate(trs):
        if i < n - 1:
            out.append(None)
            continue
        if a is None:
            a = sum(trs[i - n + 1:i + 1]) / n
        else:
            a = (a * (n - 1) + tr) / n
        out.append(a)
    return out


def atr(bars: Sequence[dict], n: int = 14) -> Optional[float]:
    s = atr_series(bars, n)
    return s[-1] if s else None


def bb_width_series(closes: Sequence[float], n: int = 20, k: float = 2.0) -> list[Optional[float]]:
    """Bollinger Band width as a fraction of the middle band."""
    out: list[Optional[float]] = []
    for i in range(len(closes)):
        if i < n - 1:
            out.append(None)
            continue
        w = closes[i - n + 1:i + 1]
        m = sum(w) / n
        sd = (sum((x - m) ** 2 for x in w) / n) ** 0.5
        out.append((2 * k * sd) / m if m else None)
    return out


def pct_change(a: float, b: float) -> float:
    """Percent change from b to a."""
    return (a / b - 1) * 100 if b else 0.0


def ret(closes: Sequence[float], n: int) -> Optional[float]:
    if len(closes) <= n:
        return None
    return pct_change(closes[-1], closes[-1 - n])


def swing_lows(bars: Sequence[dict], k: int = 3) -> list[tuple[int, float]]:
    """Pivot lows: a low lower than the k bars on each side."""
    out = []
    for i in range(k, len(bars) - k):
        lo = bars[i]["low"]
        if all(lo < bars[j]["low"] for j in range(i - k, i)) and all(lo <= bars[j]["low"] for j in range(i + 1, i + k + 1)):
            out.append((i, lo))
    return out


def percentile_of(value: float, population: Sequence[float]) -> float:
    """Share (0-100) of the population at or below value."""
    pop = [p for p in population if p is not None]
    if not pop:
        return 50.0
    return 100.0 * sum(1 for p in pop if p <= value) / len(pop)


def high_of(bars: Sequence[dict], n: int) -> float:
    return max(b["high"] for b in bars[-n:])


def low_of(bars: Sequence[dict], n: int) -> float:
    return min(b["low"] for b in bars[-n:])


def avg_volume(bars: Sequence[dict], n: int, skip_last: int = 0) -> Optional[float]:
    seg = bars[-(n + skip_last):len(bars) - skip_last] if skip_last else bars[-n:]
    if len(seg) < n:
        return None
    return sum(b["volume"] for b in seg) / n


def is_inside_day(bars: Sequence[dict]) -> bool:
    if len(bars) < 2:
        return False
    a, b = bars[-2], bars[-1]
    return b["high"] <= a["high"] and b["low"] >= a["low"]


def is_nr7(bars: Sequence[dict]) -> bool:
    if len(bars) < 7:
        return False
    ranges = [b["high"] - b["low"] for b in bars[-7:]]
    return ranges[-1] == min(ranges)
