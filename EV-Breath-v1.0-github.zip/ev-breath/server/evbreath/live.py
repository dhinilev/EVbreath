"""Live feed manager: feeds in priority order, automatic failover, and fan-out to the app (SSE)."""
from __future__ import annotations

import queue
import random
import threading
import time
from typing import Callable, Optional


class Feed:
    """A feed has a name, a start(on_tick, stop_event) loop, and reports health through ticks."""

    def __init__(self, fid: str, name: str, kind: str, runner: Optional[Callable] = None):
        self.id, self.name, self.kind = fid, name, kind
        self.runner = runner
        self.last_tick = 0.0
        self.ticks = 0
        self.error: Optional[str] = None
        self.forced_down = False


class DemoTicker:
    """Moves demo prices a little every second so the app shows live updates without a broker."""

    def __init__(self, source, symbols: list[str]):
        self.source = source
        self.symbols = symbols
        self.rng = random.Random(7)

    def __call__(self, on_tick, stop_event: threading.Event):
        while not stop_event.is_set():
            sym = self.rng.choice(self.symbols)
            s = next(x for x in self.source.universe() if x["symbol"] == sym)
            ltp = round(s["bars"][-1]["close"] * (1 + self.rng.gauss(0, 0.0008)), 2)
            on_tick({"symbol": sym, "ltp": ltp, "ts": time.time()})
            stop_event.wait(0.25)


class FeedManager:
    def __init__(self, feeds: list[Feed], on_price: Callable[[str, float], None], stale_after: float = 5.0):
        self.feeds = feeds
        self.on_price = on_price
        self.stale_after = stale_after
        self.active: Optional[Feed] = None
        self.subscribers: list[queue.Queue] = []
        self.lock = threading.Lock()
        self._stops: dict[str, threading.Event] = {}
        self.last_prices: dict[str, float] = {}

    # ------------------------------------------------------------ fan-out
    def subscribe(self) -> queue.Queue:
        q: queue.Queue = queue.Queue(maxsize=500)
        with self.lock:
            self.subscribers.append(q)
        return q

    def unsubscribe(self, q):
        with self.lock:
            if q in self.subscribers:
                self.subscribers.remove(q)

    def publish(self, event: str, data: dict):
        with self.lock:
            subs = list(self.subscribers)
        for q in subs:
            try:
                q.put_nowait({"event": event, "data": data})
            except queue.Full:
                pass

    # ------------------------------------------------------------ feeds
    def _tick(self, feed: Feed, t: dict):
        if feed.forced_down:
            return
        if t.get("error"):
            feed.error = t["error"]
            return
        feed.last_tick = t["ts"]
        feed.ticks += 1
        feed.error = None
        if self.active is feed and t.get("symbol") and t.get("ltp"):
            self.last_prices[t["symbol"]] = t["ltp"]
            self.on_price(t["symbol"], t["ltp"])
            self.publish("tick", {"symbol": t["symbol"], "ltp": t["ltp"], "feed": feed.id})

    def start(self):
        for f in self.feeds:
            if f.runner:
                ev = threading.Event()
                self._stops[f.id] = ev
                threading.Thread(target=f.runner, args=(lambda t, f=f: self._tick(f, t), ev), daemon=True).start()
        threading.Thread(target=self._watch, daemon=True).start()

    def _healthy(self, f: Feed) -> bool:
        return not f.forced_down and f.runner is not None and time.time() - f.last_tick < self.stale_after

    def _watch(self):
        while True:
            pick = next((f for f in self.feeds if self._healthy(f)), None)
            if pick is not self.active:
                old = self.active.id if self.active else None
                self.active = pick
                self.publish("feed", {"active": pick.id if pick else None, "previous": old})
            time.sleep(1)

    def force_down(self, fid: str, down: bool = True):
        for f in self.feeds:
            if f.id == fid:
                f.forced_down = down

    def status(self) -> dict:
        now = time.time()
        return {"active": self.active.id if self.active else None,
                "feeds": [{"id": f.id, "name": f.name, "kind": f.kind,
                           "state": "ACTIVE" if f is self.active else ("DOWN" if f.forced_down or (f.runner and not self._healthy(f))
                                                                      else ("STANDBY" if f.runner else "NOT CONNECTED")),
                           "ticks": f.ticks, "age_s": round(now - f.last_tick, 1) if f.last_tick else None,
                           "error": f.error} for f in self.feeds]}
