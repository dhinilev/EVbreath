"""SQLite store for daily bars, delivery, OI, company data and filings."""
from __future__ import annotations

import json
import sqlite3
import threading
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS bars (symbol TEXT, date TEXT, open REAL, high REAL, low REAL, close REAL,
  volume INTEGER, delivery_pct REAL, oi INTEGER, PRIMARY KEY (symbol, date));
CREATE TABLE IF NOT EXISTS company (symbol TEXT PRIMARY KEY, data TEXT);
CREATE TABLE IF NOT EXISTS filings (id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT, datetime TEXT,
  subject TEXT, source TEXT, data TEXT, UNIQUE(symbol, datetime, subject));
CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT);
"""


class Store:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.Lock()
        with self._conn() as c:
            c.executescript(SCHEMA)

    def _conn(self):
        return sqlite3.connect(self.path)

    def add_bars(self, rows: list[dict]):
        with self.lock, self._conn() as c:
            c.executemany("INSERT OR REPLACE INTO bars VALUES (?,?,?,?,?,?,?,?,?)",
                          [(r["symbol"], r["date"], r["open"], r["high"], r["low"], r["close"], r["volume"],
                            r.get("delivery_pct"), r.get("oi")) for r in rows])

    def set_oi(self, date: str, oi: dict[str, int]):
        with self.lock, self._conn() as c:
            c.executemany("UPDATE bars SET oi=? WHERE symbol=? AND date=?", [(v, k, date) for k, v in oi.items()])

    def set_company(self, symbol: str, data: dict):
        with self.lock, self._conn() as c:
            old = c.execute("SELECT data FROM company WHERE symbol=?", (symbol,)).fetchone()
            merged = {**(json.loads(old[0]) if old else {}), **data}
            c.execute("INSERT OR REPLACE INTO company VALUES (?,?)", (symbol, json.dumps(merged)))

    def add_filings(self, items: list[dict]) -> list[dict]:
        new = []
        with self.lock, self._conn() as c:
            for a in items:
                cur = c.execute("INSERT OR IGNORE INTO filings (symbol, datetime, subject, source, data) VALUES (?,?,?,?,?)",
                                (a.get("symbol"), a.get("datetime") or a.get("time"), a.get("subject"), a.get("source"),
                                 json.dumps(a)))
                if cur.rowcount:
                    new.append(a)
        return new

    def kv_get(self, k: str, default=None):
        with self._conn() as c:
            row = c.execute("SELECT v FROM kv WHERE k=?", (k,)).fetchone()
        return json.loads(row[0]) if row else default

    def kv_set(self, k: str, v):
        with self.lock, self._conn() as c:
            c.execute("INSERT OR REPLACE INTO kv VALUES (?,?)", (k, json.dumps(v)))

    def load_universe(self, min_days: int = 220) -> list[dict]:
        with self._conn() as c:
            syms = [r[0] for r in c.execute("SELECT symbol FROM bars GROUP BY symbol HAVING COUNT(*) >= ?", (min_days,))]
            comp = {r[0]: json.loads(r[1]) for r in c.execute("SELECT symbol, data FROM company")}
            out = []
            for sym in syms:
                rows = c.execute("SELECT date, open, high, low, close, volume, delivery_pct, oi FROM bars "
                                 "WHERE symbol=? ORDER BY date", (sym,)).fetchall()[-320:]
                info = comp.get(sym, {})
                bars = [{"date": r[0], "open": r[1], "high": r[2], "low": r[3], "close": r[4], "volume": r[5]} for r in rows]
                oi = [r[7] for r in rows]
                out.append({"symbol": sym, "name": info.get("name", sym), "sector": info.get("sector", "Other"),
                            "fno": any(oi), "bars": bars, "delivery": [r[6] or 0 for r in rows],
                            "oi": oi if any(oi) else None, "mcap_cr": info.get("mcap_cr", 0),
                            "pledge_pct": info.get("pledge_pct", 0), "promoter_pct": info.get("promoter_pct", 0),
                            "promoter_change_4q": info.get("promoter_change_4q", 0), "asm": info.get("asm", False),
                            "fo_ban": info.get("fo_ban", False), "circuit_recent": info.get("circuit_recent", False),
                            "results_in_days": info.get("results_in_days"), "bulk_buy_5d": info.get("bulk_buy_5d", False),
                            "fundamentals": info.get("fundamentals", {}), "buzz": info.get("buzz", {}),
                            "filings": info.get("filings", [])})
            return out

    def load_index(self, name: str):
        return self.kv_get(f"index:{name}")
