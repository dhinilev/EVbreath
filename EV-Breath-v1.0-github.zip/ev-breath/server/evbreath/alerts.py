"""Buzz Alert pipeline: filing -> type -> material? -> Substance -> gates -> Buy state."""
from __future__ import annotations

import re
from typing import Optional

KINDS = [
    ("Order", r"\b(order|contract|letter of award|loa|work order|purchase order)\b"),
    ("Results", r"\b(financial results|quarterly results|results for the quarter)\b"),
    ("Promoter buy", r"\b(acquisition of shares by promoter|promoter.*(acqui|purchase|buy))\b"),
    ("Bulk deal", r"\b(bulk deal|block deal)\b"),
    ("Capex", r"\b(capex|capacity expansion|new plant|commission(ed|ing))\b"),
    ("Pledge", r"\b(pledge|encumbrance)\b"),
    ("Debt", r"\b(term loan|borrowing|ncd|debentures|credit facility)\b"),
    ("Rating", r"\b(credit rating|rating)\b"),
    ("Results date", r"\b(board meeting).*\b(results|financial)\b"),
]
NEGATIVE = {"Pledge", "Debt"}


def classify(subject: str) -> str:
    text = subject.lower()
    for kind, pat in KINDS:
        if re.search(pat, text):
            return kind
    return "Other"


def is_material(filing: dict, stock: dict, rules: dict) -> bool:
    a = rules["alerts"]
    kind = filing.get("kind") or classify(filing.get("subject", ""))
    ttm_sales = (stock.get("fundamentals") or {}).get("ttm_sales_cr") or 0
    if kind == "Order" and filing.get("value_cr") and ttm_sales:
        return filing["value_cr"] / ttm_sales * 100 >= a["order_to_sales_pct"]
    if kind == "Results" and filing.get("profit_yoy_pct") is not None:
        return filing["profit_yoy_pct"] >= a["profit_yoy_pct"]
    if kind == "Promoter buy" and filing.get("promoter_buy_pct") is not None:
        return filing["promoter_buy_pct"] >= a["promoter_buy_pct"]
    if kind in ("Bulk deal", "Capex"):
        return bool(filing.get("value_cr"))
    return False


def decide(filing: dict, stock: dict, substance: int, gates: dict, rules: dict,
           sent_today: Optional[set] = None) -> dict:
    """Follow the rulebook's Buzz Alert flow and say what the app should show."""
    a = rules["alerts"]
    kind = filing.get("kind") or classify(filing.get("subject", ""))
    material = is_material({**filing, "kind": kind}, stock, rules)
    base = {"symbol": stock["symbol"], "kind": kind, "subject": filing.get("subject", ""),
            "time": filing.get("time"), "material": material, "substance": substance}
    if sent_today is not None and stock["symbol"] in sent_today:
        return {**base, "push": False, "buy": "none", "reason": "Already alerted today"}
    if not material:
        return {**base, "push": False, "buy": "none", "reason": "Logged, no alert (not material)"}
    if substance < a["min_substance"]:
        return {**base, "push": False, "buy": "none", "reason": "Logged, no alert (low substance)"}
    if not gates["pass"] or gates.get("surveillance"):
        return {**base, "push": True, "buy": "none", "reason": "Alert, no Buy (gate failed or ASM)"}
    if kind in NEGATIVE:
        return {**base, "push": True, "buy": "none", "reason": "Negative filing, no Buy"}
    if substance >= a["buy_substance"]:
        return {**base, "push": True, "buy": "buy", "reason": "Alert + Buy button"}
    return {**base, "push": True, "buy": "risky", "reason": "Alert + Buy · risky (extra confirm)"}
