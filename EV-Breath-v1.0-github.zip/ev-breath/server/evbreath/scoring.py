"""EV Breath rule engine. Every number comes from the active rules file.

A stock is a dict:
  symbol, name, sector, fno (bool), bars (oldest first: date/open/high/low/close/volume),
  delivery (list of delivery %, aligned with bars), oi (list aligned with bars, F&O only),
  mcap_cr, pledge_pct, promoter_pct, promoter_change_4q, asm (bool), fo_ban (bool),
  circuit_recent (bool), results_in_days (int or None), bulk_buy_5d (bool),
  fundamentals: sales_cagr3, profit_cagr3, sales_yoy_q (list, latest first), roce, roce3y,
                de, icr, pe, sector_pe
  buzz: news_ratio, social_ratio (mentions vs 30-day normal)
  filings: list of {date, kind, subject, material (bool)}
"""
from __future__ import annotations

import math
from typing import Optional

from . import indicators as ind


# ---------------------------------------------------------------- helpers

def closes(s: dict) -> list[float]:
    return [b["close"] for b in s["bars"]]


def last_close(s: dict) -> float:
    return s["bars"][-1]["close"]


def turnover_cr(s: dict, n: int = 20) -> float:
    seg = s["bars"][-n:]
    return sum(b["close"] * b["volume"] for b in seg) / len(seg) / 1e7 if seg else 0.0


def _clamp(x: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, x))


# ---------------------------------------------------------------- gates

def check_gates(s: dict, rules: dict, kind: str = "main") -> dict:
    """Return {'pass': bool, 'fails': [...], 'entry_blocked': bool}."""
    g = rules["gates"][kind]
    price = last_close(s)
    fails = []
    if kind == "penny":
        if price > g["max_price"]:
            fails.append(f"Price above ₹{g['max_price']}")
    elif price < g["min_price"]:
        fails.append(f"Price below ₹{g['min_price']}")
    if turnover_cr(s) < g["min_turnover_cr"]:
        fails.append(f"Turnover below ₹{g['min_turnover_cr']} cr")
    if s.get("pledge_pct", 0) > g["max_pledge_pct"]:
        fails.append(f"Pledge above {g['max_pledge_pct']}%")
    surveillance = bool(s.get("asm")) or bool(s.get("fo_ban"))
    if surveillance and kind != "penny":
        fails.append("On ASM/GSM list or F&O ban")
    if s.get("circuit_recent") and kind != "penny":
        fails.append("Hit a circuit in the last 3 days")
    rid = s.get("results_in_days")
    entry_blocked = rid is not None and 0 <= rid <= rules["gates"]["results_blackout_days"]
    return {"pass": not fails, "fails": fails, "entry_blocked": entry_blocked, "surveillance": surveillance}


# ---------------------------------------------------------------- market filter

def breath_meter(universe: list[dict], index_bars: list[dict], vix: float, rules: dict) -> dict:
    """0-100 market calm score from breadth, NIFTY trend and VIX."""
    above = adv = dec = 0
    counted = 0
    for s in universe:
        cs = closes(s)
        m50 = ind.sma(cs, 50)
        if m50 is None or len(cs) < 2:
            continue
        counted += 1
        above += cs[-1] > m50
        if cs[-1] > cs[-2]:
            adv += 1
        elif cs[-1] < cs[-2]:
            dec += 1
    pct_above = 100 * above / counted if counted else 50
    ad_ratio = adv / dec if dec else float(adv or 1)
    ic = [b["close"] for b in index_bars]
    i50 = ind.sma(ic, 50) or ic[-1]
    nifty_gap = ind.pct_change(ic[-1], i50)
    s_breadth = pct_above
    s_ad = _clamp((ad_ratio - 0.5) / 1.5 * 100)
    s_trend = _clamp((nifty_gap + 5) / 10 * 100)
    s_vix = _clamp((25 - vix) / 15 * 100)
    score = round(0.40 * s_breadth + 0.25 * s_ad + 0.20 * s_trend + 0.15 * s_vix)
    m = rules["market"]
    panic = score < m["panic_below"] or (nifty_gap < 0 and ad_ratio < 0.8)
    euphoria = score > m["euphoria_above"]
    zone = "Panic" if panic else ("Euphoria" if euphoria else "Calm")
    return {"score": score, "zone": zone, "pct_above_50dma": round(pct_above, 1), "adv": adv, "dec": dec,
            "ad_ratio": round(ad_ratio, 2), "nifty_vs_50dma_pct": round(nifty_gap, 2), "vix": vix}


# ---------------------------------------------------------------- breath score

def _entry_setup(s: dict, r: dict) -> dict:
    bars = s["bars"]
    cs = closes(s)
    price = cs[-1]
    e20 = ind.ema(cs, 20)
    avg20 = ind.avg_volume(bars, 20, skip_last=1)
    out = {"points": 0, "type": None, "entry": None, "note": "No setup"}
    if e20 is None or avg20 is None or len(bars) < 60:
        return out
    # Pullback: a 5%+ rise in the last 20 sessions, price resting just above the 20 EMA,
    # quiet volume on the dip, then a turn-up day on rising volume.
    rise = ind.pct_change(max(cs[-20:]), cs[-21])
    in_band = e20 <= price <= e20 * (1 + r["pullback_band_pct"] / 100)
    dip_vol = sum(b["volume"] for b in bars[-4:-1]) / 3
    turn = cs[-1] > cs[-2] and bars[-1]["volume"] > bars[-2]["volume"]
    if rise >= r["pullback_rise_pct"] and in_band and dip_vol < r["dip_volume_ratio"] * avg20 and turn:
        return {"points": 20, "type": "Pullback", "entry": round(e20, 2), "note": "Pullback to 20 EMA, turning up"}
    # Base breakout: a base of 15+ sessions inside a 12% range, closed above on volume.
    best = None
    for n in range(r["base_min_sessions"], 61):
        seg = bars[-n - 1:-1]
        if len(seg) < n:
            break
        hi = max(b["high"] for b in seg)
        lo = min(b["low"] for b in seg)
        if (hi - lo) / lo * 100 <= r["base_range_pct"]:
            best = (n, hi)
    if best:
        n, hi = best
        if price > hi and bars[-1]["volume"] >= r["breakout_volume_ratio"] * avg20:
            return {"points": 20, "type": "Breakout", "entry": round(hi, 2), "note": f"{n}-session base breakout"}
        out = {"points": 0, "type": "Base", "entry": round(hi, 2), "note": f"Base forming · {n} sessions"}
    # No chasing: far above the entry point scores nothing.
    if price > e20 * (1 + r["no_chase_pct"] / 100) and out["type"] is None:
        out["note"] = f"{ind.pct_change(price, e20):.1f}% above 20 EMA · wait for pullback"
        out["entry"] = round(e20, 2)
    return out


def oi_signal(s: dict, n: int = 1) -> Optional[str]:
    """LB long buildup, SB short buildup, SC short covering, LU long unwinding."""
    oi = s.get("oi") or []
    if len(oi) < n + 1 or len(s["bars"]) < n + 1:
        return None
    dp = s["bars"][-1]["close"] - s["bars"][-1 - n]["close"]
    doi = oi[-1] - oi[-1 - n]
    if dp >= 0 and doi > 0:
        return "LB"
    if dp < 0 and doi > 0:
        return "SB"
    if dp >= 0 and doi <= 0:
        return "SC"
    return "LU"


def breath_score(s: dict, ctx: dict, rules: dict) -> dict:
    r = rules["breath"]
    bars = s["bars"]
    cs = closes(s)
    price = cs[-1]
    parts = {}
    # Trend (25)
    m50s = ind.sma_series(cs, 50)
    m200s = ind.sma_series(cs, 200)
    m50, m200 = m50s[-1], m200s[-1]
    t = 0
    t += 5 if m50 and price > m50 else 0
    t += 5 if m50 and m200 and m50 > m200 else 0
    t += 5 if m200 and len(m200s) > 20 and m200s[-21] and m200 > m200s[-21] else 0
    hi52 = ind.high_of(bars, min(250, len(bars)))
    t += 5 if price >= hi52 * (1 - r["near_52wh_pct"] / 100) else 0
    lows = ind.swing_lows(bars[-120:])
    t += 5 if len(lows) >= 2 and lows[-1][1] > lows[-2][1] else 0
    parts["trend"] = t
    # Relative strength (20)
    rs_pop = list(ctx.get("rs_returns", {}).values())
    my = ind.ret(cs, 63) or 0
    pctl = ind.percentile_of(my, rs_pop)
    rs = 15 if pctl >= 90 else 10 if pctl >= 80 else 5 if pctl >= 70 else 0
    rs += 5 if ctx.get("sector_above_50", {}).get(s.get("sector"), False) else 0
    parts["rs"] = rs
    # Participation (20)
    deliv = s.get("delivery") or []
    p = 0
    if len(deliv) >= 20:
        avg_d = sum(deliv[-20:]) / 20
        up_d = [deliv[i] for i in range(len(bars) - 10, len(bars)) if bars[i]["close"] > bars[i - 1]["close"]]
        if up_d and avg_d and (sum(up_d) / len(up_d)) >= r["delivery_ratio"] * avg_d:
            p += 8
    upv = sum(bars[i]["volume"] for i in range(len(bars) - 10, len(bars)) if bars[i]["close"] > bars[i - 1]["close"])
    dnv = sum(bars[i]["volume"] for i in range(len(bars) - 10, len(bars)) if bars[i]["close"] < bars[i - 1]["close"])
    p += 6 if upv > dnv else 0
    avg20 = ind.avg_volume(bars, 20, skip_last=1) or 1
    p += 6 if bars[-1]["volume"] >= r["turn_volume_ratio"] * avg20 and price > cs[-2] else 0
    parts["participation"] = p
    # OI confirmation (15, F&O only)
    if s.get("fno") and len(s.get("oi") or []) >= 6:
        sig = [oi_signal({"bars": bars[:len(bars) - k], "oi": s["oi"][:len(s["oi"]) - k]}) for k in range(5)]
        o = 10 if sum(1 for x in sig if x == "LB") >= 3 else 0
        o += 5 if "SB" not in sig[:2] else 0
        parts["oi"] = o
    else:
        parts["oi"] = None
    # Entry setup (20)
    setup = _entry_setup(s, r)
    parts["entry"] = setup["points"]
    raw = sum(v for v in parts.values() if v is not None)
    score = raw if parts["oi"] is not None else round(raw * 100 / 85)
    return {"score": int(round(score)), "parts": parts, "setup": setup, "oi_signal": oi_signal(s)}


def breath_verdict(score: int, gates: dict, meter: dict, rules: dict) -> str:
    r = rules["breath"]
    if not gates["pass"]:
        return "Avoid"
    if score >= r["calm_from"]:
        if meter["zone"] == "Panic" or gates["entry_blocked"]:
            return "Wait for the Breath"
        return "Calm Buy Zone"
    if score >= r["wait_from"]:
        return "Wait for the Breath"
    return "Not yet"


# ---------------------------------------------------------------- multibagger DNA

def dna(s: dict, rules: dict) -> dict:
    d = rules["dna"]
    f = s.get("fundamentals") or {}
    cs = closes(s)
    m200s = ind.sma_series(cs, 200)
    m200 = m200s[-1]
    yoy = f.get("sales_yoy_q") or []
    tests = {
        "G": f.get("sales_cagr3", 0) >= d["growth_pct"] and f.get("profit_cagr3", 0) >= d["growth_pct"]
             and len(yoy) >= 2 and yoy[0] > 0 and yoy[1] > 0,
        "R": f.get("roce", 0) >= d["roce_pct"] and f.get("roce3y", 0) >= d["roce_3y_pct"],
        "D": f.get("de", 9) <= d["max_debt_equity"] and f.get("icr", 0) >= d["min_interest_cover"],
        "P": s.get("promoter_pct", 0) >= d["min_promoter_pct"] and s.get("promoter_change_4q", 0) >= -d["max_promoter_cut_pct"],
        "S": d["mcap_min_cr"] <= s.get("mcap_cr", 0) <= d["mcap_max_cr"],
        "T": bool(m200) and cs[-1] > m200 and len(m200s) > 21 and bool(m200s[-21]) and m200 > m200s[-21],
    }
    passed = sum(1 for v in tests.values() if v)
    stage = None
    if passed >= d["tests_to_pass"]:
        hi52 = ind.high_of(s["bars"], min(250, len(s["bars"])))
        w = d["early_window_days"]
        crossed = any(m200s[i] and m200s[i - 1] and cs[i] > m200s[i] and cs[i - 1] <= m200s[i - 1]
                      for i in range(len(cs) - w, len(cs)) if i > 0)
        seg = s["bars"][-d["base_min_days"]:]
        rng = (max(b["high"] for b in seg) - min(b["low"] for b in seg)) / min(b["low"] for b in seg) * 100
        if cs[-1] >= hi52 * 0.99:
            stage = "Trending"
        elif crossed:
            stage = "Early"
        elif rng <= d["base_range_pct"]:
            stage = "Base"
        else:
            stage = "Early"
    warn = None
    if f.get("pe") and f.get("sector_pe") and f["pe"] > d["pe_warning_factor"] * f["sector_pe"]:
        warn = "Valuation stretched vs sector"
    return {"tests": tests, "passed": passed, "stage": stage, "warning": warn}


# ---------------------------------------------------------------- blast fuse

def fuse(s: dict, rules: dict) -> dict:
    f = rules["fuse"]
    bars = s["bars"]
    cs = closes(s)
    parts = {}
    bbw = [x for x in ind.bb_width_series(cs, 20, 2)[-120:] if x is not None]
    squeeze = 0
    tight = False
    if bbw:
        cur = bbw[-1]
        if ind.percentile_of(cur, bbw) <= f["bb_low_pct"]:
            squeeze += 15
            tight = True
    atrs = [x for x in ind.atr_series(bars, 14)[-60:] if x is not None]
    if atrs and atrs[-1] <= max(atrs) * (1 - f["atr_drop_pct"] / 100):
        squeeze += 10
    if ind.is_nr7(bars) or ind.is_inside_day(bars):
        squeeze += 5
    parts["squeeze"] = squeeze
    v5 = ind.avg_volume(bars, 5) or 0
    v50 = ind.avg_volume(bars, 50) or 1
    parts["volume"] = 20 if v5 >= f["volume_pickup_ratio"] * v50 and (tight or squeeze >= 10) else 0
    acc = 0
    deliv = s.get("delivery") or []
    if len(deliv) >= 20 and sum(deliv[-5:]) / 5 >= f["delivery_ratio"] * (sum(deliv[-20:]) / 20):
        acc += 10
    oi = s.get("oi") or []
    if len(oi) >= 6 and oi[-6] and (oi[-1] / oi[-6] - 1) > 0.05 and abs(ind.pct_change(cs[-1], cs[-6])) < 2:
        acc += 10
    elif not s.get("fno") and s.get("bulk_buy_5d"):
        acc += 10
    parts["accumulation"] = acc
    rng_hi = ind.high_of(bars[:-1], 20)
    hi52 = ind.high_of(bars, min(250, len(bars)))
    prox = 10 if cs[-1] >= rng_hi * (1 - f["near_range_pct"] / 100) else 0
    prox += 10 if cs[-1] >= hi52 * (1 - f["near_52wh_pct"] / 100) else 0
    parts["proximity"] = prox
    parts["catalyst"] = 10 if any(x.get("material") and x.get("age_days", 99) <= 5 for x in s.get("filings", [])) else 0
    score = sum(parts.values())
    avg20 = ind.avg_volume(bars, 20, skip_last=1) or 1
    ignited = cs[-1] > rng_hi and bars[-1]["volume"] >= f["ignite_volume_ratio"] * avg20
    status = "Ignited" if ignited else ("Fuse lit" if score >= f["lit_from"] else "Loose")
    tags = []
    if squeeze >= 15:
        tags.append("SQUEEZE")
    if v50:
        tags.append(f"VOL {v5 / v50:.1f}×")
    sig = oi_signal(s, 3)
    if sig:
        tags.append(sig)
    tags.append(f"{max(0.0, ind.pct_change(hi52, cs[-1])):.1f}% TO 52WH")
    return {"score": score, "parts": parts, "status": status, "range_high": round(rng_hi, 2), "tags": tags}


# ---------------------------------------------------------------- penny buzz

def penny(s: dict, rules: dict) -> dict:
    p = rules["penny"]
    bars = s["bars"]
    cs = closes(s)
    b = s.get("buzz") or {}
    avg20 = ind.avg_volume(bars, 20, skip_last=1) or 1
    vol_ratio = bars[-1]["volume"] / avg20
    move = abs(ind.pct_change(cs[-1], cs[-2]))
    buzz = (_clamp(25 * (b.get("news_ratio", 1) - 1) / 4, 0, 25)
            + _clamp(25 * (b.get("social_ratio", 1) - 1) / 4, 0, 25)
            + _clamp(25 * (vol_ratio - 1) / 4, 0, 25)
            + (25 if s.get("circuit_recent") else _clamp(25 * move / 10, 0, 25)))
    filings = [x for x in s.get("filings", []) if x.get("age_days", 99) <= 5]
    deliv = (s.get("delivery") or [0])[-1]
    f = s.get("fundamentals") or {}
    sub = 0
    sub += 25 if filings else 0
    sub += 20 if any(x.get("material") for x in filings) else 0
    sub += 15 if deliv >= 30 else 0
    sub += 10 if s.get("pledge_pct", 0) <= 10 else 0
    sub += 10 if s.get("promoter_pct", 0) >= 40 and s.get("promoter_change_4q", 0) >= 0 else 0
    sub += 10 if f.get("de", 9) <= 1 else 0
    sub += 10 if not s.get("asm") else 0
    buzz = int(round(buzz))
    if s.get("asm") or (buzz >= p["pump_buzz_from"] and sub < p["pump_substance_below"]):
        verdict = "Pump risk"
    elif sub >= p["real_from"]:
        verdict = "Real trigger"
    else:
        verdict = "Watch"
    flags = []
    if filings:
        flags.append(filings[0]["kind"].upper())
    else:
        flags.append("NO FILING")
    flags.append(f"DEL {deliv:.0f}%")
    if s.get("pledge_pct", 0) > 10:
        flags.append(f"PLEDGE {s['pledge_pct']:.0f}%")
    if s.get("asm"):
        flags.append("ASM")
    return {"buzz": buzz, "substance": sub, "verdict": verdict, "flags": flags}


# ---------------------------------------------------------------- plan

def plan(s: dict, entry: float, rules: dict, meter_zone: str = "Calm", kind: str = "main") -> dict:
    rk = rules["risk"]
    bars = s["bars"]
    a = ind.atr(bars, 14) or entry * 0.03
    lows = [lo for _, lo in ind.swing_lows(bars[-60:]) if lo < entry]
    stop_swing = lows[-1] * 0.995 if lows else entry - 3 * a
    stop = max(stop_swing, entry - rk["atr_stop_mult"] * a)   # whichever is nearer
    stop = min(stop, entry - rk["min_stop_atr"] * a)          # never closer than 1x ATR
    stop = round(stop, 2)
    risk_pct = rules["penny"]["risk_pct"] if kind == "penny" else rk["risk_pct"]
    if meter_zone == "Euphoria":
        risk_pct *= rules["market"]["euphoria_size_factor"]
    per_share = max(entry - stop, 0.01)
    qty = math.floor(rk["capital"] * risk_pct / 100 / per_share)
    cap_qty = math.floor(rk["capital"] * rk["max_position_pct"] / 100 / entry)
    qty = max(0, min(qty, cap_qty))
    return {"entry": round(entry, 2), "stop": stop, "qty": qty, "risk_rupees": round(qty * per_share),
            "risk_pct_of_capital": round(qty * per_share / rk["capital"] * 100, 2), "value": round(qty * entry)}
