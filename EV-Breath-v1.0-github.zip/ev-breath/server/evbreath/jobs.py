"""Live-mode background jobs: EOD files, filings poller, fundamentals import, Flattrade price feed."""
from __future__ import annotations

import csv
import datetime as dt
import re
import threading
import time
from pathlib import Path

from . import alerts as al
from .nse import NSEClient

IST = dt.timezone(dt.timedelta(hours=5, minutes=30))


def now_ist() -> dt.datetime:
    return dt.datetime.now(IST)


def log(*a):
    print(now_ist().strftime("%H:%M:%S"), "[jobs]", *a, flush=True)


# ---------------------------------------------------------------- fundamentals CSV
NUM = {"mcap_cr", "promoter_pct", "promoter_change_4q", "pledge_pct", "sales_cagr3", "profit_cagr3", "sales_yoy_q1",
       "sales_yoy_q2", "roce", "roce3y", "de", "icr", "pe", "sector_pe", "ttm_sales_cr", "results_in_days"}
FUND = {"sales_cagr3", "profit_cagr3", "roce", "roce3y", "de", "icr", "pe", "sector_pe", "ttm_sales_cr"}


def import_fundamentals(store, path: Path) -> int:
    """CSV with a header row; see data/fundamentals_template.csv. Returns rows imported."""
    if not path.exists():
        return 0
    n = 0
    with open(path, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            sym = (row.get("symbol") or "").strip().upper()
            if not sym:
                continue
            vals = {}
            for k, v in row.items():
                if k in NUM and v not in (None, ""):
                    try:
                        vals[k] = float(v)
                    except ValueError:
                        pass
            data = {k: vals[k] for k in ("mcap_cr", "promoter_pct", "promoter_change_4q", "pledge_pct") if k in vals}
            if "results_in_days" in vals:
                data["results_in_days"] = int(vals["results_in_days"])
            data["fundamentals"] = {k: vals[k] for k in FUND if k in vals}
            data["fundamentals"]["sales_yoy_q"] = [vals.get("sales_yoy_q1", 0), vals.get("sales_yoy_q2", 0)]
            for k in ("name", "sector"):
                if row.get(k):
                    data[k] = row[k].strip()
            store.set_company(sym, data)
            n += 1
    return n


# ---------------------------------------------------------------- EOD
def ingest_eod(store, client: NSEClient, day: dt.date) -> int:
    rows = client.equity_bhavcopy(day)
    store.add_bars(rows)
    try:
        store.set_oi(day.isoformat(), client.fo_bhavcopy(day))
    except Exception as e:
        log("F&O bhavcopy failed:", e)
    try:
        idx = client.index_close(day)
        bar = idx.get("Nifty 50")
        if bar and bar["close"]:
            hist = [b for b in (store.kv_get("index:NIFTY") or []) if b["date"] != bar["date"]] + [bar]
            store.kv_set("index:NIFTY", sorted(hist, key=lambda b: b["date"])[-400:])
    except Exception as e:
        log("index file failed:", e)
    try:
        ban = client.fo_ban()
        asm = client.asm_list()
        for sym in ban | asm:
            store.set_company(sym, {"fo_ban": sym in ban, "asm": sym in asm})
    except Exception as e:
        log("ASM / ban lists failed:", e)
    try:
        store.kv_set("flows", client.fii_dii())
    except Exception as e:
        log("FII/DII failed:", e)
    return len(rows)


def backfill(store, client: NSEClient, days: int = 330):
    """First run: download about a year of daily files (one per trading day, slowly)."""
    d = now_ist().date()
    done = 0
    while done < days:
        d -= dt.timedelta(days=1)
        if d.weekday() >= 5:
            continue
        try:
            ingest_eod(store, client, d)
            done += 1
        except Exception:
            done += 1  # holiday or missing file
    log("backfill complete")


# ---------------------------------------------------------------- filings
VALUE_RE = re.compile(r"(?:rs\.?|₹|inr)\s*([\d,]+(?:\.\d+)?)\s*(crore|cr|lakh|lac|million|mn)?", re.I)


def parse_value_cr(text: str):
    m = VALUE_RE.search(text or "")
    if not m:
        return None
    v = float(m.group(1).replace(",", ""))
    unit = (m.group(2) or "cr").lower()
    return v / 100 if unit in ("lakh", "lac") else v / 10 if unit in ("million", "mn") else v


def poll_filings(store, client: NSEClient) -> list[dict]:
    items = []
    try:
        items += client.announcements()
    except Exception as e:
        log("NSE announcements failed:", e)
    try:
        items += client.bse_announcements()
    except Exception as e:
        log("BSE announcements failed:", e)
    new = store.add_filings(items)
    for a in new:
        sym = (a.get("symbol") or "").upper()
        if not sym:
            continue
        text = f"{a.get('subject', '')} {a.get('detail', '')}"
        kind = al.classify(text)
        f = {"time": a.get("time"), "kind": kind, "subject": a.get("subject", "")[:200], "age_days": 0,
             "value_cr": parse_value_cr(text), "source": a.get("source")}
        comp = store.kv_get(f"filings:{sym}", [])
        store.kv_set(f"filings:{sym}", ([f] + comp)[:10])
    return new


# ---------------------------------------------------------------- scheduler
class LiveJobs:
    def __init__(self, store, source, engine, fundamentals_csv: Path):
        self.store, self.source, self.engine = store, source, engine
        self.client = NSEClient()
        self.fund_csv = fundamentals_csv

    def start(self):
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        n = import_fundamentals(self.store, self.fund_csv)
        log(f"imported fundamentals for {n} companies")
        if not self.store.load_universe(min_days=60):
            log("no history yet: starting backfill (takes a while)")
            backfill(self.store, self.client)
            self.source.refresh()
        last_eod = None
        while True:
            t = now_ist()
            try:
                if t.weekday() < 5 and (9, 0) <= (t.hour, t.minute) <= (20, 0):
                    if poll_filings(self.store, self.client):
                        self.source.refresh()
                        self.engine.recompute()
                if t.weekday() < 5 and t.hour >= 19 and last_eod != t.date():
                    rows = ingest_eod(self.store, self.client, t.date())
                    log(f"EOD ingested: {rows} rows")
                    last_eod = t.date()
                    self.source.refresh()
                    self.engine.recompute()
            except Exception as e:
                log("job error:", e)
            time.sleep(60)


def flattrade_feed(ft, source, symbols_getter):
    """Feed runner for FeedManager: resolves NSE tokens via SearchScrip, then streams ticks."""
    def run(on_tick, stop_event):
        tokens = {}
        while not stop_event.is_set() and not tokens:
            try:
                for sym in symbols_getter()[:250]:
                    hits = ft.search(sym)
                    hit = next((h for h in hits if h.get("tsym") == f"{sym}-EQ"), None)
                    if hit:
                        tokens[hit["token"]] = sym
            except Exception as e:
                on_tick({"error": f"token lookup failed: {e}", "ts": time.time()})
                stop_event.wait(30)
        rev = tokens

        def tick(t):
            if t.get("token") in rev and t.get("ltp"):
                on_tick({"symbol": rev[t["token"]], "ltp": t["ltp"], "ts": t["ts"]})
            elif t.get("error"):
                on_tick(t)
        ft.stream(list(tokens), tick, stop_event)
    return run
