"""Market data sources. DemoSource is built in; LiveSource merges EOD files with live broker ticks."""
from __future__ import annotations

from . import demo


class DemoSource:
    name = "Demo market (sample data)"

    def __init__(self):
        self._u = demo.universe()

    def universe(self):
        return self._u

    def index(self, name: str):
        return demo.NIFTY if name == "NIFTY" else demo.SENSEX

    def vix(self) -> float:
        return demo.VIX

    def flows(self) -> dict:
        return dict(demo.FLOWS)

    def apply_tick(self, symbol: str, ltp: float, volume: int | None = None):
        for s in self._u:
            if s["symbol"] == symbol:
                b = s["bars"][-1]
                b["close"] = ltp
                b["high"] = max(b["high"], ltp)
                b["low"] = min(b["low"], ltp)
                if volume:
                    b["volume"] = volume


class LiveSource(DemoSource):
    """EOD history from the local store (NSE bhavcopy jobs) with today's bar updated from live ticks.

    Falls back to the demo market for anything the store does not have yet, so the app never goes blank.
    """
    name = "Live (broker feed + NSE files)"

    def __init__(self, store):
        super().__init__()
        self.store = store
        self.refresh()

    def refresh(self):
        loaded = self.store.load_universe() if self.store else []
        if loaded:
            for s in loaded:
                s["filings"] = self.store.kv_get(f"filings:{s['symbol']}", []) or s.get("filings", [])
            self._u = loaded
        self._nifty = self.store.load_index("NIFTY") or demo.NIFTY
        self._sensex = self.store.load_index("SENSEX") or demo.SENSEX
        self._flows = self.store.kv_get("flows") or dict(demo.FLOWS)

    def index(self, name: str):
        return self._nifty if name == "NIFTY" else self._sensex

    def flows(self) -> dict:
        return self._flows
