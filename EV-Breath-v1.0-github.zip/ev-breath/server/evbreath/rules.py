"""Versioned rules store: one JSON file per version, a draft, and a change log."""
from __future__ import annotations

import copy
import datetime as dt
import json
import threading
from pathlib import Path

# Allowed ranges for every editable number (path -> (min, max)).
LIMITS = {
    "gates.main.min_price": (20, 500), "gates.main.min_turnover_cr": (1, 100), "gates.main.max_pledge_pct": (0, 50),
    "market.panic_below": (10, 50), "market.euphoria_above": (60, 95),
    "breath.calm_from": (50, 95), "breath.wait_from": (40, 80), "breath.no_chase_pct": (1, 15),
    "dna.tests_to_pass": (3, 6), "dna.growth_pct": (10, 40), "dna.roce_pct": (10, 30),
    "fuse.lit_from": (40, 90), "fuse.ignite_volume_ratio": (1, 3),
    "penny.real_from": (40, 90), "penny.pump_buzz_from": (50, 95), "penny.risk_pct": (0.1, 1),
    "risk.risk_pct": (0.25, 3), "risk.max_positions": (2, 15), "risk.time_stop_sessions": (5, 40),
    "risk.capital": (10000, 100000000),
}


def _get(d: dict, path: str):
    for k in path.split("."):
        d = d[k]
    return d


def _set(d: dict, path: str, value):
    keys = path.split(".")
    for k in keys[:-1]:
        d = d[k]
    d[keys[-1]] = value


class RuleStore:
    def __init__(self, folder: Path):
        self.folder = Path(folder)
        self.folder.mkdir(parents=True, exist_ok=True)
        self.lock = threading.Lock()
        self.log_path = self.folder / "changelog.json"
        self.live_path = self.folder / "live.txt"
        self.draft: dict | None = None
        self.draft_backtest: dict | None = None

    # -- versions
    def versions(self) -> list[str]:
        vs = [p.stem[1:] for p in self.folder.glob("v*.json")]
        return sorted(vs, key=lambda v: [int(x) for x in v.split(".")])

    def live_version(self) -> str:
        if self.live_path.exists():
            return self.live_path.read_text().strip()
        return self.versions()[-1]

    def load(self, version: str | None = None) -> dict:
        v = version or self.live_version()
        return json.loads((self.folder / f"v{v}.json").read_text())

    def live(self) -> dict:
        return self.load()

    # -- draft editing
    def set_values(self, changes: dict) -> dict:
        """changes: {"breath.calm_from": 78, ...}. Validates against LIMITS."""
        with self.lock:
            draft = copy.deepcopy(self.draft or self.live())
            for path, value in changes.items():
                if path not in LIMITS:
                    raise ValueError(f"{path} is not an editable rule")
                lo, hi = LIMITS[path]
                value = float(value)
                if not lo <= value <= hi:
                    raise ValueError(f"{path} must be between {lo} and {hi}")
                old = _get(draft, path)
                _set(draft, path, int(value) if isinstance(old, int) and value.is_integer() else value)
            self.draft = draft
            self.draft_backtest = None
            return self.diff()

    def diff(self) -> dict:
        if not self.draft:
            return {}
        live = self.live()
        return {p: {"old": _get(live, p), "new": _get(self.draft, p)} for p in LIMITS if _get(live, p) != _get(self.draft, p)}

    def reset(self):
        with self.lock:
            self.draft = None
            self.draft_backtest = None

    def publish(self, reason: str = "") -> str:
        """Save the backtested draft as the next version and make it live."""
        with self.lock:
            if not self.draft or not self.diff():
                raise ValueError("No changes to publish")
            if not self.draft_backtest:
                raise ValueError("Backtest the changes before publishing")
            major, minor = [int(x) for x in self.versions()[-1].split(".")]
            new_v = f"{major}.{minor + 1}"
            changes = self.diff()
            doc = {**self.draft, "version": new_v, "date": dt.date.today().isoformat(), "note": reason}
            (self.folder / f"v{new_v}.json").write_text(json.dumps(doc, indent=2))
            self.live_path.write_text(new_v)
            log = json.loads(self.log_path.read_text()) if self.log_path.exists() else []
            log.insert(0, {"date": doc["date"], "version": new_v, "changes": changes, "reason": reason,
                           "backtest": self.draft_backtest})
            self.log_path.write_text(json.dumps(log, indent=2))
            self.draft = None
            self.draft_backtest = None
            return new_v

    def restore(self, version: str):
        if version not in self.versions():
            raise ValueError(f"Unknown version {version}")
        self.live_path.write_text(version)

    def changelog(self) -> list:
        return json.loads(self.log_path.read_text()) if self.log_path.exists() else []
