"""Order manager: re-checks the rules before any order, then places the buy and its stop-loss.

Nothing is ever placed without an explicit confirm from the app.
"""
from __future__ import annotations

import threading
import time
from typing import Optional


class OrderRejected(Exception):
    pass


class OrderManager:
    def __init__(self, engine, broker_getter, journal_path=None):
        self.engine = engine
        self.broker_getter = broker_getter  # returns a connected broker adapter or None
        self.log: list[dict] = []
        self.lock = threading.Lock()

    def validate(self, req: dict) -> dict:
        """req: symbol, qty, limit, stop, product, confirm, risky_ack."""
        rules = self.engine.rules()
        row = self.engine.check(req["symbol"])
        if not row:
            raise OrderRejected("Unknown symbol")
        if not req.get("confirm"):
            raise OrderRejected("Order needs your confirmation")
        gates = row["gates_mb"] if row["dna"]["passed"] >= rules["dna"]["tests_to_pass"] and not row["is_penny"] else row["gates"]
        if not gates["pass"]:
            raise OrderRejected("Blocked by safety gates: " + "; ".join(gates["fails"]))
        if row["gates"].get("entry_blocked"):
            raise OrderRejected("Results are due within the blackout window")
        limit, stop, qty = float(req["limit"]), float(req["stop"]), int(req["qty"])
        if stop >= limit:
            raise OrderRejected("Stop-loss must be below the buy price")
        price = row["price"]
        if limit > price * (1 + rules["breath"]["no_chase_pct"] / 100):
            raise OrderRejected(f"Limit is more than {rules['breath']['no_chase_pct']}% above the live price (no chasing)")
        rk = rules["risk"]
        risk_pct = rules["penny"]["risk_pct"] if row["is_penny"] else rk["risk_pct"]
        if row.get("meter_zone") == "Euphoria":
            risk_pct *= rules["market"]["euphoria_size_factor"]
        max_risk = rk["capital"] * risk_pct / 100
        if qty * (limit - stop) > max_risk * 1.001:
            raise OrderRejected(f"Risk ₹{qty * (limit - stop):,.0f} is above the {risk_pct}% limit (₹{max_risk:,.0f})")
        if qty * limit > rk["capital"] * rk["max_position_pct"] / 100 * 1.001:
            raise OrderRejected(f"Position above {rk['max_position_pct']}% of capital")
        if row.get("_risky") and not req.get("risky_ack"):
            raise OrderRejected("This is a risky alert: confirm the extra warning")
        return {"row": row, "limit": limit, "stop": stop, "qty": qty, "product": req.get("product", "CNC")}

    def place(self, req: dict) -> dict:
        v = self.validate(req)
        broker = self.broker_getter()
        entry = {"time": time.strftime("%Y-%m-%d %H:%M:%S"), "symbol": req["symbol"], "qty": v["qty"],
                 "limit": v["limit"], "stop": v["stop"], "product": v["product"]}
        if broker is None:
            entry.update({"status": "SIMULATED", "order_no": f"SIM-{int(time.time())}",
                          "note": "No broker connected: order simulated, nothing sent"})
        else:
            tsym = req.get("tsym") or f"{req['symbol']}-EQ"
            res = broker.buy_with_stop(tsym, v["qty"], v["limit"], v["stop"], v["product"])
            entry.update({"status": "SENT", "order_no": res["entry_order"], "pending_stop": res["stop"]})
            threading.Thread(target=self._place_stop_after_fill, args=(broker, entry), daemon=True).start()
        with self.lock:
            self.log.insert(0, entry)
        return entry

    def _place_stop_after_fill(self, broker, entry: dict, timeout_s: int = 6 * 3600):
        """Poll the order book; once the buy is filled, place the SL-LMT sell."""
        t0 = time.time()
        while time.time() - t0 < timeout_s:
            try:
                book = broker.order_book()
                o = next((x for x in book if x.get("norenordno") == entry["order_no"]), None)
                if o and o.get("status") == "COMPLETE":
                    s = entry["pending_stop"]
                    entry["stop_order"] = broker.place_order(s["tsym"], s["qty"], s["price"], "S", s["product"],
                                                             "SL-LMT", s["trigger"])
                    entry["status"] = "FILLED · STOP PLACED"
                    return
                if o and o.get("status") in ("REJECTED", "CANCELED"):
                    entry["status"] = o["status"]
                    return
            except Exception as e:
                entry["error"] = str(e)
            time.sleep(5)
