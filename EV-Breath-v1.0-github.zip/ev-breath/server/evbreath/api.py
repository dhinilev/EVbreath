"""EV Breath server: REST + live stream (SSE) for the Android app."""
from __future__ import annotations

import asyncio
import contextlib
import copy
import json
import os
import threading
import time
from pathlib import Path

from sse_starlette.sse import EventSourceResponse
from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.middleware.cors import CORSMiddleware
from starlette.requests import Request
from starlette.responses import HTMLResponse, JSONResponse
from starlette.routing import Route

from . import backtest
from .brokers.flattrade import Flattrade, FlattradeError
from .brokers.registry import BROKERS, BY_ID
from .engine import Engine
from .live import DemoTicker, Feed, FeedManager
from .orders import OrderManager, OrderRejected
from .rules import RuleStore
from .sources import DemoSource, LiveSource
from .store import Store

ROOT = Path(__file__).resolve().parent.parent
DATA = Path(os.environ.get("EVB_DATA", ROOT / "data"))
APP_TOKEN = os.environ.get("EVB_APP_TOKEN", "")
MODE = os.environ.get("EVB_MODE", "demo")  # demo | live

DATA.mkdir(parents=True, exist_ok=True)
SECRETS = DATA / "secrets.json"
rules_store = RuleStore(DATA / "rules") if (DATA / "rules").exists() else None
if rules_store is None:
    (DATA / "rules").mkdir(parents=True, exist_ok=True)
    (DATA / "rules" / "v1.0.json").write_text((ROOT / "rules" / "v1.0.json").read_text())
    rules_store = RuleStore(DATA / "rules")

store = Store(DATA / "evbreath.db")
source = LiveSource(store) if MODE == "live" else DemoSource()
engine = Engine(rules_store, source)


# ---------------------------------------------------------------- secrets + brokers
def load_secrets() -> dict:
    return json.loads(SECRETS.read_text()) if SECRETS.exists() else {}


def save_secrets(d: dict):
    SECRETS.write_text(json.dumps(d, indent=2))
    try:
        os.chmod(SECRETS, 0o600)
    except OSError:
        pass


def flattrade() -> Flattrade | None:
    s = load_secrets().get("flattrade")
    if not s:
        return None
    return Flattrade(s.get("User ID", ""), s.get("API key", ""), s.get("API secret", ""), s.get("token"))


def connected_broker():
    ft = flattrade()
    return ft if ft and ft.token else None


orders = OrderManager(engine, connected_broker)

# ---------------------------------------------------------------- live feeds
feeds = [Feed("flattrade", "Flattrade · Pi API", "Broker websocket · free"),
         Feed("kotak", "Kotak Neo · Trade API", "Broker websocket · free"),
         Feed("vendor", "Licensed data vendor", "NSE-authorised feed · paid")]
if MODE == "demo":
    feeds.insert(0, Feed("demo", "Demo ticker", "Sample prices", DemoTicker(source, [s["symbol"] for s in source.universe()])))
feed_mgr = FeedManager(feeds, on_price=lambda sym, p: source.apply_tick(sym, p))


def _recompute_loop():
    while True:
        try:
            engine.recompute()
            feed_mgr.publish("scores", {"at": time.time()})
            for a in engine.data()["alerts"]:
                key = (a["symbol"], a["subject"])
                if a["push"] and key not in engine.sent_alerts:
                    engine.sent_alerts.add(key)
                    feed_mgr.publish("alert", a)
        except Exception as e:  # keep serving the last good results
            print("recompute failed:", e)
        time.sleep(300)


# ---------------------------------------------------------------- helpers
def ok(data, status=200):
    return JSONResponse(data, status_code=status)


def auth(request: Request):
    if APP_TOKEN and request.headers.get("x-app-token") != APP_TOKEN and request.query_params.get("token") != APP_TOKEN:
        return ok({"error": "Wrong or missing app token"}, 401)
    return None


def guarded(fn):
    async def wrapper(request: Request):
        bad = auth(request)
        if bad:
            return bad
        try:
            res = fn(request) if not asyncio.iscoroutinefunction(fn) else await fn(request)
            return res if isinstance(res, (JSONResponse, HTMLResponse, EventSourceResponse)) else ok(res)
        except (ValueError, OrderRejected, FlattradeError) as e:
            return ok({"error": str(e)}, 400)
    return wrapper


# ---------------------------------------------------------------- routes
@guarded
def health(r):
    return {"ok": True, "mode": MODE, "rules": rules_store.live_version(), "source": source.name}


@guarded
def home(r):
    return engine.home()


@guarded
def scanner(r):
    q = r.query_params
    return engine.scanner(q.get("preset", "breath"), q.get("q", ""), q.get("fno") == "1")


@guarded
def multibagger(r):
    return engine.multibagger(r.query_params.get("stage", "Early"))


@guarded
def blast(r):
    return engine.blast(r.query_params.get("tab", "lit"))


@guarded
def news(r):
    return engine.news(r.query_params.get("tab", "mb"))


@guarded
def penny(r):
    q = r.query_params
    return engine.penny_board(q.get("hide_asm", "1") == "1", q.get("band", ""))


@guarded
def check(r):
    res = engine.check(r.path_params["symbol"])
    return res if res else ok({"error": "Symbol not found in the scanned universe"}, 404)


@guarded
def alert(r):
    res = engine.alert(r.path_params["symbol"])
    return res if res else ok({"error": "Symbol not found"}, 404)


@guarded
def alerts(r):
    return {"alerts": engine.data()["alerts"]}


# rules
@guarded
def rules_get(r):
    return {"live": rules_store.live(), "draft_diff": rules_store.diff(), "versions": rules_store.versions(),
            "live_version": rules_store.live_version(), "backtest": rules_store.draft_backtest,
            "changelog": rules_store.changelog()[:20]}


@guarded
async def rules_draft(r):
    body = await r.json()
    return {"diff": rules_store.set_values(body.get("changes", {}))}


@guarded
def rules_reset(r):
    rules_store.reset()
    return {"ok": True}


@guarded
def rules_backtest(r):
    draft = rules_store.draft or rules_store.live()
    res = backtest.compare(source.universe(), rules_store.live(), draft, lookback_days=int(r.query_params.get("days", 250)))
    if rules_store.draft:
        rules_store.draft_backtest = res["draft"]
    return res


@guarded
async def rules_publish(r):
    body = await r.json() if await r.body() else {}
    v = rules_store.publish(body.get("reason", ""))
    engine.recompute()
    return {"live_version": v}


@guarded
async def rules_restore(r):
    body = await r.json()
    rules_store.restore(body["version"])
    engine.recompute()
    return {"live_version": rules_store.live_version()}


# brokers
@guarded
def brokers(r):
    sec = load_secrets()
    out = []
    for b in BROKERS:
        s = sec.get(b["id"], {})
        out.append({**b, "saved": bool(s), "connected": bool(s.get("token")) if b["adapter"] else False})
    return {"brokers": out}


@guarded
async def broker_save(r):
    bid = r.path_params["id"]
    if bid not in BY_ID:
        raise ValueError("Unknown broker")
    body = await r.json()
    sec = load_secrets()
    sec[bid] = {**sec.get(bid, {}), **{k: v for k, v in body.items() if k in BY_ID[bid]["fields"] and v}}
    save_secrets(sec)
    res = {"saved": True, "adapter": BY_ID[bid]["adapter"]}
    if bid == "flattrade":
        res["login_url"] = flattrade().login_url()
    return res


async def flattrade_callback(r: Request):
    code = r.query_params.get("code")
    ft = flattrade()
    if not code or not ft:
        return HTMLResponse("<h3>Missing code or Flattrade keys. Save your keys in the app first.</h3>", 400)
    try:
        token = ft.exchange_code(code)
    except Exception as e:
        return HTMLResponse(f"<h3>Flattrade login failed: {e}</h3>", 400)
    sec = load_secrets()
    sec["flattrade"]["token"] = token
    sec["flattrade"]["token_at"] = time.strftime("%Y-%m-%d %H:%M")
    save_secrets(sec)
    return HTMLResponse("<h2 style='font-family:sans-serif'>Flattrade connected. You can go back to EV Breath.</h2>")


# market data
@guarded
def datasource(r):
    st = feed_mgr.status()
    st["last_prices"] = len(feed_mgr.last_prices)
    st["mode"] = MODE
    return st


@guarded
async def datasource_test(r):
    body = await r.json()
    feed_mgr.force_down(body["feed"], bool(body.get("down", True)))
    return feed_mgr.status()


# orders
@guarded
async def order_place(r):
    body = await r.json()
    return orders.place(body)


@guarded
def order_log(r):
    return {"orders": orders.log[:50]}


@guarded
def positions(r):
    b = connected_broker()
    return {"positions": b.positions() if b else [], "connected": bool(b)}


async def stream(request: Request):
    bad = auth(request)
    if bad:
        return bad
    q = feed_mgr.subscribe()

    async def gen():
        try:
            yield {"event": "hello", "data": json.dumps({"mode": MODE})}
            while True:
                if await request.is_disconnected():
                    break
                try:
                    msg = await asyncio.to_thread(q.get, True, 15)
                    yield {"event": msg["event"], "data": json.dumps(msg["data"])}
                except Exception:
                    yield {"event": "ping", "data": "{}"}
        finally:
            feed_mgr.unsubscribe(q)
    return EventSourceResponse(gen())


def on_startup():
    if MODE == "live":
        from .jobs import LiveJobs, flattrade_feed
        LiveJobs(store, source, engine, DATA / "fundamentals.csv").start()
        ft = connected_broker()
        if ft:
            feeds[0].runner = flattrade_feed(ft, source, lambda: [s["symbol"] for s in source.universe()])
    engine.recompute()
    feed_mgr.start()
    threading.Thread(target=_recompute_loop, daemon=True).start()


routes = [
    Route("/api/health", health), Route("/api/home", home), Route("/api/scanner", scanner),
    Route("/api/multibagger", multibagger), Route("/api/blast", blast), Route("/api/news", news),
    Route("/api/penny", penny), Route("/api/check/{symbol}", check), Route("/api/alert/{symbol}", alert),
    Route("/api/alerts", alerts),
    Route("/api/rules", rules_get), Route("/api/rules/draft", rules_draft, methods=["PUT", "POST"]),
    Route("/api/rules/reset", rules_reset, methods=["POST"]), Route("/api/rules/backtest", rules_backtest, methods=["POST", "GET"]),
    Route("/api/rules/publish", rules_publish, methods=["POST"]), Route("/api/rules/restore", rules_restore, methods=["POST"]),
    Route("/api/brokers", brokers), Route("/api/brokers/{id}", broker_save, methods=["POST"]),
    Route("/callback/flattrade", flattrade_callback),
    Route("/api/datasource", datasource), Route("/api/datasource/test", datasource_test, methods=["POST"]),
    Route("/api/orders", order_place, methods=["POST"]), Route("/api/orders/log", order_log),
    Route("/api/positions", positions), Route("/api/stream", stream),
]

@contextlib.asynccontextmanager
async def lifespan(app):
    on_startup()
    yield


app = Starlette(routes=routes, lifespan=lifespan,
                middleware=[Middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])])
