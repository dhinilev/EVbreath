"""All Indian broker APIs the app can list. 'adapter' marks the ones with working code in this server."""

F = {
    "noren": ["User ID", "API key", "API secret"],
    "oauth": ["Client ID", "API key", "API secret"],
    "kite": ["API key", "API secret"],
    "totp": ["Client code", "API key", "TOTP secret"],
    "token": ["Client ID", "Access token"],
    "xts": ["Interactive app key", "Interactive secret", "Market-data app key", "Market-data secret"],
    "redirect": ["App ID", "Secret key", "Redirect URL"],
    "session": ["API key", "Secret key", "Session token"],
}

_RAW = [
    ("flattrade", "Flattrade", "Pi API", "mine", "noren", True, "Token expires daily · log in each morning to refresh."),
    ("kotak", "Kotak Neo", "Neo Trade API", "mine", "oauth", False, "Good as a second live data feed."),
    ("dhan", "Dhan", "DhanHQ API", "mine", "token", False, "Access token is generated in Dhan web › API."),
    ("zerodha", "Zerodha", "Kite Connect", "disc", "kite", False, "Create an app on the Kite developer console."),
    ("upstox", "Upstox", "Upstox API v2", "disc", "redirect", False, "Create an app on the Upstox developer portal."),
    ("angel", "Angel One", "SmartAPI", "disc", "totp", False, "Needs TOTP enabled on your Angel One account."),
    ("groww", "Groww", "Groww Trade API", "disc", "token", False, "Generate the API key in Groww › Trading APIs."),
    ("fyers", "Fyers", "Fyers API v3", "disc", "redirect", False, "Create an app on the Fyers API dashboard."),
    ("shoonya", "Shoonya (Finvasia)", "Shoonya API", "disc", "noren", False, "Vendor code is shared by Finvasia on request."),
    ("fivepaisa", "5paisa", "5paisa API · XTS", "disc", "session", False, "Keys come from the 5paisa developer section."),
    ("aliceblue", "Alice Blue", "ANT API", "disc", "totp", False, "Enable API access in the ANT web portal."),
    ("mstock", "m.Stock (Mirae Asset)", "m.Stock Trading API", "disc", "oauth", False, "Create the API key in m.Stock › Trading APIs."),
    ("paytm", "Paytm Money", "Paytm Money API", "disc", "redirect", False, "Create an app on the Paytm Money developer page."),
    ("samco", "Samco", "Samco Trade API", "disc", "oauth", False, "Subscribe to Trade API in your Samco account."),
    ("zebu", "Zebu", "Zebu API", "disc", "noren", False, "Request API keys from Zebu support."),
    ("tradejini", "Tradejini", "CubePlus API", "disc", "oauth", False, "Generate keys in the Tradejini API portal."),
    ("firstock", "Firstock", "Firstock API", "disc", "noren", False, "Request vendor code from Firstock."),
    ("definedge", "Definedge", "Integrate API", "disc", "oauth", False, "Generate the token in Definedge › Integrate."),
    ("tradesmart", "TradeSmart", "TradeSmart API", "disc", "noren", False, "Request API access from TradeSmart."),
    ("pocketful", "Pocketful", "Pocketful API", "disc", "oauth", False, "Create an app in the Pocketful developer console."),
    ("indmoney", "INDmoney", "INDstocks API", "disc", "token", False, "Generate the access token in INDmoney › API."),
    ("nubra", "Nubra", "Nubra API", "disc", "oauth", False, "Create keys in the Nubra developer section."),
    ("arrow", "Arrow", "Arrow API", "disc", "oauth", False, "Create keys in the Arrow developer section."),
    ("wisdom", "Wisdom Capital", "XTS API", "disc", "xts", False, "XTS keys are issued by Wisdom Capital."),
    ("rmoney", "RMoney", "XTS API", "disc", "xts", False, "XTS keys are issued by RMoney."),
    ("jainam", "Jainam", "XTS API", "disc", "xts", False, "XTS keys are issued by Jainam."),
    ("compositedge", "Composite Edge", "XTS API", "disc", "xts", False, "XTS keys are issued by Composite Edge."),
    ("icici", "ICICI Direct", "Breeze API", "full", "session", False, "Session token is generated after daily login."),
    ("hdfcsec", "HDFC Securities", "HDFC Securities API", "full", "oauth", False, "Register on the HDFC Securities developer portal."),
    ("hdfcsky", "HDFC Sky", "HDFC Sky API", "full", "oauth", False, "Generate keys in HDFC Sky › API."),
    ("iifl", "IIFL Capital", "IIFL API · XTS", "full", "xts", False, "XTS keys are issued by IIFL Capital."),
    ("motilal", "Motilal Oswal", "MO Trade API", "full", "totp", False, "Register on the Motilal Oswal API portal."),
    ("sharekhan", "Sharekhan", "Sharekhan API", "full", "redirect", False, "Register on the Sharekhan developer portal."),
    ("anandrathi", "Anand Rathi", "Anand Rathi API", "full", "oauth", False, "Request API access from Anand Rathi."),
    ("indiabulls", "Indiabulls", "Indiabulls API", "full", "oauth", False, "Request API access from Indiabulls."),
]

BROKERS = [{"id": r[0], "name": r[1], "product": r[2], "group": r[3], "fields": F[r[4]], "family": r[4],
            "adapter": r[5], "note": r[6]} for r in _RAW]
BY_ID = {b["id"]: b for b in BROKERS}
