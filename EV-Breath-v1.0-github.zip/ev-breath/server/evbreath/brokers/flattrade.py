"""Flattrade Pi API adapter (Noren OMS).

Endpoints, from Flattrade's Pi API:
  login page   https://auth.flattrade.in/?app_key=<API_KEY>   -> redirects to your URL with ?code=<request_code>
  token        POST https://authapi.flattrade.in/trade/apitoken
               {"api_key", "request_code", "api_secret": sha256(api_key + request_code + api_secret)}
  REST         POST https://piconnect.flattrade.in/PiConnectAPI/<Endpoint>   body: jData=<json>&jKey=<token>
  websocket    wss://piconnect.flattrade.in/PiConnectWSAPI/

Check every field against pi.flattrade.in/docs before live trading: brokers change APIs.
SEBI retail-algo rules (Flattrade API v2): orders only from your registered static IP, and only
LMT / SL-LMT order types. This adapter refuses anything else.
"""
from __future__ import annotations

import hashlib
import json
import threading
import time
from typing import Callable, Optional

import requests

LOGIN_URL = "https://auth.flattrade.in/"
TOKEN_URL = "https://authapi.flattrade.in/trade/apitoken"
BASE_URL = "https://piconnect.flattrade.in/PiConnectAPI"
WS_URL = "wss://piconnect.flattrade.in/PiConnectWSAPI/"

ALLOWED_PRICE_TYPES = {"LMT", "SL-LMT"}
PRODUCTS = {"CNC": "C", "MIS": "I"}


class FlattradeError(RuntimeError):
    pass


class Flattrade:
    id = "flattrade"

    def __init__(self, user_id: str, api_key: str, api_secret: str, token: Optional[str] = None, timeout: float = 10):
        self.user_id = user_id
        self.api_key = api_key
        self.api_secret = api_secret
        self.token = token
        self.timeout = timeout
        self.http = requests.Session()

    # ---------------------------------------------------------------- login
    def login_url(self) -> str:
        return f"{LOGIN_URL}?app_key={self.api_key}"

    def exchange_code(self, request_code: str) -> str:
        secret = hashlib.sha256(f"{self.api_key}{request_code}{self.api_secret}".encode()).hexdigest()
        r = self.http.post(TOKEN_URL, json={"api_key": self.api_key, "request_code": request_code, "api_secret": secret},
                           timeout=self.timeout)
        r.raise_for_status()
        data = r.json()
        if data.get("stat") != "Ok" or not data.get("token"):
            raise FlattradeError(data.get("emsg") or "Token exchange failed")
        self.token = data["token"]
        return self.token

    # ---------------------------------------------------------------- REST
    def _post(self, endpoint: str, payload: dict) -> dict | list:
        if not self.token:
            raise FlattradeError("Not logged in: open the Flattrade login and approve the app")
        body = "jData=" + json.dumps(payload, separators=(",", ":")) + "&jKey=" + self.token
        r = self.http.post(f"{BASE_URL}/{endpoint}", data=body, timeout=self.timeout,
                           headers={"Content-Type": "text/plain"})
        r.raise_for_status()
        data = r.json()
        if isinstance(data, dict) and data.get("stat") == "Not_Ok":
            raise FlattradeError(data.get("emsg") or f"{endpoint} failed")
        return data

    def search(self, text: str, exch: str = "NSE") -> list:
        d = self._post("SearchScrip", {"uid": self.user_id, "stext": text, "exch": exch})
        return d.get("values", []) if isinstance(d, dict) else []

    def quote(self, token: str, exch: str = "NSE") -> dict:
        return self._post("GetQuotes", {"uid": self.user_id, "exch": exch, "token": token})

    def positions(self) -> list:
        d = self._post("PositionBook", {"uid": self.user_id, "actid": self.user_id})
        return d if isinstance(d, list) else []

    def holdings(self) -> list:
        d = self._post("Holdings", {"uid": self.user_id, "actid": self.user_id, "prd": "C"})
        return d if isinstance(d, list) else []

    def order_book(self) -> list:
        d = self._post("OrderBook", {"uid": self.user_id})
        return d if isinstance(d, list) else []

    def place_order(self, tsym: str, qty: int, price: float, side: str = "B", product: str = "CNC",
                    price_type: str = "LMT", trigger: Optional[float] = None, exch: str = "NSE",
                    remarks: str = "EV Breath") -> str:
        """Place one order. Returns the Flattrade order number."""
        if price_type not in ALLOWED_PRICE_TYPES:
            raise FlattradeError(f"{price_type} not allowed: only LMT and SL-LMT (SEBI retail algo rule)")
        if qty <= 0:
            raise FlattradeError("Quantity must be positive")
        p = {"uid": self.user_id, "actid": self.user_id, "exch": exch, "tsym": tsym, "qty": str(int(qty)),
             "prc": f"{price:.2f}", "prd": PRODUCTS.get(product, "C"), "trantype": side, "prctyp": price_type,
             "ret": "DAY", "ordersource": "API", "remarks": remarks}
        if price_type == "SL-LMT":
            if trigger is None:
                raise FlattradeError("SL-LMT needs a trigger price")
            p["trgprc"] = f"{trigger:.2f}"
        d = self._post("PlaceOrder", p)
        if not isinstance(d, dict) or not d.get("norenordno"):
            raise FlattradeError("Order not accepted")
        return d["norenordno"]

    def modify_order(self, order_no: str, tsym: str, qty: int, price: float, price_type: str = "LMT",
                     trigger: Optional[float] = None, exch: str = "NSE") -> dict:
        if price_type not in ALLOWED_PRICE_TYPES:
            raise FlattradeError("Only LMT and SL-LMT allowed")
        p = {"uid": self.user_id, "exch": exch, "norenordno": order_no, "tsym": tsym, "qty": str(int(qty)),
             "prc": f"{price:.2f}", "prctyp": price_type, "ret": "DAY"}
        if trigger is not None:
            p["trgprc"] = f"{trigger:.2f}"
        return self._post("ModifyOrder", p)

    def cancel_order(self, order_no: str) -> dict:
        return self._post("CancelOrder", {"uid": self.user_id, "norenordno": order_no})

    def buy_with_stop(self, tsym: str, qty: int, limit: float, stop: float, product: str = "CNC") -> dict:
        """Entry as a limit buy, then a protective SL-LMT sell (placed once the buy fills; see OrderManager)."""
        if stop >= limit:
            raise FlattradeError("Stop-loss must be below the buy price")
        entry_no = self.place_order(tsym, qty, limit, "B", product, "LMT")
        return {"entry_order": entry_no, "stop": {"tsym": tsym, "qty": qty, "trigger": stop,
                                                 "price": round(stop * 0.995, 2), "product": product}}

    # ---------------------------------------------------------------- live feed
    def stream(self, tokens: list[str], on_tick: Callable[[dict], None], stop_event: threading.Event):
        """Blocking websocket loop: subscribes 'NSE|<token>' keys and calls on_tick(dict)."""
        from websockets.sync.client import connect  # optional dependency, installed on the server

        while not stop_event.is_set():
            try:
                with connect(WS_URL, open_timeout=10) as ws:
                    ws.send(json.dumps({"t": "c", "uid": self.user_id, "actid": self.user_id,
                                        "source": "API", "susertoken": self.token}))
                    ack = json.loads(ws.recv(timeout=10))
                    if ack.get("s") != "OK":
                        raise FlattradeError("Websocket login refused")
                    ws.send(json.dumps({"t": "t", "k": "#".join(f"NSE|{t}" for t in tokens)}))
                    last_ping = time.time()
                    while not stop_event.is_set():
                        if time.time() - last_ping > 20:
                            ws.send(json.dumps({"t": "h"}))
                            last_ping = time.time()
                        try:
                            msg = json.loads(ws.recv(timeout=5))
                        except TimeoutError:
                            continue
                        if msg.get("t") in ("tk", "tf"):
                            on_tick({"token": msg.get("tk"), "ltp": _f(msg.get("lp")), "pc": _f(msg.get("pc")),
                                     "volume": _i(msg.get("v")), "oi": _i(msg.get("oi")), "ts": time.time()})
            except Exception as e:  # reconnect with backoff; the FeedManager fails over meanwhile
                on_tick({"error": str(e), "ts": time.time()})
                stop_event.wait(3)


def _f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def _i(x):
    try:
        return int(x)
    except (TypeError, ValueError):
        return None
