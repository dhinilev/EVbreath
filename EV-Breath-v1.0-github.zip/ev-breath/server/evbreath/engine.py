"""Engine: holds the market data, applies the live rules, and builds every screen's data."""
from __future__ import annotations

import threading
import time
from typing import Optional

from . import alerts as al
from . import indicators as ind
from . import scoring as sc


class Engine:
    def __init__(self, rule_store, source):
        """source: an object with universe(), index('NIFTY'|'SENSEX'), vix(), flows(), ltp(symbol)."""
        self.rules_store = rule_store
        self.source = source
        self.lock = threading.Lock()
        self.cache: dict = {}
        self.computed_at = 0.0
        self.sent_alerts: set = set()

    # ------------------------------------------------------------ compute
    def rules(self) -> dict:
        return self.rules_store.live()

    def recompute(self, rules: Optional[dict] = None) -> dict:
        rules = rules or self.rules()
        U = [s for s in self.source.universe() if len(s["bars"]) >= 60]
        nifty = self.source.index("NIFTY")
        meter = sc.breath_meter([s for s in U if sc.last_close(s) > rules["gates"]["penny"]["max_price"]],
                                nifty, self.source.vix(), rules)
        rs_returns = {s["symbol"]: ind.ret(sc.closes(s), 63) or 0 for s in U
                      if sc.last_close(s) > rules["gates"]["penny"]["max_price"]}
        sectors: dict = {}
        for s in U:
            cs = sc.closes(s)
            m50 = ind.sma(cs, 50)
            if m50:
                sectors.setdefault(s["sector"], []).append(cs[-1] > m50)
        ctx = {"rs_returns": rs_returns,
               "sector_above_50": {k: sum(v) / len(v) > 0.5 for k, v in sectors.items()}}
        rows = {}
        for s in U:
            price = sc.last_close(s)
            is_penny = price <= rules["gates"]["penny"]["max_price"]
            g_main = sc.check_gates(s, rules, "penny" if is_penny else "main")
            g_mb = sc.check_gates(s, rules, "multibagger")
            b = sc.breath_score(s, ctx, rules)
            verdict = sc.breath_verdict(b["score"], g_main, meter, rules)
            d = sc.dna(s, rules)
            fz = sc.fuse(s, rules)
            pn = sc.penny(s, rules) if is_penny else None
            entry = b["setup"]["entry"] or price
            pl = sc.plan(s, price if b["setup"]["type"] in ("Pullback", "Breakout") else entry, rules,
                         meter["zone"], "penny" if is_penny else "main")
            cs = sc.closes(s)
            avg_d = sum(s["delivery"][-20:]) / 20 if s.get("delivery") else 0
            rows[s["symbol"]] = {
                "symbol": s["symbol"], "name": s["name"], "sector": s["sector"], "fno": s["fno"],
                "price": round(price, 2), "chg_pct": round(ind.pct_change(cs[-1], cs[-2]), 2),
                "mcap_cr": s["mcap_cr"], "is_penny": is_penny,
                "gates": g_main, "gates_mb": g_mb, "breath": b, "verdict": verdict, "dna": d, "fuse": fz,
                "penny": pn, "plan": pl,
                "delivery_x": round(s["delivery"][-1] / avg_d, 2) if avg_d else None,
                "pledge_pct": s.get("pledge_pct", 0), "results_in_days": s.get("results_in_days"),
                "asm": s.get("asm", False), "filings": s.get("filings", []),
                "fundamentals": s.get("fundamentals", {}), "promoter_pct": s.get("promoter_pct"),
            }
        alerts = []
        for s in U:
            r = rows[s["symbol"]]
            sub = r["penny"]["substance"] if r["penny"] else self._substance_main(s)
            for f in s.get("filings", []):
                if f.get("age_days", 0) == 0:
                    mb = r["dna"]["passed"] >= rules["dna"]["tests_to_pass"] and not r["is_penny"]
                    a = al.decide(f, s, sub, r["gates_mb"] if mb else r["gates"], rules)
                    a.update({"price": r["price"], "chg_pct": r["chg_pct"], "is_penny": r["is_penny"]})
                    alerts.append(a)
        alerts.sort(key=lambda a: a.get("time") or "", reverse=True)
        with self.lock:
            self.cache = {"rows": rows, "meter": meter, "alerts": alerts, "rules_version": rules["version"]}
            self.computed_at = time.time()
        return self.cache

    @staticmethod
    def _substance_main(s: dict) -> int:
        """Substance for non-penny stocks reuses the penny Substance parts."""
        filings = [x for x in s.get("filings", []) if x.get("age_days", 99) <= 5]
        sub = 25 if filings else 0
        sub += 20 if any(x.get("material") for x in filings) else 0
        sub += 15 if (s.get("delivery") or [0])[-1] >= 30 else 0
        sub += 10 if s.get("pledge_pct", 0) <= 10 else 0
        sub += 10 if s.get("promoter_pct", 0) >= 40 and s.get("promoter_change_4q", 0) >= 0 else 0
        sub += 10 if (s.get("fundamentals") or {}).get("de", 9) <= 1 else 0
        sub += 10 if not s.get("asm") else 0
        return sub

    def data(self, max_age: float = 300) -> dict:
        if not self.cache or time.time() - self.computed_at > max_age:
            return self.recompute()
        return self.cache

    # ------------------------------------------------------------ screens
    def home(self) -> dict:
        d = self.data()
        rows = list(d["rows"].values())
        nifty = self.source.index("NIFTY")
        sensex = self.source.index("SENSEX")
        def tick(b):
            return {"last": round(b[-1]["close"], 2), "chg_pct": round(ind.pct_change(b[-1]["close"], b[-2]["close"]), 2)}
        blast = sorted([r for r in rows if r["fuse"]["status"] == "Fuse lit" and r["gates"]["pass"] and not r["is_penny"]],
                       key=lambda r: -r["fuse"]["score"])
        mb = [r for r in rows if r["dna"]["stage"] and r["gates_mb"]["pass"]]
        return {"nifty": tick(nifty), "sensex": tick(sensex), "meter": d["meter"], "flows": self.source.flows(),
                "blast_count": len(blast), "blast": [self._brief(r) for r in blast[:3]],
                "multibagger": [self._brief(r) for r in mb[:3]], "alerts": d["alerts"][:3],
                "rules_version": d["rules_version"]}

    @staticmethod
    def _brief(r: dict) -> dict:
        f = r["fundamentals"]
        return {"symbol": r["symbol"], "name": r["name"], "price": r["price"], "chg_pct": r["chg_pct"],
                "fuse": r["fuse"]["score"], "stage": r["dna"]["stage"], "verdict": r["verdict"],
                "why": f"Sales 3Y +{f.get('sales_cagr3', 0):.0f}% · ROCE {f.get('roce', 0):.0f}%"}

    def scanner(self, preset: str = "breath", q: str = "", fno_only: bool = False) -> dict:
        d = self.data()
        rows = [r for r in d["rows"].values() if not r["is_penny"]]
        if q:
            ql = q.lower()
            rows = [r for r in rows if ql in r["symbol"].lower() or ql in r["sector"].lower() or ql in r["name"].lower()]
        if fno_only:
            rows = [r for r in rows if r["fno"]]
        st = lambda r: r["breath"]["setup"]["type"]
        if preset == "breakout":
            rows = [r for r in rows if st(r) in ("Breakout", "Base")]
        elif preset == "pullback":
            rows = [r for r in rows if st(r) == "Pullback"]
        elif preset == "oi":
            rows = [r for r in rows if r["breath"]["parts"]["oi"] and r["breath"]["parts"]["oi"] >= 10]
        elif preset == "del":
            rows = [r for r in rows if (r["delivery_x"] or 0) >= 1.5]
        rows.sort(key=lambda r: -r["breath"]["score"])
        passed = sum(1 for r in d["rows"].values() if r["gates"]["pass"] and not r["is_penny"])
        out = [{"symbol": r["symbol"], "price": r["price"], "chg_pct": r["chg_pct"], "delivery_x": r["delivery_x"],
                "oi": r["breath"]["oi_signal"], "score": r["breath"]["score"], "verdict": r["verdict"],
                "setup": r["breath"]["setup"]["note"]} for r in rows]
        return {"rows": out, "scanned": len(d["rows"]), "passed": passed,
                "calm": sum(1 for r in d["rows"].values() if r["verdict"] == "Calm Buy Zone")}

    def multibagger(self, stage: str = "Early") -> dict:
        d = self.data()
        rules = self.rules()
        rows = [r for r in d["rows"].values() if r["dna"]["passed"] >= rules["dna"]["tests_to_pass"]
                and r["gates_mb"]["pass"] and (not stage or r["dna"]["stage"] == stage)]
        rows.sort(key=lambda r: (-r["dna"]["passed"], -r["fundamentals"].get("sales_cagr3", 0)))
        return {"rows": [{"symbol": r["symbol"], "name": r["name"], "price": r["price"], "mcap_cr": r["mcap_cr"],
                          "sales_cagr3": r["fundamentals"].get("sales_cagr3"), "roce": r["fundamentals"].get("roce"),
                          "pe": r["fundamentals"].get("pe"), "tests": r["dna"]["tests"], "passed": r["dna"]["passed"],
                          "stage": r["dna"]["stage"], "warning": r["dna"]["warning"]} for r in rows],
                "counts": {s: sum(1 for r in d["rows"].values() if r["dna"]["stage"] == s and r["gates_mb"]["pass"]
                                  and r["dna"]["passed"] >= rules["dna"]["tests_to_pass"])
                           for s in ("Early", "Base", "Trending")}}

    def blast(self, tab: str = "lit") -> dict:
        d = self.data()
        rows = [r for r in d["rows"].values() if r["gates"]["pass"] and not r["is_penny"]]
        lit = sorted([r for r in rows if r["fuse"]["status"] == "Fuse lit"], key=lambda r: -r["fuse"]["score"])
        ign = sorted([r for r in rows if r["fuse"]["status"] == "Ignited"], key=lambda r: -r["fuse"]["score"])
        pick = ign if tab == "ignited" else lit
        return {"rows": [{"symbol": r["symbol"], "price": r["price"], "chg_pct": r["chg_pct"], "fuse": r["fuse"]["score"],
                          "tags": r["fuse"]["tags"], "status": r["fuse"]["status"]} for r in pick],
                "counts": {"lit": len(lit), "ignited": len(ign)}}

    def news(self, tab: str = "mb") -> dict:
        d = self.data()
        rules = self.rules()
        items = []
        for r in d["rows"].values():
            in_tab = {
                "mb": r["dna"]["passed"] >= rules["dna"]["tests_to_pass"] and not r["is_penny"],
                "bl": r["fuse"]["status"] in ("Fuse lit", "Ignited") and not r["is_penny"],
                "pn": r["is_penny"],
            }[tab]
            if not in_tab:
                continue
            for f in r["filings"]:
                a = next((x for x in d["alerts"] if x["symbol"] == r["symbol"] and x["subject"] == f["subject"]), None)
                items.append({"time": f.get("time"), "symbol": r["symbol"], "kind": f["kind"], "head": f["subject"],
                              "price": r["price"], "buy": a["buy"] if a else ("none" if r["asm"] else "risky"),
                              "why": a["reason"] if a else ""})
        items.sort(key=lambda x: x["time"] or "", reverse=True)
        return {"items": items}

    def penny_board(self, hide_asm: bool = True, band: str = "") -> dict:
        d = self.data()
        rows = [r for r in d["rows"].values() if r["is_penny"]]
        if hide_asm:
            rows = [r for r in rows if not r["asm"]]
        if band == "u20":
            rows = [r for r in rows if r["price"] < 20]
        elif band == "20-50":
            rows = [r for r in rows if r["price"] >= 20]
        rows.sort(key=lambda r: -r["penny"]["buzz"])
        return {"rows": [{"symbol": r["symbol"], "price": r["price"], "chg_pct": r["chg_pct"], **r["penny"]} for r in rows]}

    def check(self, symbol: str) -> Optional[dict]:
        d = self.data()
        r = d["rows"].get(symbol.upper().strip())
        if not r:
            return None
        return {**r, "meter_zone": d["meter"]["zone"]}

    def alert(self, symbol: str) -> Optional[dict]:
        d = self.data()
        a = next((x for x in d["alerts"] if x["symbol"] == symbol.upper()), None)
        r = d["rows"].get(symbol.upper())
        if not r:
            return None
        return {"alert": a, "row": r}
