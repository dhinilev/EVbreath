"""NSE / BSE public data jobs. Downloads once a day after close, gently (one file at a time).

URLs are the ones NSE and BSE publish today; exchanges change them, so each job logs failures
instead of crashing the server. Use for your own account only and respect the exchanges' terms.
"""
from __future__ import annotations

import csv
import datetime as dt
import io
import time
import zipfile
from typing import Optional

import requests

UA = {"User-Agent": "Mozilla/5.0 (Linux; Android 14) EVBreath/1.0", "Accept": "*/*", "Accept-Language": "en-IN"}
ARCH = "https://nsearchives.nseindia.com"

EQ_BHAV = ARCH + "/products/content/sec_bhavdata_full_{ddmmyyyy}.csv"           # price + delivery %
FO_BHAV = ARCH + "/content/fo/BhavCopy_NSE_FO_0_0_0_{yyyymmdd}_F_0000.csv.zip"   # F&O OI (UDiFF)
NSE_API = "https://www.nseindia.com/api"
ANNOUNCEMENTS = NSE_API + "/corporate-announcements?index=equities"
ASM = NSE_API + "/reportASM"
FII_DII = NSE_API + "/fiidiiTradeReact"
BAN = ARCH + "/content/fo/fo_secban.csv"
BSE_ANN = ("https://api.bseindia.com/BseIndiaAPI/api/AnnSubCategoryGetData/w?pageno=1&strCat=-1"
           "&strPrevDate={d}&strScrip=&strSearch=P&strToDate={d}&strType=C")


class NSEClient:
    def __init__(self, timeout: float = 20):
        self.s = requests.Session()
        self.s.headers.update(UA)
        self.timeout = timeout
        self._warmed = 0.0

    def _warm(self):
        """NSE's JSON API needs the cookies its home page sets."""
        if time.time() - self._warmed > 600:
            self.s.get("https://www.nseindia.com", timeout=self.timeout)
            self._warmed = time.time()

    def get(self, url: str, api: bool = False) -> requests.Response:
        if api:
            self._warm()
        r = self.s.get(url, timeout=self.timeout)
        r.raise_for_status()
        time.sleep(1.0)  # be gentle
        return r

    # ------------------------------------------------------------ EOD files
    def equity_bhavcopy(self, day: dt.date) -> list[dict]:
        r = self.get(EQ_BHAV.format(ddmmyyyy=day.strftime("%d%m%Y")))
        rows = []
        for row in csv.DictReader(io.StringIO(r.text)):
            row = {k.strip(): (v or "").strip() for k, v in row.items()}
            if row.get("SERIES") not in ("EQ", "BE", "BZ", "SM"):
                continue
            rows.append({"symbol": row["SYMBOL"], "series": row["SERIES"], "date": day.isoformat(),
                         "open": _f(row.get("OPEN_PRICE")), "high": _f(row.get("HIGH_PRICE")),
                         "low": _f(row.get("LOW_PRICE")), "close": _f(row.get("CLOSE_PRICE")),
                         "volume": int(_f(row.get("TTL_TRD_QNTY")) or 0),
                         "delivery_pct": _f(row.get("DELIV_PER"))})
        return rows

    def fo_bhavcopy(self, day: dt.date) -> dict[str, int]:
        """Total stock-futures open interest per underlying."""
        r = self.get(FO_BHAV.format(yyyymmdd=day.strftime("%Y%m%d")))
        z = zipfile.ZipFile(io.BytesIO(r.content))
        oi: dict[str, int] = {}
        for row in csv.DictReader(io.StringIO(z.read(z.namelist()[0]).decode())):
            if row.get("FinInstrmTp") == "STF":
                sym = row.get("TckrSymb")
                oi[sym] = oi.get(sym, 0) + int(_f(row.get("OpnIntrst")) or 0)
        return oi

    def index_close(self, day: dt.date) -> dict[str, dict]:
        """Daily OHLC of every NSE index (keys like 'Nifty 50')."""
        r = self.get(ARCH + f"/content/indices/ind_close_all_{day.strftime('%d%m%Y')}.csv")
        out = {}
        for row in csv.DictReader(io.StringIO(r.text)):
            name = (row.get("Index Name") or "").strip()
            out[name] = {"date": day.isoformat(), "open": _f(row.get("Open Index Value")), "high": _f(row.get("High Index Value")),
                         "low": _f(row.get("Low Index Value")), "close": _f(row.get("Closing Index Value")), "volume": 0}
        return out

    def fo_ban(self) -> set[str]:
        r = self.get(BAN)
        return {line.split(",")[-1].strip() for line in r.text.splitlines()[1:] if line.strip()}

    # ------------------------------------------------------------ JSON APIs
    def announcements(self) -> list[dict]:
        data = self.get(ANNOUNCEMENTS, api=True).json()
        out = []
        for a in data if isinstance(data, list) else []:
            out.append({"symbol": a.get("symbol"), "subject": a.get("desc") or a.get("attchmntText") or "",
                        "detail": a.get("attchmntText", ""), "time": (a.get("an_dt") or "")[-8:-3],
                        "datetime": a.get("an_dt"), "url": a.get("attchmntFile"), "source": "NSE"})
        return out

    def asm_list(self) -> set[str]:
        data = self.get(ASM, api=True).json()
        syms = set()
        for key in ("longterm", "shortterm"):
            for row in (data.get(key) or {}).get("data", []):
                syms.add(row.get("symbol"))
        return syms

    def fii_dii(self) -> dict:
        data = self.get(FII_DII, api=True).json()
        out = {}
        for row in data:
            cat = (row.get("category") or "").upper()
            if "FII" in cat or "FPI" in cat:
                out["fii_cr"] = _f(row.get("netValue"))
            elif "DII" in cat:
                out["dii_cr"] = _f(row.get("netValue"))
        return out

    def bse_announcements(self, day: Optional[dt.date] = None) -> list[dict]:
        d = (day or dt.date.today()).strftime("%Y%m%d")
        r = self.s.get(BSE_ANN.format(d=d), timeout=self.timeout,
                       headers={**UA, "Referer": "https://www.bseindia.com/", "Origin": "https://www.bseindia.com"})
        r.raise_for_status()
        out = []
        for a in (r.json() or {}).get("Table", []):
            out.append({"symbol": a.get("SLONGNAME"), "scrip": a.get("SCRIP_CD"), "subject": a.get("NEWSSUB", ""),
                        "time": (a.get("NEWS_DT") or "")[11:16], "source": "BSE"})
        return out


def _f(x) -> Optional[float]:
    try:
        return float(str(x).replace(",", ""))
    except (TypeError, ValueError):
        return None
