"""Walk-forward backtest of the Breath Score rules on daily bars.

For each stock and each day: score with data up to that day only. A Calm Buy Zone with no open
position buys at that close. The trade then follows the plan rules: stop-loss, trail at the 20 EMA
after +10%, exit on a close below the 50-day average, or the time stop.
"""
from __future__ import annotations

import copy

from . import indicators as ind
from . import scoring as sc

WARMUP = 210


def _slice(s: dict, end: int) -> dict:
    t = dict(s)
    t["bars"] = s["bars"][:end]
    t["delivery"] = (s.get("delivery") or [])[:end]
    t["oi"] = (s.get("oi") or [])[:end] if s.get("oi") else None
    return t


def _daily_context(universe: list[dict], rules: dict) -> dict:
    """Per-day relative-strength population and sector strength, aligned by bar index from the end."""
    main = [s for s in universe if sc.last_close(s) > rules["gates"]["penny"]["max_price"]]
    n = min(len(s["bars"]) for s in main)
    ctx = {}
    closes = {s["symbol"]: [b["close"] for b in s["bars"][-n:]] for s in main}
    m50 = {k: ind.sma_series(v, 50) for k, v in closes.items()}
    for back in range(n - 64):
        i = n - 1 - back
        rs = {k: ind.pct_change(v[i], v[i - 63]) for k, v in closes.items()}
        sect: dict = {}
        for s in main:
            m = m50[s["symbol"]][i]
            if m:
                sect.setdefault(s["sector"], []).append(closes[s["symbol"]][i] > m)
        ctx[back] = {"rs_returns": rs, "sector_above_50": {k: sum(v) / len(v) > 0.5 for k, v in sect.items()}}
    return ctx


def run(universe: list[dict], rules: dict, lookback_days: int = 750, step: int = 1) -> dict:
    rk = rules["risk"]
    trades = []
    meter_ok = {"zone": "Calm"}
    day_ctx = _daily_context(universe, rules)
    empty = {"rs_returns": {}, "sector_above_50": {}}
    for s in universe:
        bars = s["bars"]
        if len(bars) < WARMUP + 20 or sc.last_close(s) <= rules["gates"]["penny"]["max_price"]:
            continue
        start = max(WARMUP, len(bars) - lookback_days)
        pos = None
        i = start
        while i < len(bars):
            sub = _slice(s, i + 1)
            price = bars[i]["close"]
            if pos is None:
                if (i - start) % step == 0:
                    g = sc.check_gates(sub, rules, "main")
                    b = sc.breath_score(sub, day_ctx.get(len(bars) - 1 - i, empty), rules)
                    if sc.breath_verdict(b["score"], g, meter_ok, rules) == "Calm Buy Zone":
                        p = sc.plan(sub, price, rules)
                        pos = {"symbol": s["symbol"], "entry_i": i, "entry": price, "stop": p["stop"],
                               "date": bars[i]["date"], "peak": price}
            else:
                lo, cl = bars[i]["low"], price
                pos["peak"] = max(pos["peak"], cl)
                cs = [x["close"] for x in bars[:i + 1]]
                exit_px = reason = None
                if lo <= pos["stop"]:
                    exit_px, reason = pos["stop"], "Stop-loss"
                else:
                    if ind.pct_change(pos["peak"], pos["entry"]) >= rk["trail_after_pct"]:
                        e20 = ind.ema(cs, 20)
                        if e20 and cl < e20:
                            exit_px, reason = cl, "Trail 20 EMA"
                    m50 = ind.sma(cs, 50)
                    if exit_px is None and m50 and cl < m50:
                        exit_px, reason = cl, "Below 50-day avg"
                    if exit_px is None and i - pos["entry_i"] >= rk["time_stop_sessions"] and cl <= pos["entry"] * 1.02:
                        exit_px, reason = cl, "Time stop"
                if exit_px is not None:
                    risk = pos["entry"] - pos["stop"]
                    trades.append({"symbol": pos["symbol"], "date": pos["date"], "exit_date": bars[i]["date"],
                                   "entry": round(pos["entry"], 2), "exit": round(exit_px, 2), "reason": reason,
                                   "pnl_pct": round(ind.pct_change(exit_px, pos["entry"]), 2),
                                   "r": round((exit_px - pos["entry"]) / risk, 2) if risk > 0 else 0})
                    pos = None
            i += 1
    n = len(trades)
    wins = [t for t in trades if t["pnl_pct"] > 0]
    return {
        "trades": n,
        "hit_rate_pct": round(100 * len(wins) / n, 1) if n else None,
        "avg_gain_pct": round(sum(t["pnl_pct"] for t in wins) / len(wins), 2) if wins else None,
        "avg_loss_pct": round(sum(t["pnl_pct"] for t in trades if t["pnl_pct"] <= 0) / max(1, n - len(wins)), 2) if n else None,
        "avg_r": round(sum(t["r"] for t in trades) / n, 2) if n else None,
        "recent": trades[-10:],
    }


def compare(universe: list[dict], live_rules: dict, draft_rules: dict, **kw) -> dict:
    return {"live": run(universe, copy.deepcopy(live_rules), **kw), "draft": run(universe, copy.deepcopy(draft_rules), **kw)}
