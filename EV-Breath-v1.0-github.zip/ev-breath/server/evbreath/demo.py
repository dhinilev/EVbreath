"""Deterministic demo market so the app works before any broker or data feed is connected.

Every company here is fictional. Each one is shaped to show one pattern the rules look for.
"""
from __future__ import annotations

import datetime as dt
import random

END = dt.date(2026, 10, 7)
N_DAYS = 320


def trading_days(n: int, end: dt.date = END) -> list[str]:
    out = []
    d = end
    while len(out) < n:
        if d.weekday() < 5:
            out.append(d.isoformat())
        d -= dt.timedelta(days=1)
    return out[::-1]


DATES = trading_days(N_DAYS)


def _walk(rng: random.Random, start: float, phases: list[tuple[int, float, float]]) -> list[float]:
    """phases: (days, daily drift %, daily volatility %). Returns closes."""
    p = start
    out = []
    for days, drift, vol in phases:
        for _ in range(days):
            p *= 1 + (drift + rng.gauss(0, vol)) / 100
            out.append(p)
    return out


def _bars(rng: random.Random, cs: list[float], base_vol: float, vol_mult: list[float] | None = None,
          range_pct: list[float] | None = None) -> list[dict]:
    bars = []
    prev = cs[0]
    for i, c in enumerate(cs):
        r = (range_pct[i] if range_pct else 1.6) / 100
        o = prev * (1 + rng.gauss(0, r / 3))
        hi = max(o, c) * (1 + abs(rng.gauss(0, r / 2)))
        lo = min(o, c) * (1 - abs(rng.gauss(0, r / 2)))
        v = base_vol * (vol_mult[i] if vol_mult else 1) * (0.75 + rng.random() * 0.5)
        bars.append({"date": DATES[i], "open": round(o, 2), "high": round(hi, 2), "low": round(lo, 2),
                     "close": round(c, 2), "volume": int(v)})
        prev = c
    return bars


def _scale_to(cs: list[float], last: float) -> list[float]:
    k = last / cs[-1]
    return [c * k for c in cs]


def _make(symbol, name, sector, pattern, last, seed, fno=True, mcap_cr=20000, **extra):
    rng = random.Random(seed)
    n = N_DAYS
    vm = [1.0] * n
    rp = [1.6] * n
    deliv = [40 + rng.gauss(0, 4) for _ in range(n)]
    if pattern == "pullback":
        cs = _walk(rng, 100, [(n - 22, 0.26, 1.0), (16, 0.7, 0.5), (5, -0.85, 0.12), (1, 0, 0)])
        cs[-1] = cs[-2] * 1.008
        for i in range(n - 6, n - 1):
            vm[i] = 0.5
        vm[-1] = 2.4
        for i in range(n - 20, n):
            if cs[i] > cs[i - 1]:
                deliv[i] = 68 + rng.gauss(0, 2)
    elif pattern == "breakout":
        cs = _walk(rng, 100, [(n - 31, 0.16, 1.1), (30, 0.0, 0.45), (1, 0, 0)])
        cs[-1] = max(cs[-31:-1]) * 1.035
        for i in range(n - 31, n - 1):
            rp[i] = 0.9
        vm[-1] = 2.1
        for i in range(n - 12, n):
            if cs[i] > cs[i - 1]:
                deliv[i] = 60 + rng.gauss(0, 3)
    elif pattern == "squeeze":
        cs = _walk(rng, 100, [(n - 45, 0.14, 1.2), (44, 0.02, 0.22), (1, 0, 0)])
        cs[-1] = cs[-2] * 1.002
        for i in range(n - 45, n):
            rp[i] = 0.55
        for i in range(n - 5, n):
            vm[i] = 1.6
            deliv[i] = 62 + rng.gauss(0, 3)
    elif pattern == "extended":
        cs = _walk(rng, 100, [(n - 20, 0.15, 1.1), (20, 0.75, 0.8)])
    elif pattern == "down":
        cs = _walk(rng, 100, [(n - 60, 0.05, 1.2), (60, -0.35, 1.3)])
    elif pattern == "early":
        cs = _walk(rng, 100, [(n - 70, -0.08, 1.2), (70, 0.35, 1.0)])
    elif pattern == "base":
        cs = _walk(rng, 100, [(n - 90, 0.2, 1.2), (90, 0.0, 0.7)])
    elif pattern == "trending":
        cs = _walk(rng, 100, [(n, 0.22, 1.0)])
        cs[-1] = max(cs) * 1.01
    else:  # flat / random
        cs = _walk(rng, 100, [(n, 0.03, 1.4)])
    cs = _scale_to(cs, last)
    base_vol = extra.pop("base_vol", (4e8 if fno else 9e7) / last)
    bars = _bars(rng, cs, base_vol, vm, rp)
    oi = None
    if fno:
        oi = []
        o = 1e6
        for i, b in enumerate(bars):
            if i > 0:
                up = b["close"] >= bars[i - 1]["close"]
                if pattern == "pullback" and i > n - 8:
                    o *= 1.03 if up else 0.99
                elif pattern in ("breakout", "squeeze", "trending") and i > n - 8:
                    o *= 1.03
                elif pattern == "down" and i > n - 8:
                    o *= 1.025 if not up else 0.99
                else:
                    o *= 1 + rng.gauss(0, 0.01)
            oi.append(int(o))
    stock = {"symbol": symbol, "name": name, "sector": sector, "fno": fno, "bars": bars,
             "delivery": [round(max(5, min(95, d)), 1) for d in deliv], "oi": oi, "mcap_cr": mcap_cr,
             "pledge_pct": 0, "promoter_pct": 55, "promoter_change_4q": 0, "asm": False, "fo_ban": False,
             "circuit_recent": False, "results_in_days": 30, "bulk_buy_5d": False,
             "fundamentals": {"sales_cagr3": 12, "profit_cagr3": 10, "sales_yoy_q": [6, 5], "roce": 14,
                              "roce3y": 13, "de": 0.6, "icr": 5, "pe": 24, "sector_pe": 25, "ttm_sales_cr": 4000},
             "buzz": {"news_ratio": 1, "social_ratio": 1}, "filings": [], "pattern": pattern}
    fund = extra.pop("fundamentals", None)
    if fund:
        stock["fundamentals"].update(fund)
    stock.update(extra)
    return stock


MB = {"sales_cagr3": 31, "profit_cagr3": 34, "sales_yoy_q": [22, 18], "roce": 24, "roce3y": 21,
      "de": 0.2, "icr": 12, "pe": 22, "sector_pe": 26}


def universe() -> list[dict]:
    U = [
        _make("AARAVSTL", "Aarav Steel", "Metals", "pullback", 1284.5, 11, mcap_cr=18400),
        _make("CORALPH", "Coral Pharma", "Pharma", "breakout", 642.1, 12, mcap_cr=9200),
        _make("NILAAUTO", "Nila Auto", "Auto", "extended", 2915.0, 13, mcap_cr=31000),
        _make("DHRUVINF", "Dhruv Infra", "Infra", "squeeze", 418.65, 14, mcap_cr=6100, bulk_buy_5d=True),
        _make("TARANGPW", "Tarang Power", "Power", "squeeze", 356.2, 15, mcap_cr=7400),
        _make("BHARATKN", "Bharat Kinetics", "Auto", "pullback", 2398.6, 16, mcap_cr=22000),
        _make("KESTRLAB", "Kestrel Labs", "Pharma", "down", 1102.75, 17, mcap_cr=8800, results_in_days=4),
        _make("ELARAFIN", "Elara Finance", "Finance", "down", 885.15, 18, mcap_cr=15000),
        _make("SAGARCEM", "Sagar Cement", "Cement", "early", 561.9, 19, fno=False, mcap_cr=1820,
              promoter_pct=62, fundamentals=MB),
        _make("MEERATEX", "Meera Textiles", "Textiles", "base", 311.2, 20, fno=False, mcap_cr=940,
              promoter_pct=54, promoter_change_4q=0.8, fundamentals={**MB, "roce": 21, "sales_cagr3": 27}),
        _make("VEDHACHM", "Vedha Chemicals", "Chemicals", "base", 744.0, 21, fno=False, mcap_cr=2460,
              promoter_pct=58, fundamentals={**MB, "de": 0.7, "roce": 19, "pe": 38, "sector_pe": 27}),
        _make("ORBITGR", "Orbit Gears", "Capital goods", "trending", 1560.4, 22, fno=False, mcap_cr=3110,
              promoter_pct=66, fundamentals={**MB, "roce": 28, "sales_cagr3": 22, "ttm_sales_cr": 1600}),
        _make("PALMYRA", "Palmyra Foods", "FMCG", "early", 228.35, 23, fno=False, mcap_cr=710,
              promoter_pct=46, fundamentals={**MB, "roce": 20, "sales_cagr3": 24}, results_in_days=16),
        _make("ANVIBANK", "Anvi Bank", "Banking", "flat", 1640.0, 24, mcap_cr=120000),
        _make("KAVERIIT", "Kaveri Infotech", "IT", "down", 1488.0, 25, mcap_cr=54000),
        _make("SURYAFMC", "Surya Consumer", "FMCG", "flat", 2210.0, 26, mcap_cr=46000),
        _make("MITRAREAL", "Mitra Realty", "Realty", "flat", 512.0, 27, mcap_cr=9800),
        _make("ROHINIMT", "Rohini Metals", "Metals", "trending", 904.0, 28, mcap_cr=14500),
        _make("ZOYAPHAR", "Zoya Pharma", "Pharma", "pullback", 1310.0, 29, mcap_cr=26000),
        _make("ILAPOWER", "Ila Power Grid", "Power", "trending", 288.0, 30, mcap_cr=33000),
        _make("NAVYAIT", "Navya Systems", "IT", "flat", 3120.0, 31, mcap_cr=61000),
        _make("ARJUNCAP", "Arjun Capital", "Finance", "flat", 744.0, 32, mcap_cr=12000),
        _make("TEJASAUTO", "Tejas Motors", "Auto", "breakout", 1850.0, 33, mcap_cr=28000),
        _make("VAYUINFRA", "Vayu Infra", "Infra", "pullback", 266.0, 34, mcap_cr=5200),
        # Penny stocks (under ₹50)
        _make("RAVIPOLY", "Ravi Polymers", "Plastics", "flat", 38.4, 40, fno=False, mcap_cr=420, base_vol=4e6,
              promoter_pct=52, fundamentals={"de": 0.4, "ttm_sales_cr": 80}, buzz={"news_ratio": 3.2, "social_ratio": 2.6}),
        _make("JYOTIAGR", "Jyoti Agro", "Agri", "flat", 17.25, 41, fno=False, mcap_cr=210, base_vol=6e6,
              promoter_pct=44, pledge_pct=12, fundamentals={"de": 0.9}, buzz={"news_ratio": 2.4, "social_ratio": 2.8}),
        _make("NOVAGRN", "Nova Green", "Energy", "flat", 9.8, 42, fno=False, mcap_cr=150, base_vol=9e6,
              promoter_pct=31, fundamentals={"de": 1.8}, buzz={"news_ratio": 1.4, "social_ratio": 4.8}),
        _make("SKYLINE", "Skyline Ventures", "Realty", "flat", 24.6, 43, fno=False, mcap_cr=180, base_vol=5e6,
              promoter_pct=28, pledge_pct=48, asm=True, circuit_recent=True, fundamentals={"de": 2.4},
              buzz={"news_ratio": 3.5, "social_ratio": 5.0}),
        _make("DEEPAMET", "Deepa Metals", "Metals", "flat", 44.1, 44, fno=False, mcap_cr=330, base_vol=3e6,
              promoter_pct=49, fundamentals={"de": 0.7}, buzz={"news_ratio": 1.8, "social_ratio": 1.6}),
    ]
    by = {s["symbol"]: s for s in U}
    # Penny volume / move flavour
    for sym, mult in (("RAVIPOLY", 3.4), ("JYOTIAGR", 2.2), ("NOVAGRN", 2.8), ("SKYLINE", 3.9), ("DEEPAMET", 3.2)):
        b = by[sym]["bars"]
        b[-1]["volume"] = int(b[-1]["volume"] * mult)
        b[-1]["close"] = round(b[-2]["close"] * {"RAVIPOLY": 1.098, "JYOTIAGR": 1.062, "NOVAGRN": 1.049,
                                                 "SKYLINE": 1.05, "DEEPAMET": 1.023}[sym], 2)
        b[-1]["high"] = max(b[-1]["high"], b[-1]["close"])
    by["RAVIPOLY"]["delivery"][-1] = 41
    by["JYOTIAGR"]["delivery"][-1] = 33
    by["NOVAGRN"]["delivery"][-1] = 9
    by["SKYLINE"]["delivery"][-1] = 12
    by["DEEPAMET"]["delivery"][-1] = 35
    for sym, f in FILINGS_BY_STOCK.items():
        by[sym]["filings"] = f
    return U


def _f(time, kind, subject, material, age=0, **kw):
    return {"time": time, "kind": kind, "subject": subject, "material": material, "age_days": age, **kw}


FILINGS_BY_STOCK = {
    "AARAVSTL": [_f("17:42", "Order", "Receipt of order worth ₹640 cr from a railway PSU", True, value_cr=640)],
    "CORALPH": [_f("15:48", "Results", "Financial results for the quarter: profit up 38%", True, profit_yoy_pct=38)],
    "DHRUVINF": [_f("17:10", "Bulk deal", "Bulk deal: mutual fund buys 1.1% stake", True, value_cr=67)],
    "TARANGPW": [_f("12:30", "Order", "Letter of award for 120 MW solar project", True, value_cr=520)],
    "SAGARCEM": [_f("17:42", "Capex", "Board approves new 2 MTPA grinding unit from internal accruals", True, value_cr=310)],
    "MEERATEX": [_f("16:05", "Promoter buy", "Acquisition of shares by promoter group: 0.8% from open market", True,
                    promoter_buy_pct=0.8)],
    "ORBITGR": [_f("14:20", "Order", "Export order worth ₹210 cr from a European OEM", True, value_cr=210)],
    "VEDHACHM": [_f("11:55", "Debt", "Raises ₹150 cr term loan for new plant", False, value_cr=150)],
    "PALMYRA": [_f("09:30", "Results date", "Board meeting on 23 Oct to approve financial results", False)],
    "RAVIPOLY": [_f("16:40", "Order", "Supply order worth ₹48 cr from state discom", True, value_cr=48)],
    "JYOTIAGR": [_f("10:20", "Results", "Q1 net profit up 3x on low base; sales +42%", True, profit_yoy_pct=200)],
    "DEEPAMET": [_f("11:05", "Debt cut", "Debt reduced by 30% after asset sale", False)],
}


def index_bars(last: float, seed: int) -> list[dict]:
    rng = random.Random(seed)
    cs = _scale_to(_walk(rng, 100, [(N_DAYS - 40, 0.05, 0.8), (40, 0.09, 0.6)]), last)
    return _bars(rng, cs, 1e8)


NIFTY = index_bars(25412.30, 101)
SENSEX = index_bars(83140.55, 102)
VIX = 12.8
FLOWS = {"fii_cr": -1240, "dii_cr": 2105}
