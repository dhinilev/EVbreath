import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from evbreath import alerts, backtest, indicators as ind, scoring as sc  # noqa: E402
from evbreath.engine import Engine  # noqa: E402
from evbreath.rules import RuleStore  # noqa: E402
from evbreath.sources import DemoSource  # noqa: E402

RULES = json.loads((ROOT / "rules" / "v1.0.json").read_text())


class Indicators(unittest.TestCase):
    def test_sma_ema(self):
        xs = list(range(1, 21))
        self.assertEqual(ind.sma(xs, 5), 18)
        self.assertAlmostEqual(ind.ema_series(xs, 5)[4], 3)

    def test_atr_positive(self):
        bars = [{"high": 10 + i, "low": 9 + i, "close": 9.5 + i} for i in range(30)]
        self.assertGreater(ind.atr(bars, 14), 0)


class Engine_(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        tmp = Path(tempfile.mkdtemp())
        (tmp / "v1.0.json").write_text(json.dumps(RULES))
        cls.engine = Engine(RuleStore(tmp), DemoSource())
        cls.d = cls.engine.recompute()

    def test_breakout_is_calm_buy_zone(self):
        self.assertEqual(self.d["rows"]["CORALPH"]["verdict"], "Calm Buy Zone")

    def test_downtrend_not_buyable(self):
        self.assertIn(self.d["rows"]["KESTRLAB"]["verdict"], ("Not yet", "Avoid"))

    def test_squeeze_lights_fuse(self):
        self.assertEqual(self.d["rows"]["TARANGPW"]["fuse"]["status"], "Fuse lit")

    def test_multibagger_dna(self):
        self.assertEqual(self.d["rows"]["SAGARCEM"]["dna"]["passed"], 6)
        self.assertEqual(self.d["rows"]["VEDHACHM"]["dna"]["warning"], "Valuation stretched vs sector")

    def test_penny_verdicts(self):
        self.assertEqual(self.d["rows"]["SKYLINE"]["penny"]["verdict"], "Pump risk")
        self.assertEqual(self.d["rows"]["RAVIPOLY"]["penny"]["verdict"], "Real trigger")

    def test_pledge_blocks_buy_in_alert(self):
        a = next(x for x in self.d["alerts"] if x["symbol"] == "JYOTIAGR")
        self.assertEqual(a["buy"], "none")

    def test_plan_risk_within_limit(self):
        for r in self.d["rows"].values():
            self.assertLessEqual(r["plan"]["risk_rupees"], RULES["risk"]["capital"] * RULES["risk"]["risk_pct"] / 100 + 1)
            self.assertLess(r["plan"]["stop"], r["plan"]["entry"])


class Alerts(unittest.TestCase):
    def test_classify(self):
        self.assertEqual(alerts.classify("Receipt of work order from NHAI"), "Order")
        self.assertEqual(alerts.classify("Creation of pledge on promoter shares"), "Pledge")

    def test_not_material_is_logged(self):
        s = {"symbol": "X", "fundamentals": {"ttm_sales_cr": 1000}}
        res = alerts.decide({"subject": "Receipt of order", "kind": "Order", "value_cr": 20}, s, 90,
                            {"pass": True}, RULES)
        self.assertFalse(res["push"])

    def test_risky_band(self):
        s = {"symbol": "X", "fundamentals": {"ttm_sales_cr": 100}}
        res = alerts.decide({"kind": "Order", "value_cr": 50}, s, 55, {"pass": True}, RULES)
        self.assertEqual(res["buy"], "risky")


class Rules_(unittest.TestCase):
    def test_publish_needs_backtest(self):
        tmp = Path(tempfile.mkdtemp())
        (tmp / "v1.0.json").write_text(json.dumps(RULES))
        rs = RuleStore(tmp)
        rs.set_values({"breath.calm_from": 70})
        with self.assertRaises(ValueError):
            rs.publish()
        rs.draft_backtest = {"trades": 1}
        self.assertEqual(rs.publish("test"), "1.1")
        self.assertEqual(rs.live()["breath"]["calm_from"], 70)

    def test_limits(self):
        tmp = Path(tempfile.mkdtemp())
        (tmp / "v1.0.json").write_text(json.dumps(RULES))
        with self.assertRaises(ValueError):
            RuleStore(tmp).set_values({"risk.risk_pct": 10})


class Backtest(unittest.TestCase):
    def test_lower_cutoff_trades_more(self):
        U = DemoSource().universe()
        r2 = copy.deepcopy(RULES)
        r2["breath"]["calm_from"] = 60
        a = backtest.run(U, RULES, lookback_days=100)
        b = backtest.run(U, r2, lookback_days=100)
        self.assertGreaterEqual(b["trades"], a["trades"])


if __name__ == "__main__":
    unittest.main()
