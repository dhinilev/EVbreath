// Router, live price updates and Buzz Alert notifications.
import { boot, cfg, onEngine } from './api.js';
import * as live from './data/live.js';
import { about, apihub, connect, datasource, rules, settings } from './screens-settings.js';
import { alert, check, watchlist } from './screens-stock.js';
import { blast, home, multibagger, news, penny, scanner } from './screens-main.js';
import { state } from './state.js';
import { errorBox, esc, inr, loading, nav, pillHtml, toast } from './ui.js';

const ROUTES = { home, scanner, multibagger, blast, news, penny, check, alert, watchlist, settings, apihub, datasource, rules, about, connect };
const root = document.getElementById('app');
let seq = 0, cleanup = null;

async function render(keepFocus = false) {
  const [name, ...params] = (location.hash.replace(/^#\/?/, '') || 'home').split('/');
  const screen = ROUTES[name] || home;
  const my = ++seq;
  const focusedId = keepFocus && document.activeElement && document.activeElement.id;
  const caret = focusedId && document.activeElement.selectionStart;
  if (!keepFocus) root.innerHTML = loading();
  try {
    const view = await screen(params.map(decodeURIComponent));
    if (my !== seq) return;
    if (cleanup) { try { cleanup(); } catch { /* ignore */ } cleanup = null; }
    root.innerHTML = view.html + nav(view.tab);
    if (view.mount) { const c = view.mount(root, kf => render(kf)); if (typeof c === 'function') cleanup = c; }
    if (focusedId) { const el = document.getElementById(focusedId); if (el) { el.focus(); try { el.setSelectionRange(caret, caret); } catch { /* not a text input */ } } }
    if (!keepFocus) window.scrollTo(0, 0);
    // Tell the live feed which stocks are on screen (the broker feed prioritises them).
    live.setFocus([...new Set([...root.querySelectorAll('[data-ltp]')].map(e => e.dataset.ltp))].slice(0, 30));
    paintPill();
  } catch (e) {
    if (my === seq) root.innerHTML = errorBox(e) + nav('home');
  }
}

root.addEventListener('click', e => {
  const go = e.target.closest('[data-go]');
  if (go) { location.hash = go.dataset.go; return; }
  if (e.target.closest('[data-back]')) { if (history.length > 1) history.back(); else location.hash = '#/home'; }
});
window.addEventListener('hashchange', () => render());

function paintPill() {
  const p = document.querySelector('[data-live-pill]');
  if (p) p.innerHTML = pillHtml(state.live);
}

live.onLive(ev => {
  if (ev.type === 'tick') {
    document.querySelectorAll(`[data-ltp="${CSS.escape(ev.symbol)}"]`).forEach(el => {
      const dp = el.dataset.dp ? +el.dataset.dp : 2;
      el.textContent = (el.textContent.trim().startsWith('₹') ? '₹' : '') + inr(ev.ltp, dp);
      el.classList.remove('flash'); void el.offsetWidth; el.classList.add('flash');
    });
  } else if (ev.type === 'status') {
    state.live = ev.state; paintPill();
  } else if (ev.type === 'alert') {
    const a = ev.alert;
    toast(`<b>● Buzz Alert · ${esc(a.symbol)}</b>${a.watched ? ' <span class="gold">★</span>' : ''}<br><span class="small">${esc(a.subject)}</span><br><a href="#/alert/${esc(a.symbol)}" class="sb">Open</a>`, 10000);
    notify(a);
  } else if (ev.type === 'scores') refreshScreen();
});
onEngine(ev => { if (ev.type === 'scores') refreshScreen(); });
function refreshScreen() {
  const n = location.hash.replace(/^#\/?/, '').split('/')[0] || 'home';
  if (['home', 'scanner', 'blast', 'multibagger', 'watchlist', 'news'].includes(n) && !document.activeElement.matches('input')) render(true);
}

let notifId = 1;
async function notify(a) {
  const LN = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications;
  if (!LN) return;
  try {
    const perm = await LN.requestPermissions();
    if (perm.display !== 'granted') return;
    await LN.schedule({ notifications: [{ id: notifId++, title: `Buzz Alert · ${a.symbol}${a.watched ? ' ★' : ''}`, body: a.subject, extra: { symbol: a.symbol } }] });
  } catch { /* notifications optional */ }
}
const LN = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications;
if (LN) LN.addListener('localNotificationActionPerformed', ev => { const s = ev.notification.extra && ev.notification.extra.symbol; if (s) location.hash = `#/alert/${s}`; });

// Back from a broker login page (callback.html forwards the token here).
if (new URLSearchParams(location.search).has('request_token') || new URLSearchParams(location.search).has('requestToken')) location.hash = '#/connect';

boot().then(() => { state.live = live.liveState(); render(); }).catch(e => { root.innerHTML = errorBox(e) + nav('home'); });
export { cfg };
