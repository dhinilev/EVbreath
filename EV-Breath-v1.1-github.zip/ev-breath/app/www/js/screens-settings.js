// Settings, broker connection (data only), API Hub, Market data, Rules, About
import { api, cfg, reloadEngine, setMode } from './api.js';
import * as B from './data/brokers.js';
import { kv } from './data/idb.js';
import * as live from './data/live.js';
import { clearData, importFundamentals, isSyncing, syncAll, syncInfo } from './data/sync.js';
import { openExternal } from './screens-stock.js';
import { state } from './state.js';
import { band, demoRibbon, esc, icon, inr, LOGO, toast } from './ui.js';

const ago = t => { if (!t) return 'never'; const s = Math.max(0, Math.round((Date.now() - t) / 1000)); return s < 60 ? s + 's ago' : s < 3600 ? Math.round(s / 60) + ' min ago' : s < 86400 ? Math.round(s / 3600) + ' h ago' : Math.round(s / 86400) + ' days ago'; };

// ------------------------------------------------------------------ Settings
export async function settings() {
  const [rules, st, info] = await Promise.all([api('/api/rules'), B.statusAll(), syncInfo()]);
  const rk = rules.live.risk;
  let sel = state.broker || null, open = false;
  const badge = id => { const s = st[id]; return s.connected ? '<span class="badge green">CONNECTED</span>' : s.expired ? '<span class="badge orange">LOG IN TODAY</span>' : s.saved ? '<span class="badge">SAVED</span>' : '<span class="badge grey">NOT CONNECTED</span>'; };
  return {
    tab: 'home',
    html: `${demoRibbon()}${band('Settings', 'Market data, broker, rules')}
    <div class="page">
      <div class="card">
        <div class="between"><h3>Market data</h3><span class="xs ${cfg.demo ? 'orange' : 'up'} b">● ${cfg.demo ? 'DEMO' : 'LIVE'}</span></div>
        <div class="seg"><button class="${cfg.wanted === 'demo' ? 'on' : ''}" data-mode="demo">Demo market</button><button class="${cfg.wanted === 'live' ? 'on' : ''}" data-mode="live">Live NSE / BSE</button></div>
        <div class="xs muted">${cfg.wanted === 'live' ? `NSE history on this phone: ${info.days} trading days, ${info.symbols} stocks${info.latest ? ' · latest ' + info.latest : ''}.` : 'Sample market with fictional companies, to learn the app.'}</div>
        <a class="btn ghost sm" href="#/datasource" style="display:flex;align-items:center;justify-content:center">Market data &amp; sync →</a>
      </div>
      <div class="col">
        <span class="xs muted" style="letter-spacing:2px">BROKER · LIVE PRICES ONLY · NO ORDERS</span>
        <button class="card between" id="ddbtn" style="flex-direction:row;color:var(--text);text-align:left"><span class="col"><b id="ddtitle">${sel ? esc(B.BY_ID[sel].name) : 'Choose your broker'}</b><span class="xs muted" id="ddsub">${sel ? 'tap to switch' : 'HDFC Sky or Sharekhan · for live prices'}</span></span>${icon('down', 18)}</button>
        <div id="dd"></div>
        <div id="bpage"></div>
      </div>
      <div class="card list" style="gap:0">
        <a class="between" href="#/watchlist" style="padding:12px 0;color:var(--text)"><span>Watchlist &amp; alerts</span><span class="gold">→</span></a>
        <a class="between" href="#/rules" style="padding:12px 0;color:var(--text)"><span>Stock selection rules</span><span class="xs gold b">v${esc(rules.live_version)} · edit →</span></a>
        <a class="between" href="#/apihub" style="padding:12px 0;color:var(--text)"><span>API Hub · data sources</span><span class="gold">→</span></a>
        <div class="between" style="padding:12px 0"><span>Capital (for the plan)</span><span>₹${inr(rk.capital, 0)}</span></div>
        <div class="between" style="padding:12px 0"><span>Risk per trade (for the plan)</span><span>${rk.risk_pct}%</span></div>
        <a class="between" href="#/about" style="padding:12px 0;color:var(--text)"><span>About EV Breath</span><span class="gold">→</span></a>
      </div>
      <div class="xs muted" style="text-align:center">EV Breath is watch-only. It never places, changes or cancels orders.</div>
    </div>`,
    mount(root, rerender) {
      const $ = s => root.querySelector(s);
      root.querySelectorAll('[data-mode]').forEach(b => b.onclick = async () => {
        await setMode(b.dataset.mode);
        toast(b.dataset.mode === 'live' ? (cfg.demo ? 'Live chosen. Open Market data and tap Sync to download NSE history.' : 'Live NSE / BSE data on') : 'Demo market on');
        rerender();
      });
      const drawList = () => {
        if (!open) { $('#dd').innerHTML = ''; return; }
        $('#dd').innerHTML = `<div class="ddlist"><div class="ddgroup">DATA CONNECTORS · ${B.BROKERS.length}</div>${B.BROKERS.map(x => `<button class="dditem" data-b="${x.id}"><span class="col"><b class="small">${esc(x.name)}</b><span class="xs muted">${esc(x.product)} · live prices</span></span>${badge(x.id)}</button>`).join('')}</div>`;
        root.querySelectorAll('[data-b]').forEach(btn => btn.onclick = () => { sel = state.broker = btn.dataset.b; open = false; drawList(); drawPage(); });
      };
      const drawPage = async () => {
        if (!sel) { $('#bpage').innerHTML = ''; return; }
        const b = B.BY_ID[sel], c = await B.getCfg(sel), s = (await B.statusAll())[sel];
        $('#ddtitle').textContent = b.name; $('#ddsub').textContent = b.product + ' · tap to switch';
        $('#bpage').innerHTML = `<div class="card" style="margin-top:8px">
          <div class="between"><span class="col"><b>${esc(b.name)}</b><span class="xs muted">${esc(b.product)} · market data only</span></span>${badge(sel)}</div>
          ${b.fields.map(([k, label]) => `<div class="field"><label for="bf-${k}">${esc(label)}</label><input id="bf-${k}" data-f="${k}" autocomplete="off" ${/secret|key/i.test(k) && k !== 'version_id' ? 'type="password"' : ''} value="${/secret|api_key/i.test(k) ? '' : esc(c[k] || '')}" placeholder="${c[k] && /secret|api_key/i.test(k) ? '•••••••• saved' : 'Enter ' + esc(label.toLowerCase())}"></div>`).join('')}
          <div class="inner xs col" style="gap:6px"><span class="muted">Redirect URL to enter in the broker's app form</span><span class="row"><b class="grow" style="word-break:break-all">${esc(B.REDIRECT_URL)}</b><button class="btn sm ghost" id="copy">Copy</button></span></div>
          <div class="col xs muted" style="gap:4px">${b.steps.map((t, i) => `<span>${i + 1}. ${esc(t)}</span>`).join('')}<span>${esc(b.feed)}.</span></div>
          ${s.error ? `<div class="warn">${esc(s.error)}</div>` : ''}
          <div class="grid2"><button class="btn ghost sm" id="bsave">Save keys</button><button class="btn sm" id="blogin">${s.connected ? 'Log in again' : 'Save &amp; log in'}</button></div>
          <details class="xs muted"><summary>Login page did not come back to the app?</summary>
            <div class="col" style="gap:8px;margin-top:8px"><span>Log in in your browser instead, then copy the full address of the page it lands on (it contains the request token) and paste it here.</span>
            <div class="grid2"><button class="btn ghost sm" id="bext">Open login in browser</button><span></span></div>
            <div class="field"><input id="paste" placeholder="Paste the redirected link"></div><button class="btn sm" id="bpaste">Connect with link</button></div></details>
          <div class="grid2"><button class="btn ghost sm" id="bdocs">Developer portal</button><button class="btn ghost sm" id="bforget">Disconnect</button></div>
          <div id="bres"></div></div>`;
        const vals = () => { const o = {}; root.querySelectorAll('[data-f]').forEach(i => { if (i.value.trim()) o[i.dataset.f] = i.value.trim(); }); return o; };
        $('#copy').onclick = () => { try { navigator.clipboard.writeText(B.REDIRECT_URL); toast('Redirect URL copied'); } catch { toast(B.REDIRECT_URL); } };
        $('#bsave').onclick = async () => { await B.saveCfg(sel, vals()); toast('Keys saved on this phone'); drawPage(); };
        $('#blogin').onclick = async () => {
          try {
            await B.saveCfg(sel, vals());
            const url = await B.loginUrl(sel);
            await kv.set('login.pending', { broker: sel, at: Date.now() });
            location.href = url; // the broker sends you back to https://localhost/callback.html
          } catch (e) { $('#bres').innerHTML = `<div class="warn">${esc(e.message)}</div>`; }
        };
        $('#bext').onclick = async () => { try { await B.saveCfg(sel, vals()); openExternal(await B.loginUrl(sel)); } catch (e) { $('#bres').innerHTML = `<div class="warn">${esc(e.message)}</div>`; } };
        $('#bpaste').onclick = async () => {
          try { await B.finishLogin(sel, B.tokenFromUrl($('#paste').value)); await live.reconnectBroker(); $('#bres').innerHTML = `<div class="okbox">${esc(b.name)} connected for today · live prices on</div>`; drawPage(); }
          catch (e) { $('#bres').innerHTML = `<div class="warn">${esc(e.message)}</div>`; }
        };
        $('#bdocs').onclick = () => openExternal(b.portal);
        $('#bforget').onclick = async () => { await B.forget(sel); await live.reconnectBroker(); toast(`${esc(b.name)} keys removed from this phone`); drawPage(); };
      };
      $('#ddbtn').onclick = () => { open = !open; drawList(); };
      if (sel) drawPage();
    },
  };
}

// Broker login comes back here: https://localhost/callback.html -> index.html?request_token=...#/connect
export async function connect() {
  const pend = await kv.get('login.pending');
  const qs = new URLSearchParams(location.search);
  const token = qs.get('request_token') || qs.get('requestToken') || qs.get('request-token') || qs.get('code');
  let ok = false, msg = '';
  if (!pend) msg = 'No login was waiting. Start again from Settings.';
  else if (!token) msg = 'The broker did not send a request token' + (qs.get('error') || qs.get('message') ? ': ' + (qs.get('error') || qs.get('message')) : '.');
  else {
    try { await B.finishLogin(pend.broker, token); ok = true; await kv.del('login.pending'); await live.reconnectBroker(); }
    catch (e) { msg = e.message; }
  }
  history.replaceState(null, '', location.pathname + '#/connect');
  const name = pend ? B.BY_ID[pend.broker].name : 'Broker';
  return {
    tab: 'home',
    html: `${band('Broker login', name, { back: false })}<div class="page">
      ${ok ? `<div class="okbox">${esc(name)} connected for today. Live prices are on. Log in again tomorrow (broker sessions last one day).</div>` : `<div class="warn">${esc(msg)}</div>`}
      <div class="grid2"><a class="btn ghost" href="#/settings" style="display:flex;align-items:center;justify-content:center">Settings</a><a class="btn" href="#/home" style="display:flex;align-items:center;justify-content:center">Home</a></div></div>`,
  };
}

// ------------------------------------------------------------------ API Hub
const FREE = 'FREE', FM = 'FREEMIUM', PAID = 'PAID';
const HUB = [
  ['broker', 'Brokers', 'BROKER DATA CONNECTORS', 'Live prices · no orders', [['HDFC Sky Open API', 'LTP · CANDLES · YOUR ACCOUNT', FREE, 'hdfcsky'], ['Sharekhan API', 'STREAMING LTP · CANDLES', FREE, 'sharekhan']]],
  ['exch', 'Exchange', 'EXCHANGE & PUBLIC DATA', 'Built into the app', [
    ['NSE equity bhavcopy + delivery', 'DAILY PRICES · DELIVERY %', FREE, 1], ['NSE F&O bhavcopy', 'DAILY OI · BUILDUP', FREE, 1], ['NSE live market (Total Market 750)', 'LIVE PRICES · EVERY 60 S', FREE, 1],
    ['NSE indices + India VIX', 'NIFTY · VIX', FREE, 1], ['BSE SENSEX', 'LIVE INDEX', FREE, 1], ['NSE corporate announcements', 'FILINGS · BUZZ ALERTS', FREE, 1],
    ['NSE ASM / GSM / F&O ban', 'SAFETY FLAGS', FREE, 1], ['NSE FII / DII', 'FLOWS', FREE, 1], ['NSE quote (any stock)', 'WATCHLIST STOCKS', FREE, 1],
    ['BSE corporate announcements', 'BSE-ONLY STOCKS', FREE], ['BSE / NSE XBRL results', 'QUARTERLY FINANCIALS', FREE], ['AMFI mutual fund NAV & holdings', 'MF DATA', FREE]]],
  ['data', 'Live data', 'REAL-TIME DATA VENDORS', 'NSE-authorised · paid', ['TrueData', 'Global Financial Datafeeds (GDFL)', 'TradingView', 'Vtrender Charts', 'Spider Software', 'Market Pulse Technologies', 'Quantsapp', 'Reliable Software Systems', 'Ticker Data'].map(n => [n, 'RETAIL · TICK DATA · NSE/BSE', PAID])],
  ['fund', 'Fundamentals', 'FUNDAMENTALS', 'For Multibagger DNA', [['Your fundamentals CSV', 'IMPORT IN MARKET DATA', FREE, 'fund'], ['Screener.in export', 'CSV YOU DOWNLOAD', FM], ['EODHD', 'NSE/BSE EOD · FUNDAMENTALS', PAID], ['Twelve Data', 'NSE QUOTES', FM]]],
  ['news', 'News', 'NEWS', 'Headlines', [['Google News RSS', 'MEDIA COVERAGE', FREE], ['Economic Times Markets RSS', 'MARKET NEWS', FREE], ['Moneycontrol RSS', 'MARKET NEWS', FREE], ['NewsAPI.org', 'HEADLINES', FM]]],
  ['alert', 'Alerts', 'ALERTS', 'Notify you', [['Android notifications', 'BUZZ ALERTS · WATCHLIST', FREE, 1], ['Telegram Bot API', 'ALERTS', FREE], ['Gmail API / SMTP', 'EMAIL DIGEST', FREE]]],
  ['chart', 'Charts & AI', 'CHARTS & AI', 'Display and explain', [['TradingView Lightweight Charts', 'CHART LIBRARY', FREE], ['Claude API (Anthropic)', 'AI NEWS SUMMARY', PAID]]],
];
const PC = { FREE: 'var(--green)', FREEMIUM: 'var(--blue2)', PAID: 'var(--orange)' };

export async function apihub() {
  const st = await B.statusAll();
  const fund = await kv.get('fund', {});
  const on = a => a[3] === 1 ? !cfg.demo : a[3] === 'fund' ? Object.keys(fund).length > 0 : a[3] ? !!(st[a[3]] && st[a[3]].connected) : false;
  const all = HUB.flatMap(c => c[4]);
  const cat = state.hubCat, q = (state.hubQ || '').toLowerCase();
  const groups = HUB.filter(c => cat === 'all' || cat === c[0]).map(c => [c, c[4].filter(a => !q || (a[0] + a[1]).toLowerCase().includes(q))]).filter(([, l]) => l.length);
  return {
    tab: 'home',
    html: `${band('API Hub', 'Where EV Breath gets its data')}
    <div class="page">
      <div class="stats"><div class="stat"><span class="k">Listed</span><span class="v">${all.length}</span></div><div class="stat"><span class="k">In use</span><span class="v up">${all.filter(on).length}</span></div><div class="stat"><span class="k">Free</span><span class="v gold">${all.filter(a => a[2] === FREE).length}</span></div></div>
      <label class="search">${icon('scan', 18)}<input id="hq" value="${esc(state.hubQ || '')}" placeholder="Search any API"></label>
      <div class="chips"><button class="chip ${cat === 'all' ? 'on' : ''}" data-c="all">All ${all.length}</button>${HUB.map(c => `<button class="chip ${cat === c[0] ? 'on' : ''}" data-c="${c[0]}">${c[1]} ${c[4].length}</button>`).join('')}</div>
      ${groups.map(([c, l]) => `<div class="col"><div class="between" style="padding-top:6px"><span class="xs gold" style="letter-spacing:2px">${c[2]} · ${l.length}</span><span class="xs muted">${c[3]}</span></div>
        <div class="list">${l.map(a => `<div class="between" style="padding:10px 0"><span class="col"><b class="small">${esc(a[0])}</b><span class="xs muted">${esc(a[1])}</span></span><span class="row">${on(a) ? '<span class="badge green">ON</span>' : ''}<span class="tag" style="border-color:${PC[a[2]]};color:${PC[a[2]]}">${a[2]}</span></span></div>`).join('')}</div></div>`).join('') || '<div class="empty">No API matches</div>'}
      <div class="xs muted">Broker connectors read prices only. FREE / FREEMIUM / PAID is a guide; check each provider's plan. Exchange and broker data are for your own use.</div>
    </div>`,
    mount(root, rerender) {
      root.querySelectorAll('[data-c]').forEach(b => b.onclick = () => { state.hubCat = b.dataset.c; rerender(); });
      const i = root.querySelector('#hq'); let t; i.oninput = () => { clearTimeout(t); t = setTimeout(() => { state.hubQ = i.value; rerender(true); }, 300); };
    },
  };
}

// ------------------------------------------------------------------ Market data
const C = { ACTIVE: 'var(--green)', STANDBY: 'var(--blue2)', DOWN: 'var(--red)', 'NOT CONNECTED': 'var(--muted)', 'LOGIN NEEDED': 'var(--orange)', 'MARKET CLOSED': 'var(--muted)', 'OFF HOURS': 'var(--muted)', RECONNECTING: 'var(--orange)' };
export async function datasource() {
  const [info, st, fund, auto] = await Promise.all([syncInfo(), api('/api/status'), kv.get('fund', {}), kv.get('sync.auto', true)]);
  const F = live.feeds;
  const order = cfg.wanted === 'demo' ? [F.demo] : [F.broker, F.nse, F.bse, F.filings];
  const activeFeed = order.find(f => f.state === 'ACTIVE');
  return {
    tab: 'home',
    html: `${demoRibbon()}${band('Market Data', 'NSE / BSE + your broker · watch-only')}
    <div class="page">
      <div class="seg"><button class="${cfg.wanted === 'demo' ? 'on' : ''}" data-mode="demo">Demo market</button><button class="${cfg.wanted === 'live' ? 'on' : ''}" data-mode="live">Live NSE / BSE</button></div>
      <div class="card" style="border-color:${activeFeed ? '#1F4A37' : 'var(--line)'}"><div class="between"><b class="${activeFeed ? 'up' : 'muted'}"><span class="dot ${activeFeed ? '' : 'off'}"></span> ${activeFeed ? 'LIVE · ' + esc(activeFeed.name.toUpperCase()) : cfg.wanted === 'live' && !live.marketOpen() ? 'MARKET CLOSED · LAST CLOSE' : 'NO LIVE FEED'}</b><span class="xs muted">${cfg.demo ? 'DEMO' : 'LIVE'}</span></div>
        <div class="grid3"><div class="col"><span class="xs muted">SCORED</span><b>${inr(st.universe, 0)}</b></div><div class="col"><span class="xs muted">LAST TICK</span><b>${activeFeed && activeFeed.last ? ago(activeFeed.last) : '—'}</b></div><div class="col"><span class="xs muted">PRICES</span><b>${inr(live.lastPrices.size, 0)}</b></div></div></div>
      ${cfg.wanted === 'live' ? `
      <div class="card">
        <div class="between"><h3>NSE history on this phone</h3>${icon('sync', 20)}</div>
        <div class="grid3"><div class="col"><span class="xs muted">DAYS</span><b>${info.days}</b></div><div class="col"><span class="xs muted">STOCKS</span><b>${inr(info.symbols, 0)}</b></div><div class="col"><span class="xs muted">LATEST</span><b>${esc(info.latest || '—')}</b></div></div>
        <div id="prog" class="col" style="gap:6px"></div>
        <div class="xs muted">${info.days < 200 ? 'First sync downloads about a year of NSE daily files (price, delivery %, F&amp;O OI, NIFTY, India VIX): roughly 300 small files, a few minutes on Wi-Fi. Keep the app open.' : 'After 6:30 PM IST the day\'s files are added automatically while the app is open.'} Last sync: ${ago(info.last)}.</div>
        ${(info.errors || []).length ? `<details class="xs muted"><summary>${info.errors.length} note(s) from the last sync</summary>${info.errors.map(e => `<div>${esc(e)}</div>`).join('')}</details>` : ''}
        <div class="grid2"><button class="btn sm" id="sync">${info.days ? 'Sync now' : 'Download history'}</button><button class="btn ghost sm" id="auto">Auto daily sync: ${auto ? 'ON' : 'OFF'}</button></div>
      </div>
      <span class="xs muted" style="letter-spacing:2px">LIVE FEEDS · AUTO FAILOVER</span>
      <div class="list">${order.map((f, i) => `<div class="between" style="padding:12px 0"><span class="row"><span class="tag" style="border-color:${C[f.state] || 'var(--muted)'};color:${C[f.state] || 'var(--muted)'}">${i + 1}</span><span class="col"><b class="small">${esc(f.name)}</b><span class="xs muted">${esc(f.kind)}${f.error ? ' · ' + esc(f.error) : ''}</span></span></span>
        <span class="tag" style="border-color:${C[f.state] || 'var(--muted)'};color:${C[f.state] || 'var(--muted)'}">${esc(f.state)}</span></div>`).join('')}</div>
      <div class="xs muted">Broker first (when you are logged in today), else NSE's public live data. Prices refresh every 5–60 seconds; scores every 5 minutes.</div>
      <div class="card">
        <h3>Fundamentals (Multibagger DNA)</h3>
        <div class="xs muted">NSE files have no sales, ROCE, debt or promoter data. Import a CSV with these columns (one row per company): symbol, name, sector, mcap_cr, promoter_pct, promoter_change_4q, pledge_pct, sales_cagr3, profit_cagr3, sales_yoy_q1, sales_yoy_q2, roce, roce3y, de, icr, pe, sector_pe, ttm_sales_cr, results_in_days</div>
        <div class="between small"><span>Companies imported</span><b>${Object.keys(fund).length}</b></div>
        <label class="btn ghost sm" style="display:flex;align-items:center;justify-content:center">Import CSV<input type="file" id="csv" accept=".csv,text/csv,text/plain" style="display:none"></label>
        <div id="csvres"></div>
      </div>
      <button class="btn ghost sm" id="clear">Delete downloaded market data</button>` : `<div class="card small dim">The demo market uses fictional companies so you can learn every screen. Switch to <b>Live NSE / BSE</b> above to download real data.</div>`}
    </div>`,
    mount(root, rerender) {
      const $ = s => root.querySelector(s);
      root.querySelectorAll('[data-mode]').forEach(b => b.onclick = async () => { await setMode(b.dataset.mode); rerender(); });
      if (cfg.wanted !== 'live') return;
      const prog = p => { $('#prog').innerHTML = `<div class="between xs"><span>${esc(p.phase)}${p.note ? ' · ' + esc(p.note) : ''}</span><span>${p.total ? Math.round(p.done / p.total * 100) : 0}%</span></div><div class="bar"><i style="width:${p.total ? p.done / p.total * 100 : 0}%"></i></div>`; };
      const run = async () => {
        $('#sync').disabled = true; $('#sync').textContent = 'Syncing…';
        try {
          const r = await syncAll({ onProgress: prog });
          await reloadEngine();
          toast(r.upToDate ? 'Already up to date' : `Added ${r.added} trading day(s)${r.errors.length ? ' · ' + r.errors.length + ' note(s)' : ''}`);
        } catch (e) { toast(esc(e.message)); }
        rerender();
      };
      $('#sync').onclick = run;
      if (isSyncing()) { $('#sync').disabled = true; $('#sync').textContent = 'Syncing…'; }
      $('#auto').onclick = async () => { await kv.set('sync.auto', !(await kv.get('sync.auto', true))); rerender(); };
      $('#csv').onchange = async e => {
        const f = e.target.files[0]; if (!f) return;
        try { const n = await importFundamentals(await f.text()); await reloadEngine(); $('#csvres').innerHTML = `<div class="okbox">Imported ${n} companies</div>`; }
        catch (err) { $('#csvres').innerHTML = `<div class="warn">${esc(err.message)}</div>`; }
      };
      $('#clear').onclick = async () => { if (!confirm('Delete all downloaded NSE data from this phone? Your watchlist, rules and broker keys stay.')) return; await clearData(); await reloadEngine(); rerender(); };
      const off = live.onLive(ev => { if (ev.type === 'sync') prog(ev.p); });
      return off;
    },
  };
}

// ------------------------------------------------------------------ Rules
const RULES_UI = [
  ['Safety gates', 'Fail = Avoid', [['gates.main.min_price', 'Minimum price', 20, 500, 10, v => '₹' + v], ['gates.main.min_turnover_cr', 'Minimum daily turnover', 1, 100, 1, v => '₹' + v + ' cr'], ['gates.main.max_pledge_pct', 'Maximum promoter pledge', 0, 50, 1, v => v + '%']]],
  ['Market filter', 'Breath Meter 0–100', [['market.panic_below', 'Panic below', 10, 50, 1, String], ['market.euphoria_above', 'Euphoria above', 60, 95, 1, String]]],
  ['Breath Score', 'Scanner and Stock Check', [['breath.calm_from', 'Calm Buy Zone from', 50, 95, 1, String], ['breath.wait_from', 'Wait for the Breath from', 40, 80, 1, String], ['breath.no_chase_pct', 'No chasing above entry by', 1, 15, 1, v => v + '%']]],
  ['Multibagger DNA', 'Reviewed quarterly', [['dna.tests_to_pass', 'Tests to pass', 3, 6, 1, v => v + ' of 6'], ['dna.growth_pct', 'Sales & profit growth (3Y)', 10, 40, 1, v => v + '%'], ['dna.roce_pct', 'Minimum ROCE', 10, 30, 1, v => v + '%']]],
  ['Blast Fuse', 'Coiled stocks', [['fuse.lit_from', 'Fuse lit from', 40, 90, 1, String], ['fuse.ignite_volume_ratio', 'Ignite on volume', 1, 3, 0.1, v => (+v).toFixed(1) + '×']]],
  ['Penny Buzz', 'Buzz vs Substance', [['penny.real_from', 'Real trigger from Substance', 40, 90, 1, String], ['penny.pump_buzz_from', 'Pump risk from Buzz', 50, 95, 1, String], ['penny.risk_pct', 'Risk per penny trade', 0.1, 1, 0.1, v => (+v).toFixed(1) + '%']]],
  ['Plan and risk', 'For the plan card (no orders)', [['risk.capital', 'Capital', 10000, 5000000, 10000, v => '₹' + inr(v, 0)], ['risk.risk_pct', 'Risk per trade', 0.25, 3, 0.25, v => v + '%'], ['risk.max_positions', 'Maximum open positions', 2, 15, 1, String], ['risk.time_stop_sessions', 'Time stop', 5, 40, 1, v => v + ' sessions']]],
];
const getp = (o, p) => p.split('.').reduce((a, k) => a[k], o);

export async function rules() {
  const d = await api('/api/rules');
  const live = d.live;
  const draft = {};
  for (const [p, ch] of Object.entries(d.draft_diff || {})) draft[p] = ch.new;
  let bt = null;
  return {
    tab: 'home',
    html: `${demoRibbon()}${band('Rules', 'Every number the app uses to pick stocks', { right: `<span class="pill" style="color:var(--gold)" id="ver">v${esc(d.live_version)} · live</span>` })}
    <div class="page">
      ${RULES_UI.map(([t, sub, items]) => `<div class="card"><div class="between"><h3>${t}</h3><span class="xs muted">${sub}</span></div>
        ${items.map(([p, label, min, max, step, fmt]) => { const v = draft[p] ?? getp(live, p); return `<div class="col" style="gap:6px;padding:8px 0;border-top:1px solid var(--line2)">
          <div class="between"><label for="${p}" class="small">${label}</label><span class="row"><span class="badge" data-ed="${p}" style="display:${p in draft ? 'inline' : 'none'};font-size:10px">EDITED</span><b class="gold" data-v="${p}">${fmt(v)}</b></span></div>
          <input type="range" id="${p}" data-p="${p}" min="${min}" max="${max}" step="${step}" value="${v}"></div>`; }).join('')}</div>`).join('')}
      <div id="bt"></div>
      ${d.changelog && d.changelog.length ? `<div class="card"><h3>Change log</h3>${d.changelog.map(c => `<div class="small"><b>v${esc(c.version)}</b> · ${esc(c.date)} · ${Object.keys(c.changes).length} change(s)${c.reason ? ' · ' + esc(c.reason) : ''}</div>`).join('')}</div>` : ''}
      <div class="sheet"><span class="xs muted" id="status" style="text-align:center"></span>
        <div class="grid2"><button class="btn ghost" id="reset">Reset to v${esc(d.live_version)}</button><button class="btn" id="cta"></button></div></div>
    </div>`,
    mount(root, rerender) {
      const $ = s => root.querySelector(s);
      const fmtOf = Object.fromEntries(RULES_UI.flatMap(g => g[2]).map(r => [r[0], r[5]]));
      const refresh = () => {
        const n = Object.keys(draft).length;
        $('#ver').textContent = n ? `v${d.live_version} → draft` : `v${d.live_version} · live`;
        $('#status').textContent = n === 0 ? `Live rules: v${d.live_version}` : bt ? `${n} change(s) backtested · ready to save` : `${n} unsaved change(s) · backtest before going live`;
        $('#cta').textContent = n === 0 ? 'Run backtest' : bt ? 'Save new version' : 'Backtest changes';
      };
      let timer;
      root.querySelectorAll('[data-p]').forEach(inp => inp.oninput = () => {
        const p = inp.dataset.p, v = parseFloat(inp.value);
        if (Math.abs(v - getp(live, p)) < 1e-9) delete draft[p]; else draft[p] = v;
        root.querySelector(`[data-v="${p}"]`).textContent = fmtOf[p](v);
        root.querySelector(`[data-ed="${p}"]`).style.display = p in draft ? 'inline' : 'none';
        bt = null; $('#bt').innerHTML = ''; refresh();
        clearTimeout(timer);
        timer = setTimeout(async () => {
          try { await api('/api/rules/reset', { method: 'POST' }); if (Object.keys(draft).length) await api('/api/rules/draft', { method: 'PUT', body: { changes: draft } }); }
          catch (e) { toast(esc(e.message)); }
        }, 400);
      });
      $('#reset').onclick = async () => { await api('/api/rules/reset', { method: 'POST' }); rerender(); };
      $('#cta').onclick = async () => {
        const n = Object.keys(draft).length;
        if (n && bt) {
          const reason = prompt('Why this change? (saved in the change log)', '') || '';
          try { const res = await api('/api/rules/publish', { method: 'POST', body: { reason } }); toast(`Rules v${esc(res.live_version)} are live`); rerender(); }
          catch (e) { toast(esc(e.message)); }
          return;
        }
        $('#cta').disabled = true; $('#cta').textContent = 'Backtesting…';
        try {
          const r = await api('/api/rules/backtest?days=250', { method: 'POST' });
          if (!r.universe) throw new Error(cfg.demo ? 'The demo market is too short for a backtest. Use live NSE data (230+ days).' : 'Not enough history yet: a backtest needs 230+ trading days. Sync in Market data.');
          bt = r;
          const row = (k, x) => `<div class="grid3 small"><span class="sb">${k}</span><span>${x.trades} trades · ${x.hit_rate_pct ?? '—'}% hit</span><span>avg ${x.avg_r ?? '—'} R</span></div>`;
          $('#bt').innerHTML = `<div class="card hl"><h3>Backtest · last 250 sessions</h3>${row('Live v' + d.live_version, r.live)}${n ? row('Your draft', r.draft) : ''}<span class="xs muted">Paper trades on the ${r.universe} most-traded stocks. Past results do not promise future ones.</span></div>`;
        } catch (e) { toast(esc(e.message)); }
        $('#cta').disabled = false; refresh();
      };
      refresh();
    },
  };
}


// ------------------------------------------------------------------ About
export async function about() {
  const steps = [['Scan', 'Every evening after close, the whole market is checked against the rules, on your phone.'], ['Check substance', 'Is there real news, delivery and OI behind the move, or only buzz?'],
    ['Wait for the breath', 'A calm pullback or a clean base breakout. Never chase.'], ['Plan before you buy', 'Entry zone, stop-loss and quantity at 1% risk, worked out for you.'], ['You decide', 'EV Breath only watches and alerts. Any order is yours, placed in your own broker app.']];
  return {
    tab: 'home',
    html: `${band('About', '')}
    <div class="page" style="align-items:stretch">
      <div class="col" style="align-items:center;gap:8px;padding:8px 0"><div class="logo" style="width:84px;height:84px;border-radius:20px">${LOGO.replace(/width="28" height="28"/, 'width="64" height="64"')}</div>
        <span class="brand" style="font-size:34px">EV <span>Breath</span></span><span class="small muted" style="letter-spacing:5px">TRADE CALM.</span><span class="xs muted">An Erulenkattil Veettil Group · v1.1 · watch-only</span></div>
      <div class="card row" style="flex-direction:row"><span class="ring" style="width:52px;height:52px;border-width:2px"><b style="font-size:20px" class="gold">V</b></span><span class="col"><span class="xs muted">Created by</span><b>Valerian</b><span class="small dim">12+ years in the market</span></span></div>
      <div class="small dim" style="line-height:1.55">EV Pulse reads the options market. <b style="color:var(--text)">EV Breath reads equity stocks</b>: trend, delivery, OI, fundamentals and real news. The market always moves for a reason. Breath helps you find it calmly, and plan every buy before you take it.</div>
      <span class="xs muted" style="letter-spacing:2px">THE PLAN TO BUY</span>
      <div class="list">${steps.map(([t, s], i) => `<div class="row" style="padding:9px 0;align-items:flex-start"><b class="gold small" style="width:24px">0${i + 1}</b><span class="col"><b class="small">${t}</b><span class="xs muted">${s}</span></span></div>`).join('')}</div>
      <div class="col" style="align-items:center;gap:4px"><b class="gold">No luck. Only information.</b><span class="xs muted">Sister app: EV Pulse (options) · An information tool, not investment advice. No orders are ever placed from this app.</span></div>
    </div>`,
  };
}
