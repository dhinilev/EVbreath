// The app's data API. Everything is computed on the phone by the engine worker; no server is needed.
// Paths are the same as the old server's (/api/...), so each screen just asks for what it shows.
import { kv } from './data/idb.js';
import * as live from './data/live.js';

const pending = new Map();
let seq = 0;
let worker = null, core = null;
const engineListeners = new Set();
export const onEngine = fn => { engineListeners.add(fn); return () => engineListeners.delete(fn); };

function startWorker() {
  try {
    worker = new Worker(new URL('./engine/worker.js', import.meta.url), { type: 'module' });
    worker.onmessage = e => {
      const m = e.data;
      if (m.event) { engineListeners.forEach(fn => fn(m.event)); return; }
      const p = pending.get(m.id);
      if (!p) return;
      pending.delete(m.id);
      if (m.ok) p.resolve(m.data); else p.reject(new Error(m.error));
    };
    // If the worker cannot start, answer everything on the page instead.
    worker.onerror = e => {
      if (e && e.preventDefault) e.preventDefault();
      worker = null;
      const waiting = [...pending.values()];
      pending.clear();
      waiting.forEach(p => send(p.msg).then(p.resolve, p.reject));
    };
  } catch { worker = null; }
}
startWorker();

async function send(msg) {
  if (worker) {
    const id = ++seq;
    return new Promise((resolve, reject) => {
      pending.set(id, { resolve, reject, msg });
      worker.postMessage({ id, msg });
    });
  }
  // Fallback: run the engine on the page if workers are unavailable.
  if (!core) { const { createCore } = await import('./engine/core.js'); core = createCore(ev => engineListeners.forEach(fn => fn(ev))); }
  return core.handle(msg);
}

export const engine = { send };

export async function api(path, { method = 'GET', body } = {}) {
  return send({ path, method, body });
}

// App mode: "demo" (sample market) or "live" (NSE / BSE + your broker)
export const cfg = {
  mode: 'demo',          // what the engine is actually showing
  wanted: 'demo',        // what you chose
  get demo() { return this.mode === 'demo'; },
};

export async function refreshStatus() {
  const s = await api('/api/status');
  cfg.mode = s.mode; cfg.wanted = s.wanted;
  return s;
}

export async function setMode(m) {
  await kv.set('mode', m);
  await send({ type: 'reload' });
  await refreshStatus();
  await live.startLive(engine, cfg.wanted);
}

export async function reloadEngine() { await send({ type: 'reload' }); await refreshStatus(); }

export async function boot() {
  await refreshStatus();
  await live.startLive(engine, cfg.wanted);
}

// Watchlist (kept on the phone)
export const watch = {
  async list() { return (await kv.get('watchlist', [])) || []; },
  async has(sym) { return (await this.list()).includes(sym); },
  async toggle(sym) {
    const l = await this.list();
    const next = l.includes(sym) ? l.filter(x => x !== sym) : [sym, ...l].slice(0, 60);
    await kv.set('watchlist', next);
    return next.includes(sym);
  },
};
