// The engine's request handler. Runs inside a Web Worker so scoring never freezes the screen.
// It answers the same paths the old server did (/api/...), all computed on the phone.
import { idb, kv } from '../data/idb.js';
import { isMaterial } from './alerts.js';
import { compare } from './backtest.js';
import { DEMO_MARKET } from './demo-market.js';
import { Engine } from './engine.js';
import { RuleStore } from './rules.js';
import * as sc from './scoring.js';
import { DemoSource, LiveSource } from './sources.js';

export function createCore(emit = () => {}) {
  let rules = null, engine = null, mode = 'demo', fallback = false, ready = null, liveSrc = null;

  async function boot() {
    rules = await new RuleStore().load();
    mode = (await kv.get('mode', 'demo')) || 'demo';
    let source;
    fallback = false;
    if (mode === 'live') {
      liveSrc = await new LiveSource().load(idb, kv);
      for (const s of liveSrc.universe()) for (const f of s.filings) f.material = isMaterial(f, s, rules.live());
      if (liveSrc.universe().filter(s => s.bars.length >= 60).length >= 20 && liveSrc.index('NIFTY').length >= 2) source = liveSrc;
      else { fallback = true; source = new DemoSource(DEMO_MARKET); }
    } else source = new DemoSource(DEMO_MARKET);
    engine = new Engine(rules, source);
    engine.recompute();
    emit({ type: 'scores', at: Date.now(), mode: status().mode });
  }
  ready = boot();

  function status() {
    const d = engine.cache || {};
    return { mode: fallback ? 'demo' : mode, wanted: mode, fallback, source: engine.source.name, universe: d.universe_size || 0,
      computed_at: engine.computedAt, rules: rules.liveVersion() };
  }

  const q = (u, k, dflt = '') => u.searchParams.get(k) ?? dflt;

  async function route(path, method = 'GET', body = {}) {
    await ready;
    const u = new URL('http://x' + path);
    const p = u.pathname;
    let m;
    if (p === '/api/status') return status();
    if (p === '/api/home') return { ...engine.home(), status: status() };
    if (p === '/api/scanner') return engine.scanner(q(u, 'preset', 'breath'), q(u, 'q'), q(u, 'fno') === '1');
    if (p === '/api/multibagger') return engine.multibagger(q(u, 'stage', 'Early'));
    if (p === '/api/blast') return engine.blast(q(u, 'tab', 'lit'));
    if (p === '/api/news') return engine.news(q(u, 'tab', 'mb'));
    if (p === '/api/penny') return engine.pennyBoard(q(u, 'hide_asm', '1') === '1', q(u, 'band'));
    if (p === '/api/search') return engine.search(q(u, 'q'));
    if (p === '/api/watchlist') return engine.watchlist(q(u, 'symbols').split(',').filter(Boolean));
    if (p === '/api/alerts') return { alerts: engine.data().alerts };
    if ((m = p.match(/^\/api\/check\/(.+)$/))) {
      const r = engine.check(decodeURIComponent(m[1]));
      if (!r) throw new Error(status().mode === 'demo'
        ? 'Not in the demo market. Switch Market data to Live (NSE / BSE) to check any listed stock.'
        : 'Not found in your NSE data yet. Check the symbol, or run Market data › Sync.');
      return r;
    }
    if ((m = p.match(/^\/api\/alert\/(.+)$/))) {
      const r = engine.alert(decodeURIComponent(m[1]));
      if (!r) throw new Error('Symbol not found');
      return r;
    }
    if (p === '/api/rules') {
      return { live: rules.live(), draft_diff: rules.diff(), versions: rules.versions(), live_version: rules.liveVersion(),
        backtest: rules.draftBacktest, changelog: rules.log.slice(0, 20) };
    }
    if (p === '/api/rules/draft') return { diff: rules.setValues((body && body.changes) || {}) };
    if (p === '/api/rules/reset') { rules.reset(); return { ok: true }; }
    if (p === '/api/rules/backtest') {
      const draft = rules.draft || rules.live();
      const pennyMax = rules.live().gates.penny.max_price;
      // Keep it quick on a phone: the 120 most-traded stocks above the penny band.
      const U = engine.source.universe().filter(s => s.bars.length >= 230 && sc.lastClose(s) > pennyMax)
        .sort((a, b) => sc.turnoverCr(b) - sc.turnoverCr(a)).slice(0, 120);
      const res = compare(U, rules.live(), draft, { lookbackDays: parseInt(q(u, 'days', '250'), 10) });
      res.universe = U.length;
      if (rules.draft) rules.draftBacktest = res.draft;
      return res;
    }
    if (p === '/api/rules/publish') { const v = await rules.publish((body && body.reason) || ''); engine.recompute(); emit({ type: 'scores', at: Date.now() }); return { live_version: v }; }
    if (p === '/api/rules/restore') { await rules.restore(body.version); engine.recompute(); return { live_version: rules.liveVersion() }; }
    throw new Error(`Unknown request ${method} ${p}`);
  }

  async function handle(msg) {
    if (msg.type === 'reload') { ready = boot(); await ready; return status(); }
    if (msg.type === 'ticks') {
      await ready;
      let moved = 0;
      for (const t of msg.ticks || []) if (engine.source.applyTick && engine.source.applyTick(t.symbol, t.ltp)) moved++;
      return { moved };
    }
    if (msg.type === 'quotes') {
      await ready;
      if (engine.source.applyQuotes) engine.source.applyQuotes(msg.today);
      return { ok: true };
    }
    if (msg.type === 'recompute') {
      await ready;
      engine.recompute();
      emit({ type: 'scores', at: Date.now() });
      return { alerts: engine.cache.alerts.filter(a => a.push) };
    }
    return route(msg.path, msg.method, msg.body);
  }

  return { handle };
}
