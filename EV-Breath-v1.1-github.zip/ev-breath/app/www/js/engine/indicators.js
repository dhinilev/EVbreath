// Technical indicators. Every function takes oldest-first arrays.
// A bar is {date, open, high, low, close, volume}.

export function sma(xs, n) {
  if (n <= 0 || xs.length < n) return null;
  let s = 0;
  for (let i = xs.length - n; i < xs.length; i++) s += xs[i];
  return s / n;
}

export function smaSeries(xs, n) {
  const out = new Array(xs.length);
  let run = 0;
  for (let i = 0; i < xs.length; i++) {
    run += xs[i];
    if (i >= n) run -= xs[i - n];
    out[i] = i >= n - 1 ? run / n : null;
  }
  return out;
}

export function emaSeries(xs, n) {
  const out = new Array(xs.length);
  const k = 2 / (n + 1);
  let e = null;
  for (let i = 0; i < xs.length; i++) {
    if (i < n - 1) { out[i] = null; continue; }
    if (e === null) { let s = 0; for (let j = i - n + 1; j <= i; j++) s += xs[j]; e = s / n; }
    else e = xs[i] * k + e * (1 - k);
    out[i] = e;
  }
  return out;
}

export function ema(xs, n) {
  const s = emaSeries(xs, n);
  return s.length ? s[s.length - 1] : null;
}

export function trueRanges(bars) {
  return bars.map((b, i) => {
    if (i === 0) return b.high - b.low;
    const pc = bars[i - 1].close;
    return Math.max(b.high - b.low, Math.abs(b.high - pc), Math.abs(b.low - pc));
  });
}

// Wilder's ATR.
export function atrSeries(bars, n = 14) {
  const trs = trueRanges(bars);
  const out = new Array(trs.length);
  let a = null;
  for (let i = 0; i < trs.length; i++) {
    if (i < n - 1) { out[i] = null; continue; }
    if (a === null) { let s = 0; for (let j = i - n + 1; j <= i; j++) s += trs[j]; a = s / n; }
    else a = (a * (n - 1) + trs[i]) / n;
    out[i] = a;
  }
  return out;
}

export function atr(bars, n = 14) {
  const s = atrSeries(bars, n);
  return s.length ? s[s.length - 1] : null;
}

// Bollinger Band width as a fraction of the middle band.
export function bbWidthSeries(closes, n = 20, k = 2) {
  const out = new Array(closes.length);
  for (let i = 0; i < closes.length; i++) {
    if (i < n - 1) { out[i] = null; continue; }
    let m = 0;
    for (let j = i - n + 1; j <= i; j++) m += closes[j];
    m /= n;
    let v = 0;
    for (let j = i - n + 1; j <= i; j++) v += (closes[j] - m) ** 2;
    const sd = Math.sqrt(v / n);
    out[i] = m ? (2 * k * sd) / m : null;
  }
  return out;
}

// Percent change from b to a.
export const pctChange = (a, b) => (b ? (a / b - 1) * 100 : 0);

export function ret(closes, n) {
  if (closes.length <= n) return null;
  return pctChange(closes[closes.length - 1], closes[closes.length - 1 - n]);
}

// Pivot lows: a low lower than the k bars on each side. Returns [index, low] pairs.
export function swingLows(bars, k = 3) {
  const out = [];
  for (let i = k; i < bars.length - k; i++) {
    const lo = bars[i].low;
    let ok = true;
    for (let j = i - k; j < i && ok; j++) if (!(lo < bars[j].low)) ok = false;
    for (let j = i + 1; j <= i + k && ok; j++) if (!(lo <= bars[j].low)) ok = false;
    if (ok) out.push([i, lo]);
  }
  return out;
}

// Share (0-100) of the population at or below value.
export function percentileOf(value, population) {
  const pop = population.filter(p => p !== null && p !== undefined);
  if (!pop.length) return 50;
  let n = 0;
  for (const p of pop) if (p <= value) n++;
  return (100 * n) / pop.length;
}

export function highOf(bars, n) {
  let m = -Infinity;
  for (let i = Math.max(0, bars.length - n); i < bars.length; i++) if (bars[i].high > m) m = bars[i].high;
  return m;
}

export function lowOf(bars, n) {
  let m = Infinity;
  for (let i = Math.max(0, bars.length - n); i < bars.length; i++) if (bars[i].low < m) m = bars[i].low;
  return m;
}

export function avgVolume(bars, n, skipLast = 0) {
  const end = bars.length - skipLast;
  const start = Math.max(0, end - n);
  if (end - start < n) return null;
  let s = 0;
  for (let i = start; i < end; i++) s += bars[i].volume;
  return s / n;
}

export function isInsideDay(bars) {
  if (bars.length < 2) return false;
  const a = bars[bars.length - 2], b = bars[bars.length - 1];
  return b.high <= a.high && b.low >= a.low;
}

export function isNr7(bars) {
  if (bars.length < 7) return false;
  const r = bars.slice(-7).map(b => b.high - b.low);
  return r[6] === Math.min(...r);
}

// Python-style round (half to even), so results match the rulebook tests.
export function rnd(x, nd = 0) {
  if (x === null || x === undefined || !isFinite(x)) return x;
  if (nd === 0) {
    const f = Math.floor(x);
    const d = x - f;
    if (d === 0.5) return f % 2 === 0 ? f : f + 1;
    return Math.round(x);
  }
  // toFixed rounds the exact binary value, like Python does.
  return Number(x.toFixed(nd));
}
