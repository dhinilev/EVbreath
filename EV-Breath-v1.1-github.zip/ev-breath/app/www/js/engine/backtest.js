// Walk-forward backtest of the Breath Score rules on daily bars.
// Each day is scored with data up to that day only. A Calm Buy Zone with no open position "enters" at
// that close. The paper trade then follows the plan rules: stop-loss, trail at the 20 EMA after +10%,
// exit on a close below the 50-day average, or the time stop. Paper trades only: nothing is ever ordered.
import * as ind from './indicators.js';
import * as sc from './scoring.js';

const WARMUP = 210;
const rnd = ind.rnd;

function slice(s, end) {
  return { ...s, bars: s.bars.slice(0, end), delivery: (s.delivery || []).slice(0, end), oi: s.oi ? s.oi.slice(0, end) : null };
}

// Per-day relative-strength population and sector strength, keyed by bars back from the end.
function dailyContext(universe, rules) {
  const main = universe.filter(s => sc.lastClose(s) > rules.gates.penny.max_price);
  if (!main.length) return {};
  const n = Math.min(...main.map(s => s.bars.length));
  const cl = {}, m50 = {};
  for (const s of main) { cl[s.symbol] = s.bars.slice(-n).map(b => b.close); m50[s.symbol] = ind.smaSeries(cl[s.symbol], 50); }
  const ctx = {};
  for (let back = 0; back < n - 64; back++) {
    const i = n - 1 - back;
    const rs = {};
    for (const [k, v] of Object.entries(cl)) rs[k] = ind.pctChange(v[i], v[i - 63]);
    const sect = {};
    for (const s of main) {
      const m = m50[s.symbol][i];
      if (m) (sect[s.sector] = sect[s.sector] || []).push(cl[s.symbol][i] > m);
    }
    const above = {};
    for (const [k, v] of Object.entries(sect)) above[k] = v.filter(Boolean).length / v.length > 0.5;
    ctx[back] = { rs_returns: rs, sector_above_50: above };
  }
  return ctx;
}

export function run(universe, rules, { lookbackDays = 750, step = 1 } = {}) {
  const rk = rules.risk;
  const trades = [];
  const meterOk = { zone: 'Calm' };
  const dayCtx = dailyContext(universe, rules);
  const empty = { rs_returns: {}, sector_above_50: {} };
  for (const s of universe) {
    const bars = s.bars;
    if (bars.length < WARMUP + 20 || sc.lastClose(s) <= rules.gates.penny.max_price) continue;
    const start = Math.max(WARMUP, bars.length - lookbackDays);
    let pos = null;
    for (let i = start; i < bars.length; i++) {
      const price = bars[i].close;
      if (pos === null) {
        if ((i - start) % step === 0) {
          const sub = slice(s, i + 1);
          const g = sc.checkGates(sub, rules, 'main');
          const b = sc.breathScore(sub, dayCtx[bars.length - 1 - i] || empty, rules);
          if (sc.breathVerdict(b.score, g, meterOk, rules) === 'Calm Buy Zone') {
            const p = sc.plan(sub, price, rules);
            pos = { symbol: s.symbol, entry_i: i, entry: price, stop: p.stop, date: bars[i].date, peak: price };
          }
        }
      } else {
        const lo = bars[i].low, cl = price;
        pos.peak = Math.max(pos.peak, cl);
        const cs = [];
        for (let j = 0; j <= i; j++) cs.push(bars[j].close);
        let exitPx = null, reason = null;
        if (lo <= pos.stop) { exitPx = pos.stop; reason = 'Stop-loss'; }
        else {
          if (ind.pctChange(pos.peak, pos.entry) >= rk.trail_after_pct) {
            const e20 = ind.ema(cs, 20);
            if (e20 && cl < e20) { exitPx = cl; reason = 'Trail 20 EMA'; }
          }
          const m50 = ind.sma(cs, 50);
          if (exitPx === null && m50 && cl < m50) { exitPx = cl; reason = 'Below 50-day avg'; }
          if (exitPx === null && i - pos.entry_i >= rk.time_stop_sessions && cl <= pos.entry * 1.02) { exitPx = cl; reason = 'Time stop'; }
        }
        if (exitPx !== null) {
          const risk = pos.entry - pos.stop;
          trades.push({ symbol: pos.symbol, date: pos.date, exit_date: bars[i].date, entry: rnd(pos.entry, 2), exit: rnd(exitPx, 2), reason,
            pnl_pct: rnd(ind.pctChange(exitPx, pos.entry), 2), r: risk > 0 ? rnd((exitPx - pos.entry) / risk, 2) : 0 });
          pos = null;
        }
      }
    }
  }
  const n = trades.length;
  const wins = trades.filter(t => t.pnl_pct > 0);
  const sumOf = (a, k) => a.reduce((x, t) => x + t[k], 0);
  return {
    trades: n,
    hit_rate_pct: n ? rnd((100 * wins.length) / n, 1) : null,
    avg_gain_pct: wins.length ? rnd(sumOf(wins, 'pnl_pct') / wins.length, 2) : null,
    avg_loss_pct: n ? rnd(sumOf(trades.filter(t => t.pnl_pct <= 0), 'pnl_pct') / Math.max(1, n - wins.length), 2) : null,
    avg_r: n ? rnd(sumOf(trades, 'r') / n, 2) : null,
    recent: trades.slice(-10),
  };
}

export function compare(universe, liveRules, draftRules, opts) {
  return { live: run(universe, liveRules, opts), draft: run(universe, draftRules, opts) };
}
