// Engine worker: scoring runs here, off the screen's thread.
import { createCore } from './core.js';

const core = createCore(ev => self.postMessage({ event: ev }));
self.onmessage = async e => {
  const { id, msg } = e.data;
  try { self.postMessage({ id, ok: true, data: await core.handle(msg) }); }
  catch (err) { self.postMessage({ id, ok: false, error: String((err && err.message) || err) }); }
};
