// Versioned rules, kept on the phone: every version, a draft, and a change log.
import { kv } from '../data/idb.js';
import { RULES_V1 } from './rules-v1.js';

// Allowed ranges for every editable number (path -> [min, max]).
export const LIMITS = {
  'gates.main.min_price': [20, 500], 'gates.main.min_turnover_cr': [1, 100], 'gates.main.max_pledge_pct': [0, 50],
  'market.panic_below': [10, 50], 'market.euphoria_above': [60, 95],
  'breath.calm_from': [50, 95], 'breath.wait_from': [40, 80], 'breath.no_chase_pct': [1, 15],
  'dna.tests_to_pass': [3, 6], 'dna.growth_pct': [10, 40], 'dna.roce_pct': [10, 30],
  'fuse.lit_from': [40, 90], 'fuse.ignite_volume_ratio': [1, 3],
  'penny.real_from': [40, 90], 'penny.pump_buzz_from': [50, 95], 'penny.risk_pct': [0.1, 1],
  'risk.risk_pct': [0.25, 3], 'risk.max_positions': [2, 15], 'risk.time_stop_sessions': [5, 40],
  'risk.capital': [10000, 100000000],
};

const clone = o => JSON.parse(JSON.stringify(o));
export const getPath = (d, p) => p.split('.').reduce((a, k) => a[k], d);
function setPath(d, p, v) { const ks = p.split('.'); let o = d; for (const k of ks.slice(0, -1)) o = o[k]; o[ks[ks.length - 1]] = v; }
const vkey = v => v.split('.').map(Number);
const cmp = (a, b) => { const x = vkey(a), y = vkey(b); return x[0] - y[0] || x[1] - y[1]; };

export class RuleStore {
  constructor() { this.versionsMap = {}; this.liveV = '1.0'; this.log = []; this.draft = null; this.draftBacktest = null; }

  async load() {
    this.versionsMap = (await kv.get('rules.versions')) || {};
    if (!this.versionsMap['1.0']) this.versionsMap['1.0'] = clone(RULES_V1);
    this.liveV = (await kv.get('rules.live')) || '1.0';
    if (!this.versionsMap[this.liveV]) this.liveV = '1.0';
    this.log = (await kv.get('rules.log')) || [];
    return this;
  }

  versions() { return Object.keys(this.versionsMap).sort(cmp); }
  liveVersion() { return this.liveV; }
  live() { return this.versionsMap[this.liveV]; }

  setValues(changes) {
    const draft = clone(this.draft || this.live());
    for (const [path, raw] of Object.entries(changes)) {
      if (!(path in LIMITS)) throw new Error(`${path} is not an editable rule`);
      const [lo, hi] = LIMITS[path];
      const value = parseFloat(raw);
      if (!(value >= lo && value <= hi)) throw new Error(`${path} must be between ${lo} and ${hi}`);
      setPath(draft, path, value);
    }
    this.draft = draft;
    this.draftBacktest = null;
    return this.diff();
  }

  diff() {
    if (!this.draft) return {};
    const live = this.live();
    const out = {};
    for (const p of Object.keys(LIMITS)) if (getPath(live, p) !== getPath(this.draft, p)) out[p] = { old: getPath(live, p), new: getPath(this.draft, p) };
    return out;
  }

  reset() { this.draft = null; this.draftBacktest = null; }

  async publish(reason = '') {
    if (!this.draft || !Object.keys(this.diff()).length) throw new Error('No changes to publish');
    if (!this.draftBacktest) throw new Error('Backtest the changes before publishing');
    const [major, minor] = vkey(this.versions().slice(-1)[0]);
    const v = `${major}.${minor + 1}`;
    const changes = this.diff();
    const date = new Date().toISOString().slice(0, 10);
    this.versionsMap[v] = { ...this.draft, version: v, date, note: reason };
    this.liveV = v;
    this.log.unshift({ date, version: v, changes, reason, backtest: this.draftBacktest });
    this.draft = null; this.draftBacktest = null;
    await this.save();
    return v;
  }

  async restore(v) {
    if (!this.versionsMap[v]) throw new Error(`Unknown version ${v}`);
    this.liveV = v;
    await this.save();
  }

  async save() {
    await kv.set('rules.versions', this.versionsMap);
    await kv.set('rules.live', this.liveV);
    await kv.set('rules.log', this.log.slice(0, 50));
  }
}
