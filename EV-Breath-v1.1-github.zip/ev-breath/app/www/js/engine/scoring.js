// EV Breath rule engine. Every number comes from the active rules.
//
// A stock is an object:
//   symbol, name, sector, fno, bars (oldest first), delivery (aligned with bars), oi (aligned, F&O only),
//   mcap_cr, pledge_pct, promoter_pct, promoter_change_4q, asm, fo_ban, circuit_recent, results_in_days,
//   bulk_buy_5d, fundamentals {sales_cagr3, profit_cagr3, sales_yoy_q, roce, roce3y, de, icr, pe, sector_pe,
//   ttm_sales_cr}, buzz {news_ratio, social_ratio}, filings [{time, kind, subject, material, age_days}]
import * as ind from './indicators.js';

const rnd = ind.rnd;
export const closes = s => s.bars.map(b => b.close);
export const lastClose = s => s.bars[s.bars.length - 1].close;
const last = a => a[a.length - 1];
const g0 = (v, d) => (v === undefined || v === null ? d : v);
const clamp = (x, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, x));
const sum = a => a.reduce((x, y) => x + y, 0);

export function turnoverCr(s, n = 20) {
  const seg = s.bars.slice(-n);
  return seg.length ? sum(seg.map(b => b.close * b.volume)) / seg.length / 1e7 : 0;
}

// ---------------------------------------------------------------- gates
export function checkGates(s, rules, kind = 'main') {
  const g = rules.gates[kind];
  const price = lastClose(s);
  const fails = [];
  if (kind === 'penny') { if (price > g.max_price) fails.push(`Price above ₹${g.max_price}`); }
  else if (price < g.min_price) fails.push(`Price below ₹${g.min_price}`);
  if (turnoverCr(s) < g.min_turnover_cr) fails.push(`Turnover below ₹${g.min_turnover_cr} cr`);
  if (g0(s.pledge_pct, 0) > g.max_pledge_pct) fails.push(`Pledge above ${g.max_pledge_pct}%`);
  const surveillance = !!s.asm || !!s.fo_ban;
  if (surveillance && kind !== 'penny') fails.push('On ASM/GSM list or F&O ban');
  if (s.circuit_recent && kind !== 'penny') fails.push('Hit a circuit in the last 3 days');
  const rid = s.results_in_days;
  const entry_blocked = rid !== null && rid !== undefined && rid >= 0 && rid <= rules.gates.results_blackout_days;
  return { pass: !fails.length, fails, entry_blocked, surveillance };
}

// ---------------------------------------------------------------- market filter
export function breathMeter(universe, indexBars, vix, rules) {
  let above = 0, adv = 0, dec = 0, counted = 0;
  for (const s of universe) {
    const cs = closes(s);
    const m50 = ind.sma(cs, 50);
    if (m50 === null || cs.length < 2) continue;
    counted++;
    if (last(cs) > m50) above++;
    if (last(cs) > cs[cs.length - 2]) adv++;
    else if (last(cs) < cs[cs.length - 2]) dec++;
  }
  const pctAbove = counted ? (100 * above) / counted : 50;
  const adRatio = dec ? adv / dec : (adv || 1);
  const ic = indexBars.map(b => b.close);
  const i50 = ind.sma(ic, 50) || last(ic);
  const gap = ind.pctChange(last(ic), i50);
  const sAd = clamp(((adRatio - 0.5) / 1.5) * 100);
  const sTrend = clamp(((gap + 5) / 10) * 100);
  const sVix = clamp(((25 - vix) / 15) * 100);
  const score = rnd(0.4 * pctAbove + 0.25 * sAd + 0.2 * sTrend + 0.15 * sVix);
  const m = rules.market;
  const panic = score < m.panic_below || (gap < 0 && adRatio < 0.8);
  const euphoria = score > m.euphoria_above;
  const zone = panic ? 'Panic' : euphoria ? 'Euphoria' : 'Calm';
  return { score, zone, pct_above_50dma: rnd(pctAbove, 1), adv, dec, ad_ratio: rnd(adRatio, 2),
    nifty_vs_50dma_pct: rnd(gap, 2), vix };
}

// ---------------------------------------------------------------- breath score
function entrySetup(s, r) {
  const bars = s.bars;
  const cs = closes(s);
  const n0 = cs.length;
  const price = cs[n0 - 1];
  const e20 = ind.ema(cs, 20);
  const avg20 = ind.avgVolume(bars, 20, 1);
  let out = { points: 0, type: null, entry: null, note: 'No setup' };
  if (e20 === null || avg20 === null || bars.length < 60) return out;
  // Pullback: a 5%+ rise in the last 20 sessions, price resting just above the 20 EMA,
  // quiet volume on the dip, then a turn-up day on rising volume.
  const rise = ind.pctChange(Math.max(...cs.slice(-20)), cs[n0 - 21]);
  const inBand = e20 <= price && price <= e20 * (1 + r.pullback_band_pct / 100);
  const dipVol = (bars[n0 - 4].volume + bars[n0 - 3].volume + bars[n0 - 2].volume) / 3;
  const turn = cs[n0 - 1] > cs[n0 - 2] && bars[n0 - 1].volume > bars[n0 - 2].volume;
  if (rise >= r.pullback_rise_pct && inBand && dipVol < r.dip_volume_ratio * avg20 && turn) {
    return { points: 20, type: 'Pullback', entry: rnd(e20, 2), note: 'Pullback to 20 EMA, turning up' };
  }
  // Base breakout: a base of 15+ sessions inside a 12% range, closed above on volume.
  let best = null;
  let hi = -Infinity, lo = Infinity;
  for (let n = 1; n <= 60; n++) {
    const i = n0 - 1 - n;            // bars[-n-1 : -1] grows one bar at a time from the right
    if (i < 0) break;
    hi = Math.max(hi, bars[i].high);
    lo = Math.min(lo, bars[i].low);
    if (n < r.base_min_sessions) continue;
    if (((hi - lo) / lo) * 100 <= r.base_range_pct) best = [n, hi];
  }
  if (best) {
    const [n, bh] = best;
    if (price > bh && bars[n0 - 1].volume >= r.breakout_volume_ratio * avg20) {
      return { points: 20, type: 'Breakout', entry: rnd(bh, 2), note: `${n}-session base breakout` };
    }
    out = { points: 0, type: 'Base', entry: rnd(bh, 2), note: `Base forming · ${n} sessions` };
  }
  // No chasing: far above the entry point scores nothing.
  if (price > e20 * (1 + r.no_chase_pct / 100) && out.type === null) {
    out.note = `${ind.pctChange(price, e20).toFixed(1)}% above 20 EMA · wait for pullback`;
    out.entry = rnd(e20, 2);
  }
  return out;
}

// LB long buildup, SB short buildup, SC short covering, LU long unwinding.
export function oiSignal(s, n = 1, cut = 0) {
  const oi = s.oi || [];
  const L = oi.length - cut, B = s.bars.length - cut;
  if (L < n + 1 || B < n + 1) return null;
  const dp = s.bars[B - 1].close - s.bars[B - 1 - n].close;
  const doi = oi[L - 1] - oi[L - 1 - n];
  if (dp >= 0 && doi > 0) return 'LB';
  if (dp < 0 && doi > 0) return 'SB';
  if (dp >= 0 && doi <= 0) return 'SC';
  return 'LU';
}

export function breathScore(s, ctx, rules) {
  const r = rules.breath;
  const bars = s.bars;
  const cs = closes(s);
  const n0 = cs.length;
  const price = cs[n0 - 1];
  const parts = {};
  // Trend (25)
  const m50s = ind.smaSeries(cs, 50);
  const m200s = ind.smaSeries(cs, 200);
  const m50 = m50s[n0 - 1], m200 = m200s[n0 - 1];
  let t = 0;
  t += m50 && price > m50 ? 5 : 0;
  t += m50 && m200 && m50 > m200 ? 5 : 0;
  t += m200 && m200s.length > 20 && m200s[n0 - 21] && m200 > m200s[n0 - 21] ? 5 : 0;
  const hi52 = ind.highOf(bars, Math.min(250, bars.length));
  t += price >= hi52 * (1 - r.near_52wh_pct / 100) ? 5 : 0;
  const lows = ind.swingLows(bars.slice(-120));
  t += lows.length >= 2 && lows[lows.length - 1][1] > lows[lows.length - 2][1] ? 5 : 0;
  parts.trend = t;
  // Relative strength (20)
  const rsPop = Object.values(ctx.rs_returns || {});
  const my = ind.ret(cs, 63) || 0;
  const pctl = ind.percentileOf(my, rsPop);
  let rs = pctl >= 90 ? 15 : pctl >= 80 ? 10 : pctl >= 70 ? 5 : 0;
  rs += (ctx.sector_above_50 || {})[s.sector] ? 5 : 0;
  parts.rs = rs;
  // Participation (20)
  const deliv = s.delivery || [];
  let p = 0;
  if (deliv.length >= 20) {
    const avgD = sum(deliv.slice(-20)) / 20;
    const upD = [];
    for (let i = bars.length - 10; i < bars.length; i++) if (bars[i].close > bars[i - 1].close) upD.push(deliv[i]);
    if (upD.length && avgD && sum(upD) / upD.length >= r.delivery_ratio * avgD) p += 8;
  }
  let upv = 0, dnv = 0;
  for (let i = bars.length - 10; i < bars.length; i++) {
    if (bars[i].close > bars[i - 1].close) upv += bars[i].volume;
    else if (bars[i].close < bars[i - 1].close) dnv += bars[i].volume;
  }
  p += upv > dnv ? 6 : 0;
  const avg20 = ind.avgVolume(bars, 20, 1) || 1;
  p += bars[n0 - 1].volume >= r.turn_volume_ratio * avg20 && price > cs[n0 - 2] ? 6 : 0;
  parts.participation = p;
  // OI confirmation (15, F&O only)
  if (s.fno && (s.oi || []).length >= 6) {
    const sig = [0, 1, 2, 3, 4].map(k => oiSignal(s, 1, k));
    let o = sig.filter(x => x === 'LB').length >= 3 ? 10 : 0;
    o += sig.slice(0, 2).includes('SB') ? 0 : 5;
    parts.oi = o;
  } else parts.oi = null;
  // Entry setup (20)
  const setup = entrySetup(s, r);
  parts.entry = setup.points;
  const raw = sum(Object.values(parts).filter(v => v !== null));
  const score = parts.oi !== null ? raw : rnd((raw * 100) / 85);
  return { score: rnd(score), parts, setup, oi_signal: oiSignal(s) };
}

export function breathVerdict(score, gates, meter, rules) {
  const r = rules.breath;
  if (!gates.pass) return 'Avoid';
  if (score >= r.calm_from) {
    if (meter.zone === 'Panic' || gates.entry_blocked) return 'Wait for the Breath';
    return 'Calm Buy Zone';
  }
  if (score >= r.wait_from) return 'Wait for the Breath';
  return 'Not yet';
}

// ---------------------------------------------------------------- multibagger DNA
export function dna(s, rules) {
  const d = rules.dna;
  const f = s.fundamentals || {};
  const cs = closes(s);
  const n0 = cs.length;
  const m200s = ind.smaSeries(cs, 200);
  const m200 = m200s[n0 - 1];
  const yoy = f.sales_yoy_q || [];
  const tests = {
    G: g0(f.sales_cagr3, 0) >= d.growth_pct && g0(f.profit_cagr3, 0) >= d.growth_pct && yoy.length >= 2 && yoy[0] > 0 && yoy[1] > 0,
    R: g0(f.roce, 0) >= d.roce_pct && g0(f.roce3y, 0) >= d.roce_3y_pct,
    D: g0(f.de, 9) <= d.max_debt_equity && g0(f.icr, 0) >= d.min_interest_cover,
    P: g0(s.promoter_pct, 0) >= d.min_promoter_pct && g0(s.promoter_change_4q, 0) >= -d.max_promoter_cut_pct,
    S: d.mcap_min_cr <= g0(s.mcap_cr, 0) && g0(s.mcap_cr, 0) <= d.mcap_max_cr,
    T: !!m200 && cs[n0 - 1] > m200 && m200s.length > 21 && !!m200s[n0 - 21] && m200 > m200s[n0 - 21],
  };
  const passed = Object.values(tests).filter(Boolean).length;
  let stage = null;
  if (passed >= d.tests_to_pass) {
    const hi52 = ind.highOf(s.bars, Math.min(250, s.bars.length));
    const w = d.early_window_days;
    let crossed = false;
    for (let i = Math.max(0, n0 - w); i < n0 && !crossed; i++) {
      if (i > 0 && m200s[i] && m200s[i - 1] && cs[i] > m200s[i] && cs[i - 1] <= m200s[i - 1]) crossed = true;
    }
    const seg = s.bars.slice(-d.base_min_days);
    const lo = Math.min(...seg.map(b => b.low));
    const rng = ((Math.max(...seg.map(b => b.high)) - lo) / lo) * 100;
    if (cs[n0 - 1] >= hi52 * 0.99) stage = 'Trending';
    else if (crossed) stage = 'Early';
    else if (rng <= d.base_range_pct) stage = 'Base';
    else stage = 'Early';
  }
  let warning = null;
  if (f.pe && f.sector_pe && f.pe > d.pe_warning_factor * f.sector_pe) warning = 'Valuation stretched vs sector';
  return { tests, passed, stage, warning };
}

// ---------------------------------------------------------------- blast fuse
export function fuse(s, rules) {
  const f = rules.fuse;
  const bars = s.bars;
  const cs = closes(s);
  const n0 = cs.length;
  const parts = {};
  const bbw = ind.bbWidthSeries(cs, 20, 2).slice(-120).filter(x => x !== null);
  let squeeze = 0, tight = false;
  if (bbw.length && ind.percentileOf(last(bbw), bbw) <= f.bb_low_pct) { squeeze += 15; tight = true; }
  const atrs = ind.atrSeries(bars, 14).slice(-60).filter(x => x !== null);
  if (atrs.length && last(atrs) <= Math.max(...atrs) * (1 - f.atr_drop_pct / 100)) squeeze += 10;
  if (ind.isNr7(bars) || ind.isInsideDay(bars)) squeeze += 5;
  parts.squeeze = squeeze;
  const v5 = ind.avgVolume(bars, 5) || 0;
  const v50 = ind.avgVolume(bars, 50) || 1;
  parts.volume = v5 >= f.volume_pickup_ratio * v50 && (tight || squeeze >= 10) ? 20 : 0;
  let acc = 0;
  const deliv = s.delivery || [];
  if (deliv.length >= 20 && sum(deliv.slice(-5)) / 5 >= f.delivery_ratio * (sum(deliv.slice(-20)) / 20)) acc += 10;
  const oi = s.oi || [];
  if (oi.length >= 6 && oi[oi.length - 6] && last(oi) / oi[oi.length - 6] - 1 > 0.05 && Math.abs(ind.pctChange(cs[n0 - 1], cs[n0 - 6])) < 2) acc += 10;
  else if (!s.fno && s.bulk_buy_5d) acc += 10;
  parts.accumulation = acc;
  const rngHi = ind.highOf(bars.slice(0, -1), 20);
  const hi52 = ind.highOf(bars, Math.min(250, bars.length));
  let prox = cs[n0 - 1] >= rngHi * (1 - f.near_range_pct / 100) ? 10 : 0;
  prox += cs[n0 - 1] >= hi52 * (1 - f.near_52wh_pct / 100) ? 10 : 0;
  parts.proximity = prox;
  parts.catalyst = (s.filings || []).some(x => x.material && g0(x.age_days, 99) <= 5) ? 10 : 0;
  const score = sum(Object.values(parts));
  const avg20 = ind.avgVolume(bars, 20, 1) || 1;
  const ignited = cs[n0 - 1] > rngHi && bars[n0 - 1].volume >= f.ignite_volume_ratio * avg20;
  const status = ignited ? 'Ignited' : score >= f.lit_from ? 'Fuse lit' : 'Loose';
  const tags = [];
  if (squeeze >= 15) tags.push('SQUEEZE');
  if (v50) tags.push(`VOL ${(v5 / v50).toFixed(1)}×`);
  const sig = oiSignal(s, 3);
  if (sig) tags.push(sig);
  tags.push(`${Math.max(0, ind.pctChange(hi52, cs[n0 - 1])).toFixed(1)}% TO 52WH`);
  return { score, parts, status, range_high: rnd(rngHi, 2), tags };
}

// ---------------------------------------------------------------- substance (shared by penny and main)
export function substance(s) {
  const filings = (s.filings || []).filter(x => g0(x.age_days, 99) <= 5);
  let sub = filings.length ? 25 : 0;
  sub += filings.some(x => x.material) ? 20 : 0;
  sub += last(s.delivery && s.delivery.length ? s.delivery : [0]) >= 30 ? 15 : 0;
  sub += g0(s.pledge_pct, 0) <= 10 ? 10 : 0;
  sub += g0(s.promoter_pct, 0) >= 40 && g0(s.promoter_change_4q, 0) >= 0 ? 10 : 0;
  sub += g0((s.fundamentals || {}).de, 9) <= 1 ? 10 : 0;
  sub += !s.asm ? 10 : 0;
  return { sub, filings };
}

// ---------------------------------------------------------------- penny buzz
export function penny(s, rules) {
  const p = rules.penny;
  const bars = s.bars;
  const cs = closes(s);
  const n0 = cs.length;
  const b = s.buzz || {};
  const avg20 = ind.avgVolume(bars, 20, 1) || 1;
  const volRatio = bars[n0 - 1].volume / avg20;
  const move = Math.abs(ind.pctChange(cs[n0 - 1], cs[n0 - 2]));
  let buzz = clamp((25 * (g0(b.news_ratio, 1) - 1)) / 4, 0, 25)
    + clamp((25 * (g0(b.social_ratio, 1) - 1)) / 4, 0, 25)
    + clamp((25 * (volRatio - 1)) / 4, 0, 25)
    + (s.circuit_recent ? 25 : clamp((25 * move) / 10, 0, 25));
  const { sub, filings } = substance(s);
  const deliv = last(s.delivery && s.delivery.length ? s.delivery : [0]);
  buzz = rnd(buzz);
  let verdict;
  if (s.asm || (buzz >= p.pump_buzz_from && sub < p.pump_substance_below)) verdict = 'Pump risk';
  else if (sub >= p.real_from) verdict = 'Real trigger';
  else verdict = 'Watch';
  const flags = [filings.length ? filings[0].kind.toUpperCase() : 'NO FILING', `DEL ${deliv.toFixed(0)}%`];
  if (g0(s.pledge_pct, 0) > 10) flags.push(`PLEDGE ${s.pledge_pct.toFixed(0)}%`);
  if (s.asm) flags.push('ASM');
  return { buzz, substance: sub, verdict, flags };
}

// ---------------------------------------------------------------- plan (information only: this app never places orders)
export function plan(s, entry, rules, meterZone = 'Calm', kind = 'main') {
  const rk = rules.risk;
  const bars = s.bars;
  const a = ind.atr(bars, 14) || entry * 0.03;
  const lows = ind.swingLows(bars.slice(-60)).map(x => x[1]).filter(lo => lo < entry);
  const stopSwing = lows.length ? last(lows) * 0.995 : entry - 3 * a;
  let stop = Math.max(stopSwing, entry - rk.atr_stop_mult * a); // whichever is nearer
  stop = Math.min(stop, entry - rk.min_stop_atr * a);           // never closer than 1x ATR
  stop = rnd(stop, 2);
  let riskPct = kind === 'penny' ? rules.penny.risk_pct : rk.risk_pct;
  if (meterZone === 'Euphoria') riskPct *= rules.market.euphoria_size_factor;
  const perShare = Math.max(entry - stop, 0.01);
  let qty = Math.floor((rk.capital * riskPct) / 100 / perShare);
  const capQty = Math.floor((rk.capital * rk.max_position_pct) / 100 / entry);
  qty = Math.max(0, Math.min(qty, capQty));
  return { entry: rnd(entry, 2), stop, qty, risk_rupees: rnd(qty * perShare),
    risk_pct_of_capital: rnd(((qty * perShare) / rk.capital) * 100, 2), value: rnd(qty * entry) };
}
