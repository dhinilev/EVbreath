// Starting rulebook values (v1.0). Backtest before changing.
export const RULES_V1 = {
  "version": "1.0",
  "date": "2026-10-07",
  "note": "Starting values from the EV Breath Rulebook. Backtest before changing.",
  "gates": {
    "main": {
      "min_price": 100,
      "min_turnover_cr": 25,
      "max_pledge_pct": 20
    },
    "multibagger": {
      "min_price": 30,
      "min_turnover_cr": 2,
      "max_pledge_pct": 5
    },
    "penny": {
      "max_price": 50,
      "min_turnover_cr": 0.5,
      "max_pledge_pct": 10
    },
    "circuit_lookback_days": 3,
    "results_blackout_days": 5
  },
  "market": {
    "panic_below": 30,
    "euphoria_above": 75,
    "euphoria_size_factor": 0.5
  },
  "breath": {
    "calm_from": 75,
    "wait_from": 60,
    "near_52wh_pct": 15,
    "delivery_ratio": 1.2,
    "turn_volume_ratio": 1.5,
    "pullback_rise_pct": 5,
    "pullback_band_pct": 3,
    "dip_volume_ratio": 0.8,
    "base_min_sessions": 15,
    "base_range_pct": 12,
    "breakout_volume_ratio": 1.5,
    "no_chase_pct": 5
  },
  "dna": {
    "tests_to_pass": 5,
    "growth_pct": 20,
    "roce_pct": 18,
    "roce_3y_pct": 15,
    "max_debt_equity": 0.5,
    "min_interest_cover": 4,
    "min_promoter_pct": 50,
    "max_promoter_cut_pct": 2,
    "mcap_min_cr": 500,
    "mcap_max_cr": 10000,
    "pe_warning_factor": 1.3,
    "early_window_days": 60,
    "base_range_pct": 25,
    "base_min_days": 63
  },
  "fuse": {
    "lit_from": 60,
    "bb_low_pct": 10,
    "atr_drop_pct": 30,
    "volume_pickup_ratio": 1.3,
    "delivery_ratio": 1.3,
    "near_range_pct": 3,
    "near_52wh_pct": 5,
    "ignite_volume_ratio": 1.5,
    "fail_days": 3
  },
  "penny": {
    "real_from": 60,
    "pump_buzz_from": 70,
    "pump_substance_below": 30,
    "risk_pct": 0.5,
    "max_total_pct": 5
  },
  "alerts": {
    "min_substance": 50,
    "buy_substance": 60,
    "order_to_sales_pct": 10,
    "profit_yoy_pct": 25,
    "promoter_buy_pct": 0.25,
    "max_per_stock_per_day": 1
  },
  "risk": {
    "capital": 500000,
    "risk_pct": 1,
    "max_position_pct": 10,
    "max_positions": 8,
    "max_per_sector": 2,
    "atr_stop_mult": 2,
    "min_stop_atr": 1,
    "trail_after_pct": 10,
    "time_stop_sessions": 15
  }
};
