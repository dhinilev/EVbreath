// Buzz Alert pipeline: filing -> type -> material? -> Substance -> gates -> what to show.
// Watch-only app: the outcome is a "watch" signal, never an order.

export const KINDS = [
  ['Order', /\b(order|contract|letter of award|loa|work order|purchase order)\b/],
  ['Results', /\b(financial results|quarterly results|results for the quarter)\b/],
  ['Promoter buy', /\b(acquisition of shares by promoter|promoter.*(acqui|purchase|buy))\b/],
  ['Bulk deal', /\b(bulk deal|block deal)\b/],
  ['Capex', /\b(capex|capacity expansion|new plant|commission(ed|ing))\b/],
  ['Pledge', /\b(pledge|encumbrance)\b/],
  ['Debt', /\b(term loan|borrowing|ncd|debentures|credit facility)\b/],
  ['Rating', /\b(credit rating|rating)\b/],
  ['Results date', /\b(board meeting).*\b(results|financial)\b/],
];
const NEGATIVE = new Set(['Pledge', 'Debt']);

export function classify(subject) {
  const text = (subject || '').toLowerCase();
  for (const [kind, re] of KINDS) if (re.test(text)) return kind;
  return 'Other';
}

export function isMaterial(filing, stock, rules) {
  const a = rules.alerts;
  const kind = filing.kind || classify(filing.subject);
  const ttm = (stock.fundamentals || {}).ttm_sales_cr || 0;
  if (kind === 'Order' && filing.value_cr && ttm) return (filing.value_cr / ttm) * 100 >= a.order_to_sales_pct;
  if (kind === 'Results' && filing.profit_yoy_pct !== undefined && filing.profit_yoy_pct !== null) return filing.profit_yoy_pct >= a.profit_yoy_pct;
  if (kind === 'Promoter buy' && filing.promoter_buy_pct !== undefined && filing.promoter_buy_pct !== null) return filing.promoter_buy_pct >= a.promoter_buy_pct;
  if (kind === 'Bulk deal' || kind === 'Capex') return !!filing.value_cr;
  return false;
}

// signal: "strong" (rules agree, worth a close look), "caution" (passes, but weaker substance), "none".
export function decide(filing, stock, substance, gates, rules, sentToday = null) {
  const a = rules.alerts;
  const kind = filing.kind || classify(filing.subject);
  const material = isMaterial({ ...filing, kind }, stock, rules);
  const base = { symbol: stock.symbol, kind, subject: filing.subject || '', time: filing.time || null, material, substance };
  if (sentToday && sentToday.has(stock.symbol)) return { ...base, push: false, signal: 'none', reason: 'Already alerted today' };
  if (!material) return { ...base, push: false, signal: 'none', reason: 'Logged, no alert (not material)' };
  if (substance < a.min_substance) return { ...base, push: false, signal: 'none', reason: 'Logged, no alert (low substance)' };
  if (!gates.pass || gates.surveillance) return { ...base, push: true, signal: 'none', reason: 'Alert · safety gate failed or on ASM' };
  if (NEGATIVE.has(kind)) return { ...base, push: true, signal: 'none', reason: 'Alert · negative filing' };
  if (substance >= a.buy_substance) return { ...base, push: true, signal: 'strong', reason: 'Alert · strong substance, rules agree' };
  return { ...base, push: true, signal: 'caution', reason: 'Alert · weaker substance, watch with care' };
}

const VALUE_RE = /(?:rs\.?|₹|inr)\s*([\d,]+(?:\.\d+)?)\s*(crore|cr|lakh|lac|million|mn)?/i;
export function parseValueCr(text) {
  const m = VALUE_RE.exec(text || '');
  if (!m) return null;
  const v = parseFloat(m[1].replace(/,/g, ''));
  const unit = (m[2] || 'cr').toLowerCase();
  return unit === 'lakh' || unit === 'lac' ? v / 100 : unit === 'million' || unit === 'mn' ? v / 10 : v;
}
