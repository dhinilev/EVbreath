// Engine: holds the market data, applies the live rules and builds every screen's data.
import * as al from './alerts.js';
import * as ind from './indicators.js';
import * as sc from './scoring.js';

const rnd = ind.rnd;
const g0 = (v, d) => (v === undefined || v === null ? d : v);

export class Engine {
  // source: { universe(), index('NIFTY'|'SENSEX'), vix(), flows(), name, mode }
  constructor(ruleStore, source) {
    this.rulesStore = ruleStore;
    this.source = source;
    this.cache = null;
    this.computedAt = 0;
  }

  rules() { return this.rulesStore.live(); }

  recompute(rules) {
    rules = rules || this.rules();
    const pennyMax = rules.gates.penny.max_price;
    const U = this.source.universe().filter(s => s.bars.length >= 60);
    const nifty = this.source.index('NIFTY');
    const meter = sc.breathMeter(U.filter(s => sc.lastClose(s) > pennyMax), nifty, this.source.vix(), rules);
    const rsReturns = {};
    for (const s of U) if (sc.lastClose(s) > pennyMax) rsReturns[s.symbol] = ind.ret(sc.closes(s), 63) || 0;
    const sectors = {};
    for (const s of U) {
      const cs = sc.closes(s);
      const m50 = ind.sma(cs, 50);
      if (m50) (sectors[s.sector] = sectors[s.sector] || []).push(cs[cs.length - 1] > m50);
    }
    const above = {};
    for (const [k, v] of Object.entries(sectors)) above[k] = v.filter(Boolean).length / v.length > 0.5;
    const ctx = { rs_returns: rsReturns, sector_above_50: above };
    const rows = new Map();
    for (const s of U) {
      try { rows.set(s.symbol, this.row(s, ctx, meter, rules)); } catch (e) { /* skip a stock with broken data */ }
    }
    const alerts = [];
    for (const s of U) {
      const r = rows.get(s.symbol);
      if (!r) continue;
      const sub = r.penny ? r.penny.substance : sc.substance(s).sub;
      for (const f of s.filings || []) {
        if (g0(f.age_days, 0) === 0) {
          const mb = r.dna.passed >= rules.dna.tests_to_pass && !r.is_penny;
          const a = al.decide(f, s, sub, mb ? r.gates_mb : r.gates, rules);
          Object.assign(a, { price: r.price, chg_pct: r.chg_pct, is_penny: r.is_penny, id: f.id || `${s.symbol}|${f.subject}` });
          alerts.push(a);
        }
      }
    }
    alerts.sort((a, b) => ((b.time || '') > (a.time || '') ? 1 : (b.time || '') < (a.time || '') ? -1 : 0));
    this.cache = { rows, meter, alerts, rules_version: rules.version, universe_size: U.length };
    this.computedAt = Date.now();
    return this.cache;
  }

  row(s, ctx, meter, rules) {
    const price = sc.lastClose(s);
    const isPenny = price <= rules.gates.penny.max_price;
    const gMain = sc.checkGates(s, rules, isPenny ? 'penny' : 'main');
    const gMb = sc.checkGates(s, rules, 'multibagger');
    const b = sc.breathScore(s, ctx, rules);
    const verdict = sc.breathVerdict(b.score, gMain, meter, rules);
    const d = sc.dna(s, rules);
    const fz = sc.fuse(s, rules);
    const pn = isPenny ? sc.penny(s, rules) : null;
    const entry = b.setup.entry || price;
    const pl = sc.plan(s, ['Pullback', 'Breakout'].includes(b.setup.type) ? price : entry, rules, meter.zone, isPenny ? 'penny' : 'main');
    const cs = sc.closes(s);
    const dl = s.delivery || [];
    const avgD = dl.length ? dl.slice(-20).reduce((x, y) => x + y, 0) / 20 : 0;
    const lastBar = s.bars[s.bars.length - 1];
    return {
      symbol: s.symbol, name: s.name, sector: s.sector, fno: !!s.fno,
      price: rnd(price, 2), chg_pct: rnd(ind.pctChange(cs[cs.length - 1], cs[cs.length - 2]), 2),
      mcap_cr: s.mcap_cr || 0, is_penny: isPenny,
      gates: gMain, gates_mb: gMb, breath: b, verdict, dna: d, fuse: fz, penny: pn, plan: pl,
      delivery_x: avgD ? rnd(dl[dl.length - 1] / avgD, 2) : null,
      pledge_pct: g0(s.pledge_pct, 0), results_in_days: g0(s.results_in_days, null),
      asm: !!s.asm, filings: s.filings || [], fundamentals: s.fundamentals || {}, promoter_pct: g0(s.promoter_pct, null),
      has_fundamentals: !!(s.fundamentals && Object.keys(s.fundamentals).length > 1),
      bar_date: lastBar.date, provisional: !!lastBar.live,
      spark: cs.slice(-60).map(x => rnd(x, 2)),
    };
  }

  data(maxAgeMs = 300000) {
    if (!this.cache || Date.now() - this.computedAt > maxAgeMs) return this.recompute();
    return this.cache;
  }

  // ------------------------------------------------------------ screens
  home() {
    const d = this.data();
    const rows = [...d.rows.values()];
    const tick = name => {
      const b = this.source.index(name);
      if (!b || b.length < 2) return { last: null, chg_pct: null };
      return { last: rnd(b[b.length - 1].close, 2), chg_pct: rnd(ind.pctChange(b[b.length - 1].close, b[b.length - 2].close), 2) };
    };
    const blast = rows.filter(r => r.fuse.status === 'Fuse lit' && r.gates.pass && !r.is_penny).sort((a, b) => b.fuse.score - a.fuse.score);
    const mb = rows.filter(r => r.dna.stage && r.gates_mb.pass);
    return { nifty: tick('NIFTY'), sensex: tick('SENSEX'), meter: d.meter, flows: this.source.flows(),
      blast_count: blast.length, blast: blast.slice(0, 3).map(brief), multibagger: mb.slice(0, 3).map(brief),
      alerts: d.alerts.slice(0, 3), rules_version: d.rules_version, universe_size: d.universe_size,
      source: this.source.name, mode: this.source.mode };
  }

  scanner(preset = 'breath', q = '', fnoOnly = false) {
    const d = this.data();
    let rows = [...d.rows.values()].filter(r => !r.is_penny);
    if (q) {
      const ql = q.toLowerCase();
      rows = rows.filter(r => r.symbol.toLowerCase().includes(ql) || (r.sector || '').toLowerCase().includes(ql) || (r.name || '').toLowerCase().includes(ql));
    }
    if (fnoOnly) rows = rows.filter(r => r.fno);
    const st = r => r.breath.setup.type;
    if (preset === 'breakout') rows = rows.filter(r => ['Breakout', 'Base'].includes(st(r)));
    else if (preset === 'pullback') rows = rows.filter(r => st(r) === 'Pullback');
    else if (preset === 'oi') rows = rows.filter(r => r.breath.parts.oi && r.breath.parts.oi >= 10);
    else if (preset === 'del') rows = rows.filter(r => (r.delivery_x || 0) >= 1.5);
    rows.sort((a, b) => b.breath.score - a.breath.score);
    const all = [...d.rows.values()];
    return {
      rows: rows.slice(0, 300).map(r => ({ symbol: r.symbol, price: r.price, chg_pct: r.chg_pct, delivery_x: r.delivery_x,
        oi: r.breath.oi_signal, score: r.breath.score, verdict: r.verdict, setup: r.breath.setup.note })),
      total: rows.length, scanned: d.rows.size, passed: all.filter(r => r.gates.pass && !r.is_penny).length,
      calm: all.filter(r => r.verdict === 'Calm Buy Zone').length,
    };
  }

  multibagger(stage = 'Early') {
    const d = this.data();
    const rules = this.rules();
    const ok = r => r.dna.passed >= rules.dna.tests_to_pass && r.gates_mb.pass;
    const rows = [...d.rows.values()].filter(r => ok(r) && (!stage || r.dna.stage === stage));
    rows.sort((a, b) => (b.dna.passed - a.dna.passed) || (g0(b.fundamentals.sales_cagr3, 0) - g0(a.fundamentals.sales_cagr3, 0)));
    const counts = {};
    for (const s of ['Early', 'Base', 'Trending']) counts[s] = [...d.rows.values()].filter(r => r.dna.stage === s && ok(r)).length;
    return {
      rows: rows.map(r => ({ symbol: r.symbol, name: r.name, price: r.price, mcap_cr: r.mcap_cr, sales_cagr3: g0(r.fundamentals.sales_cagr3, null),
        roce: g0(r.fundamentals.roce, null), pe: g0(r.fundamentals.pe, null), tests: r.dna.tests, passed: r.dna.passed, stage: r.dna.stage, warning: r.dna.warning })),
      counts, with_fundamentals: [...d.rows.values()].filter(r => r.has_fundamentals).length,
    };
  }

  blast(tab = 'lit') {
    const d = this.data();
    const rows = [...d.rows.values()].filter(r => r.gates.pass && !r.is_penny);
    const lit = rows.filter(r => r.fuse.status === 'Fuse lit').sort((a, b) => b.fuse.score - a.fuse.score);
    const ign = rows.filter(r => r.fuse.status === 'Ignited').sort((a, b) => b.fuse.score - a.fuse.score);
    const pick = tab === 'ignited' ? ign : lit;
    return { rows: pick.map(r => ({ symbol: r.symbol, price: r.price, chg_pct: r.chg_pct, fuse: r.fuse.score, tags: r.fuse.tags, status: r.fuse.status })),
      counts: { lit: lit.length, ignited: ign.length } };
  }

  news(tab = 'mb') {
    const d = this.data();
    const rules = this.rules();
    const items = [];
    for (const r of d.rows.values()) {
      const inTab = {
        mb: r.dna.passed >= rules.dna.tests_to_pass && !r.is_penny,
        bl: ['Fuse lit', 'Ignited'].includes(r.fuse.status) && !r.is_penny,
        pn: r.is_penny,
        all: true,
      }[tab];
      if (!inTab) continue;
      for (const f of r.filings) {
        const a = d.alerts.find(x => x.symbol === r.symbol && x.subject === f.subject);
        items.push({ time: f.time || null, date: f.date || null, symbol: r.symbol, kind: f.kind, head: f.subject, price: r.price, chg_pct: r.chg_pct,
          signal: a ? a.signal : 'none', why: a ? a.reason : '', url: f.url || null, source: f.source || null });
      }
    }
    const key = x => (x.date || '') + (x.time || '');
    items.sort((a, b) => (key(b) > key(a) ? 1 : key(b) < key(a) ? -1 : 0));
    return { items: items.slice(0, 200) };
  }

  pennyBoard(hideAsm = true, band = '') {
    const d = this.data();
    let rows = [...d.rows.values()].filter(r => r.is_penny);
    if (hideAsm) rows = rows.filter(r => !r.asm);
    if (band === 'u20') rows = rows.filter(r => r.price < 20);
    else if (band === '20-50') rows = rows.filter(r => r.price >= 20);
    rows.sort((a, b) => b.penny.buzz - a.penny.buzz);
    return { rows: rows.slice(0, 200).map(r => ({ symbol: r.symbol, price: r.price, chg_pct: r.chg_pct, ...r.penny })) };
  }

  check(symbol) {
    const d = this.data();
    const r = d.rows.get(String(symbol).toUpperCase().trim());
    return r ? { ...r, meter_zone: d.meter.zone } : null;
  }

  alert(symbol) {
    const d = this.data();
    const sym = String(symbol).toUpperCase();
    const r = d.rows.get(sym);
    if (!r) return null;
    return { alert: d.alerts.find(x => x.symbol === sym) || null, row: r };
  }

  watchlist(symbols) {
    const d = this.data();
    return { rows: symbols.map(sym => {
      const r = d.rows.get(sym);
      if (!r) return { symbol: sym, missing: true };
      return { symbol: sym, name: r.name, price: r.price, chg_pct: r.chg_pct, score: r.breath.score, verdict: r.verdict,
        fuse: r.fuse.score, fuse_status: r.fuse.status, dna: r.dna.passed, is_penny: r.is_penny, penny: r.penny,
        alert: d.alerts.find(a => a.symbol === sym && a.push) || null, setup: r.breath.setup.note, spark: r.spark.slice(-30) };
    }) };
  }

  search(q) {
    const d = this.data();
    const ql = String(q || '').toUpperCase().trim();
    if (!ql) return { rows: [] };
    const out = [];
    for (const r of d.rows.values()) {
      if (r.symbol.startsWith(ql) || (r.name || '').toUpperCase().includes(ql)) out.push({ symbol: r.symbol, name: r.name, price: r.price });
      if (out.length >= 12) break;
    }
    return { rows: out };
  }
}

function brief(r) {
  const f = r.fundamentals || {};
  return { symbol: r.symbol, name: r.name, price: r.price, chg_pct: r.chg_pct, fuse: r.fuse.score, stage: r.dna.stage, verdict: r.verdict,
    why: `Sales 3Y +${g0(f.sales_cagr3, 0).toFixed(0)}% · ROCE ${g0(f.roce, 0).toFixed(0)}%` };
}
