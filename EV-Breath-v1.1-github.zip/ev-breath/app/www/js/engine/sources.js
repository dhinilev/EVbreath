// Market data sources for the engine.
//   DemoSource: the built-in sample market (fictional companies).
//   LiveSource: NSE daily files kept on the phone + today's live prices.

export function unpackBars(p) {
  const out = new Array(p.date.length);
  for (let i = 0; i < p.date.length; i++) out[i] = { date: p.date[i], open: p.o[i], high: p.h[i], low: p.l[i], close: p.c[i], volume: p.v[i] };
  return out;
}

export class DemoSource {
  constructor(market) {
    this.name = 'Demo market (sample data)';
    this.mode = 'demo';
    this.m = market;
    this.u = market.universe.map(s => ({ ...JSON.parse(JSON.stringify({ ...s, bars: undefined })), bars: unpackBars(s.bars) }));
    this.idx = { NIFTY: unpackBars(market.NIFTY), SENSEX: unpackBars(market.SENSEX) };
  }
  universe() { return this.u; }
  index(name) { return this.idx[name] || this.idx.NIFTY; }
  vix() { return this.m.VIX; }
  flows() { return { ...this.m.FLOWS }; }
  applyTick(symbol, ltp) {
    const s = this.u.find(x => x.symbol === symbol);
    if (!s) return false;
    const b = s.bars[s.bars.length - 1];
    b.close = ltp; b.high = Math.max(b.high, ltp); b.low = Math.min(b.low, ltp);
    return true;
  }
}

// Live: one record per symbol in IndexedDB "bars":
//   {symbol, date[], o[], h[], l[], c[], v[], dl[] (delivery %), oi[] (F&O futures OI, 0 when none)}
// plus kv: "meta.companies" {SYM: {name, sector, mcap_cr, ...}}, "fund" {SYM: {...}}, "index.NIFTY", "index.SENSEX",
// "vix", "flows", "asm" [..], "ban" [..], "filings" {SYM: [...]}, "live.today" {date, quotes: {SYM: {...}}}
export class LiveSource {
  constructor() { this.name = 'Live · NSE / BSE'; this.mode = 'live'; this.u = []; this.idx = {}; this.v = null; this.f = {}; this.bySym = new Map(); }

  async load(idb, kv) {
    const [recs, companies, fund, nifty, sensex, vix, flows, asm, ban, filings, today, watch] = await Promise.all([
      idb.all('bars'), kv.get('meta.companies', {}), kv.get('fund', {}), kv.get('index.NIFTY', []), kv.get('index.SENSEX', []),
      kv.get('vix', null), kv.get('flows', {}), kv.get('asm', []), kv.get('ban', []), kv.get('filings', {}), kv.get('live.today', null),
      kv.get('watchlist', [])]);
    const asmS = new Set(asm), banS = new Set(ban), watchS = new Set(watch);
    const u = [];
    for (const [sym, p] of recs) {
      if (!p || !p.date || p.date.length < 2) continue;
      // Skip very illiquid stocks (no rule can pass them) unless they are on your watchlist.
      if (!watchS.has(sym) && turnover20(p) < 0.3) continue;
      const bars = unpackBars(p);
      const c = companies[sym] || {}, fd = fund[sym] || {};
      const oi = p.oi && p.oi.some(x => x) ? p.oi.slice() : null;
      const s = {
        symbol: sym, name: fd.name || c.name || sym, sector: fd.sector || c.sector || 'Other', fno: !!oi, bars,
        delivery: (p.dl || []).map(x => (x === null || x === undefined ? 0 : x)), oi,
        mcap_cr: fd.mcap_cr || c.mcap_cr || 0, pledge_pct: fd.pledge_pct || 0, promoter_pct: fd.promoter_pct || 0,
        promoter_change_4q: fd.promoter_change_4q || 0, asm: asmS.has(sym), fo_ban: banS.has(sym),
        circuit_recent: circuitRecent(bars), results_in_days: fd.results_in_days ?? null, bulk_buy_5d: false,
        fundamentals: fd.fundamentals || {}, buzz: { news_ratio: 1, social_ratio: 1 }, filings: (filings[sym] || []).map(withAge),
      };
      // News buzz: today's filings count vs normal.
      const nToday = s.filings.filter(x => x.age_days === 0).length;
      if (nToday) s.buzz.news_ratio = 1 + nToday * 1.5;
      if (s.filings.some(x => x.age_days <= 5 && x.kind === 'Bulk deal')) s.bulk_buy_5d = true;
      u.push(s);
    }
    this.u = u;
    this.bySym = new Map(u.map(s => [s.symbol, s]));
    this.idx = { NIFTY: nifty.map(b => ({ ...b })), SENSEX: sensex.map(b => ({ ...b })) };
    this.v = vix;
    this.f = flows || {};
    if (today) this.applyQuotes(today);
    return this;
  }

  universe() { return this.u; }
  index(name) { return this.idx[name] && this.idx[name].length ? this.idx[name] : this.idx.NIFTY || []; }
  vix() { return this.v ?? 15; }
  flows() { return { ...this.f }; }

  // Today's live quotes become a provisional bar (marked live:true) until the day's NSE file arrives.
  applyQuotes(today) {
    if (!today || !today.date) return;
    for (const [sym, q] of Object.entries(today.quotes || {})) {
      const s = this.bySym.get(sym);
      if (s && q.ltp) upsertBar(s.bars, today.date, q, s.delivery, s.oi);
    }
    for (const name of ['NIFTY', 'SENSEX']) {
      const q = (today.index || {})[name];
      if (q && q.ltp && this.idx[name] && this.idx[name].length) upsertBar(this.idx[name], today.date, q);
    }
    if (today.vix) this.v = today.vix;
  }

  applyTick(symbol, ltp) {
    const s = this.bySym.get(symbol);
    if (!s) return false;
    const b = s.bars[s.bars.length - 1];
    if (!b.live) return false; // only move today's provisional bar
    b.close = ltp; b.high = Math.max(b.high, ltp); b.low = Math.min(b.low, ltp);
    return true;
  }
}

function upsertBar(bars, date, q, delivery, oi) {
  const lastB = bars[bars.length - 1];
  if (lastB.date > date) return;
  const bar = { date, open: q.open || q.ltp, high: Math.max(q.high || q.ltp, q.ltp), low: Math.min(q.low || q.ltp, q.ltp), close: q.ltp, volume: q.volume || 0, live: true };
  if (lastB.date === date) {
    if (!lastB.live) return; // the day's official file is already in
    bars[bars.length - 1] = bar;
  } else {
    bars.push(bar);
    if (delivery) delivery.push(delivery.length ? delivery[delivery.length - 1] : 0);
    if (oi) oi.push(oi[oi.length - 1]);
  }
}

function turnover20(p) {
  const n = p.c.length, k = Math.min(20, n);
  let s = 0;
  for (let i = n - k; i < n; i++) s += p.c[i] * p.v[i];
  return k ? s / k / 1e7 : 0;
}

// A close at the day's high or low after a 4.9%+ move counts as a circuit hit.
function circuitRecent(bars) {
  for (let i = Math.max(1, bars.length - 3); i < bars.length; i++) {
    const b = bars[i], pc = bars[i - 1].close;
    const mv = Math.abs(b.close / pc - 1) * 100;
    if (mv >= 4.9 && (b.close === b.high || b.close === b.low) && b.high !== b.low) return true;
  }
  return false;
}

const IST_MS = 5.5 * 3600 * 1000;
export const istToday = () => new Date(Date.now() + IST_MS).toISOString().slice(0, 10);
function withAge(f) {
  if (!f.date) return { ...f, age_days: f.age_days ?? 0 };
  const days = Math.round((Date.parse(istToday()) - Date.parse(f.date)) / 86400000);
  return { ...f, age_days: Math.max(0, days) };
}
