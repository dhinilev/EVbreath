// Home, Scanner, Multibagger, Blast, News, Penny
import { api, cfg, watch } from './api.js';
import { band, bar, cls, demoRibbon, dnaTiles, esc, icon, inr, livePill, LOGO, sgn, signalBadge, spark, verdictBadge } from './ui.js';
import { state } from './state.js';

export async function home() {
  const d = await api('/api/home');
  const wl = await watch.list();
  const w = wl.length ? await api('/api/watchlist?symbols=' + encodeURIComponent(wl.slice(0, 4).join(','))) : { rows: [] };
  const flows = d.flows || {};
  const today = new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: '2-digit', weekday: 'short' });
  const m = d.meter;
  return {
    tab: 'home',
    html: `${demoRibbon()}
    <div class="band">
      <div class="between">
        <div class="row"><div class="logo">${LOGO}</div><span class="brand">EV <span>Breath</span></span></div>
        <div class="row">${livePill(state.live)}<a class="iconbtn" href="#/watchlist" aria-label="Watchlist">${icon('star')}</a><a class="iconbtn" href="#/settings" aria-label="Settings">${icon('gear')}</a></div>
      </div>
      <div class="grid2">
        <div class="seg" style="background:#3B1D52;border:none"><button class="${state.exch === 'NSE' ? 'on' : ''}" data-exch="NSE">NSE</button><button class="${state.exch === 'BSE' ? 'on' : ''}" data-exch="BSE">BSE</button></div>
        <div class="pill" style="height:46px;border-radius:14px;background:transparent;border:1px solid #8E62AE;color:var(--text);justify-content:center">${esc(today)}</div>
      </div>
      <div class="row wrap">
        <span class="pill">NIFTY <span class="${cls(d.nifty.chg_pct)}"><span data-ltp="NIFTY" data-dp="0">${inr(d.nifty.last, 0)}</span> · ${sgn(d.nifty.chg_pct)}%</span></span>
        <span class="pill">SENSEX <span class="${cls(d.sensex.chg_pct)}"><span data-ltp="SENSEX" data-dp="0">${inr(d.sensex.last, 0)}</span> · ${sgn(d.sensex.chg_pct)}%</span></span>
      </div>
    </div>
    <div class="page">
      <a class="search" href="#/check">${icon('scan', 18)}<span class="grow">Check any stock…</span><span class="tag" style="border-color:var(--gold);color:var(--gold)">Stock Check</span></a>
      <div class="stats">
        <div class="stat"><span class="k">Breath</span><span class="v gold">${m.score}</span><span class="s ${m.zone === 'Calm' ? 'up' : m.zone === 'Panic' ? 'dn' : 'orange'}">${m.zone}</span></div>
        <div class="stat"><span class="k">Adv / Dec</span><span class="v">${m.ad_ratio}</span><span class="s muted">${m.adv} / ${m.dec}</span></div>
        <div class="stat"><span class="k">FII ₹cr</span><span class="v">${inr(flows.fii_cr, 0)}</span><span class="s ${cls(flows.dii_cr)}">DII ${sgn(flows.dii_cr, 0)}</span></div>
      </div>
      <div class="card">
        <div class="between"><h3 class="row"><span class="gold">${icon('star', 20, true)}</span>Watchlist</h3><a href="#/watchlist" class="sb small">${wl.length ? 'All ' + wl.length + ' →' : 'Add →'}</a></div>
        ${w.rows.map(r => r.missing ? `<div class="inner small muted">${esc(r.symbol)} · not in the data yet</div>` : `<a class="inner" href="#/check/${r.symbol}" style="display:grid;grid-template-columns:1fr auto auto;gap:10px;align-items:center;color:var(--text)">
          <span class="col"><span class="sb">${r.symbol}</span><span class="xs muted">${esc(r.verdict)} · Breath ${r.score}</span></span>${spark(r.spark, 64, 22)}<span class="col" style="align-items:flex-end"><span data-ltp="${r.symbol}">₹${inr(r.price)}</span><span class="xs ${cls(r.chg_pct)}">${sgn(r.chg_pct)}%</span></span></a>`).join('') || '<div class="empty">Tap ★ on any stock to watch it. You get an alert when news lands.</div>'}
      </div>
      <div class="card hl">
        <div class="between"><h3 class="row"><span class="orange">${icon('blast', 20)}</span>Blast Watch</h3><a class="badge green" href="#/blast">${d.blast_count} fuse lit</a></div>
        ${d.blast.length ? d.blast.map(r => `<a class="inner" href="#/check/${r.symbol}" style="display:grid;grid-template-columns:1.1fr 1.4fr 44px;gap:10px;align-items:center;color:var(--text)">
          <span class="sb">${r.symbol}</span>${bar(r.fuse, 'orange')}<span class="b orange" style="text-align:right">${r.fuse}%</span></a>`).join('') : '<div class="empty">No fuse lit today</div>'}
      </div>
      <div class="card">
        <div class="between"><h3>Multibagger Radar</h3><a href="#/multibagger" class="sb small">All →</a></div>
        ${d.multibagger.map(r => `<a class="inner between" href="#/check/${r.symbol}" style="color:var(--text)"><span class="col"><span class="sb">${r.symbol}</span><span class="small muted">${esc(r.why)}</span></span><span class="tag" style="border-color:var(--blue);color:var(--blue2)">${r.stage}</span></a>`).join('') || '<div class="empty">Nothing on the radar</div>'}
      </div>
      <div class="card">
        <div class="between"><h3>Buzz Alerts</h3><a href="#/news" class="sb small">News →</a></div>
        ${d.alerts.filter(a => a.push).map(a => `<a class="inner col" href="#/alert/${a.symbol}" style="color:var(--text)"><span class="between"><span class="sb">${a.symbol}</span><span class="small muted">${esc(a.time || '')}</span></span><span class="small dim">${esc(a.subject)}</span></a>`).join('') || '<div class="empty">No alerts yet today</div>'}
      </div>
      <div class="xs muted" style="text-align:center">Rules v${esc(d.rules_version)} · ${cfg.demo ? 'demo data' : 'live NSE / BSE data · ' + d.universe_size + ' stocks scored'} · watch-only, no orders</div>
    </div>`,
    mount(root) {
      root.querySelectorAll('[data-exch]').forEach(b => b.onclick = () => { state.exch = b.dataset.exch; root.querySelectorAll('[data-exch]').forEach(x => x.classList.toggle('on', x === b)); });
    },
  };
}

const PRESETS = [['breath', 'Breath score', 'All 5 rules combined · sorted by score'], ['breakout', 'Breakout', 'Base of 3+ weeks broken on 1.5× volume'],
  ['pullback', 'Pullback', 'Uptrend, price resting near the 20 EMA'], ['oi', 'OI buildup', 'Long buildup 3+ sessions (F&O stocks)'], ['del', 'Delivery spike', 'Delivery above 1.5× its 20-day average']];

export async function scanner() {
  const preset = state.scanPreset || 'breath';
  const q = state.scanQ || '';
  const d = await api(`/api/scanner?preset=${preset}${q ? '&q=' + encodeURIComponent(q) : ''}`);
  return {
    tab: 'scanner',
    html: `${demoRibbon()}${band('Scanner', `${cfg.demo ? '<span class="orange">● DEMO</span>' : '<span class="up">● LIVE</span>'} · ${d.passed}/${d.scanned} passed gates · ${d.calm} Calm Buy Zone`, { back: false })}
    <div class="page">
      <label class="search">${icon('scan', 18)}<input id="scan-q" value="${esc(q)}" placeholder="Symbol or sector"></label>
      <div class="chips">${PRESETS.map(([id, label]) => `<button class="chip ${preset === id ? 'on' : ''}" data-preset="${id}">${label}</button>`).join('')}</div>
      <div class="xs muted">${PRESETS.find(p => p[0] === preset)[2]}</div>
      <table class="tbl"><thead><tr><th>SYMBOL</th><th>LTP</th><th>CHG%</th><th>DEL×</th><th>OI</th><th>SCORE</th></tr></thead><tbody>
      ${d.rows.map(r => `<tr data-go="#/check/${r.symbol}"><td class="sb">${r.symbol}<div class="xs muted">${esc(r.setup)}</div></td>
        <td data-ltp="${r.symbol}">${inr(r.price)}</td><td class="${cls(r.chg_pct)}">${sgn(r.chg_pct)}</td><td>${r.delivery_x ?? '—'}</td>
        <td class="${['LB', 'SC'].includes(r.oi) ? 'up' : r.oi === 'SB' ? 'dn' : 'muted'} xs">${r.oi || '—'}</td>
        <td class="b ${r.verdict === 'Calm Buy Zone' ? 'up' : r.verdict === 'Wait for the Breath' ? 'gold' : ''}">${r.score}</td></tr>`).join('')}
      </tbody></table>
      ${d.rows.length ? (d.total > d.rows.length ? `<div class="xs muted">Showing the top ${d.rows.length} of ${d.total}. Search to narrow down.</div>` : '') : '<div class="empty">No stocks match</div>'}
      <div class="xs muted">OI: LB long buildup · SC short covering · SB short buildup · LU long unwinding. Green score = Calm Buy Zone, gold = Wait for the Breath.</div>
    </div>`,
    mount(root, rerender) {
      root.querySelectorAll('[data-preset]').forEach(b => b.onclick = () => { state.scanPreset = b.dataset.preset; rerender(); });
      const inp = root.querySelector('#scan-q');
      let t; inp.oninput = () => { clearTimeout(t); t = setTimeout(() => { state.scanQ = inp.value; rerender(true); }, 400); };
    },
  };
}

export async function multibagger() {
  const stage = state.mbStage || 'Early';
  const d = await api(`/api/multibagger?stage=${stage}`);
  const counts = d.counts || {};
  return {
    tab: 'multibagger',
    html: `${demoRibbon()}${band('Multibagger Radar', 'Small &amp; mid caps with the growth DNA · reviewed quarterly', { back: false })}
    <div class="page">
      <div class="card" style="padding:10px 12px"><div class="grid3 xs dim">
        <span><b class="gold">G</b> Sales &amp; profit 3Y ≥20%</span><span><b class="gold">R</b> ROCE ≥18%</span><span><b class="gold">D</b> Debt/Eq ≤0.5</span>
        <span><b class="gold">P</b> Promoter ≥50%</span><span><b class="gold">S</b> ₹500–10k cr</span><span><b class="gold">T</b> Above rising 200 DMA</span></div></div>
      <div class="seg">${['Early', 'Base', 'Trending'].map(s => `<button class="${stage === s ? 'on' : ''}" data-stage="${s}">${s} ${counts[s] ?? ''}</button>`).join('')}</div>
      <div class="list">${d.rows.map(r => `<a class="item" href="#/check/${r.symbol}" style="color:var(--text)">
        <div class="between"><span class="b">${r.symbol}</span><span data-ltp="${r.symbol}">₹${inr(r.price)}</span></div>
        <div class="xs muted">MCAP ₹${inr(r.mcap_cr, 0)}cr · SALES 3Y <span class="up">+${r.sales_cagr3}%</span> · ROCE ${r.roce}% · PE ${r.pe}</div>
        <div class="between">${dnaTiles(r.tests)}<span class="small muted">${r.passed}/6${r.warning ? ' · ' + esc(r.warning) : ''}</span></div></a>`).join('') || '<div class="empty">No stocks at this stage</div>'}</div>
      ${!cfg.demo && !d.with_fundamentals ? `<a class="warn" href="#/datasource" style="display:block">Multibagger DNA needs company fundamentals (sales growth, ROCE, debt, promoter). Import your fundamentals CSV in Market data →</a>` : ''}
      <div class="xs muted">A screen, not a tip. Check the business before you invest.</div>
    </div>`,
    mount(root, rerender) { root.querySelectorAll('[data-stage]').forEach(b => b.onclick = () => { state.mbStage = b.dataset.stage; rerender(); }); },
  };
}

export async function blast() {
  const tab = state.blastTab || 'lit';
  const d = await api(`/api/blast?tab=${tab}`);
  return {
    tab: 'blast',
    html: `${demoRibbon()}${band('Blast <span class="orange">Watch</span>', 'Coiled stocks where pressure is building', { back: false })}
    <div class="page">
      <div class="seg"><button class="${tab === 'lit' ? 'on' : ''}" data-tab="lit">Fuse lit · ${d.counts.lit}</button><button class="${tab === 'ignited' ? 'on' : ''}" data-tab="ignited">Ignited today · ${d.counts.ignited}</button></div>
      <div class="xs muted">FUSE = range squeeze + volume pickup + accumulation + distance to 52-week high + catalyst</div>
      <div class="list">${d.rows.map(r => `<a class="item" href="#/check/${r.symbol}" style="color:var(--text)">
        <div class="between"><span class="b">${r.symbol}</span><span><span data-ltp="${r.symbol}">₹${inr(r.price)}</span> <span class="${cls(r.chg_pct)}">${sgn(r.chg_pct)}%</span></span></div>
        <div class="row"><div class="grow">${bar(r.fuse, 'orange')}</div><span class="b orange" style="width:40px;text-align:right">${r.fuse}%</span></div>
        <div class="chips">${r.tags.map(t => `<span class="tag">${esc(t)}</span>`).join('')}</div></a>`).join('') || '<div class="empty">Nothing here right now</div>'}</div>
      <div class="xs muted">A high fuse means the setup is tight, not that a move is certain. Plan the stop first.</div>
    </div>`,
    mount(root, rerender) { root.querySelectorAll('[data-tab]').forEach(b => b.onclick = () => { state.blastTab = b.dataset.tab; rerender(); }); },
  };
}

export async function news() {
  const tab = state.newsTab || 'mb';
  const d = await api(`/api/news?tab=${tab}`);
  return {
    tab: 'news',
    html: `${demoRibbon()}${band('News', 'NSE · BSE filings, checked against the rules', { back: false })}
    <div class="page">
      <div class="seg">${[['mb', 'Multibagger'], ['bl', 'Blast'], ['pn', 'Penny'], ['all', 'All']].map(([id, l]) => `<button class="${tab === id ? 'on' : ''}" data-tab="${id}">${l}</button>`).join('')}</div>
      ${tab === 'pn' ? `<a class="card between" href="#/penny" style="border-color:var(--red);color:var(--text)"><span><b class="dn">Penny Buzz board</b> · buzz vs substance</span><span class="dn">Open →</span></a>` : ''}
      <div class="list">${d.items.map(n => `<div class="item">
        <div class="row xs"><span class="muted">${esc(n.date && n.date !== todayIso() ? n.date.slice(5) + ' ' : '')}${esc(n.time || '')}</span><span class="tag" style="background:var(--card2)">${n.symbol}</span><span class="tag">${esc(n.kind)}</span></div>
        <div style="font-size:15px;line-height:1.4">${esc(n.head)}</div>
        <div class="small muted">${esc(n.why || '')}</div>
        <div class="between"><span><span data-ltp="${n.symbol}">₹${inr(n.price)}</span> <span class="small ${cls(n.chg_pct)}">${sgn(n.chg_pct)}%</span></span><span class="row">${n.signal !== 'none' ? signalBadge(n.signal) : ''}<a class="btn sm ghost" href="#/alert/${n.symbol}" style="display:inline-flex;align-items:center">View</a></span></div>
      </div>`).join('') || (tab === 'all' ? '<div class="empty">No filings yet</div>' : '<div class="empty">No filings for this group. Try All.</div>')}</div>
    </div>`,
    mount(root, rerender) { root.querySelectorAll('[data-tab]').forEach(b => b.onclick = () => { state.newsTab = b.dataset.tab; rerender(); }); },
  };
}

export async function penny() {
  const hide = state.pennyHide !== false;
  const band_ = state.pennyBand || '';
  const d = await api(`/api/penny?hide_asm=${hide ? 1 : 0}`);
  let rows = d.rows;
  if (band_ === 'u20') rows = rows.filter(r => r.price < 20);
  if (band_ === '20-50') rows = rows.filter(r => r.price >= 20);
  return {
    tab: 'news',
    html: `${demoRibbon()}${band('Penny <span class="dn">Buzz</span>', 'Under ₹50 · ranked by buzz today')}
    <div class="page">
      <div class="warn">High-risk zone. Many penny moves are operator-driven. Read <b>Substance</b> before <b>Buzz</b>.</div>
      <div class="chips"><button class="chip ${band_ === 'u20' ? 'on' : ''}" data-band="u20">Under ₹20</button><button class="chip ${band_ === '20-50' ? 'on' : ''}" data-band="20-50">₹20–50</button>
        <button class="chip ${hide ? 'on' : ''}" data-hide>${hide ? 'Hiding ASM/GSM' : 'Showing ASM/GSM'}</button></div>
      <div class="list">${rows.map(r => `<a class="item" href="#/alert/${r.symbol}" style="color:var(--text)">
        <div class="between"><span><b>${r.symbol}</b> <span data-ltp="${r.symbol}">₹${inr(r.price)}</span> <span class="${cls(r.chg_pct)}">${sgn(r.chg_pct)}%</span></span>${verdictBadge(r.verdict)}</div>
        <div style="display:grid;grid-template-columns:74px 1fr 34px;gap:8px;align-items:center" class="xs"><span class="orange">BUZZ</span>${bar(r.buzz, 'orange')}<span>${r.buzz}</span>
          <span class="blue">SUBSTANCE</span>${bar(r.substance, 'blue')}<span>${r.substance}</span></div>
        <div class="chips">${r.flags.map(f => `<span class="tag">${esc(f)}</span>`).join('')}</div></a>`).join('') || '<div class="empty">No penny stocks match</div>'}</div>
    </div>`,
    mount(root, rerender) {
      root.querySelectorAll('[data-band]').forEach(b => b.onclick = () => { state.pennyBand = state.pennyBand === b.dataset.band ? '' : b.dataset.band; rerender(); });
      root.querySelector('[data-hide]').onclick = () => { state.pennyHide = !hide; rerender(); };
    },
  };
}

const todayIso = () => new Date(Date.now() + 5.5 * 3600e3).toISOString().slice(0, 10);
