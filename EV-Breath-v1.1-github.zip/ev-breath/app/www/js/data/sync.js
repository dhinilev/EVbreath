// Keeps NSE daily data on the phone: about a year of price + delivery history, recent F&O OI,
// NIFTY and India VIX, company names/sectors, ASM and F&O ban lists, FII/DII flows.
// First sync downloads one small file per trading day (a few minutes); after that, one file a day.
import { idb, kv } from './idb.js';
import * as nse from './nse.js';

const IST = 5.5 * 3600 * 1000;
export const nowIst = () => new Date(Date.now() + IST); // read with getUTC* methods
const dayOnly = d => new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
const KEEP = 330;

// Trading days to look at, newest first. Today counts only after 6:30 PM IST, when NSE publishes the files.
function candidateDays(n) {
  const t = nowIst();
  let d = dayOnly(t);
  if (t.getUTCHours() * 60 + t.getUTCMinutes() < 18 * 60 + 30) d = new Date(d.getTime() - 86400000);
  const out = [];
  while (out.length < n) {
    const wd = d.getUTCDay();
    if (wd !== 0 && wd !== 6) out.push(d);
    d = new Date(d.getTime() - 86400000);
  }
  return out;
}

let running = null;
export const isSyncing = () => !!running;

// onProgress({phase, done, total, note})
export function syncAll(opts = {}) {
  if (running) return running;
  running = doSync(opts).finally(() => { running = null; });
  return running;
}

async function doSync({ days = 260, onProgress = () => {} } = {}) {
  const status = await kv.get('sync.days', {});
  const log = [];
  const result = { added: 0, holidays: 0, errors: [] };

  // 1. Lists (cheap, refreshed daily)
  onProgress({ phase: 'Lists', done: 0, total: 1, note: 'Company list, ASM, F&O ban, FII/DII' });
  const today = nse.iso(nowIst());
  if ((await kv.get('sync.lists')) !== today) {
    try {
      const companies = await nse.companyList();
      const old = await kv.get('meta.companies', {});
      await kv.set('meta.companies', { ...old, ...companies });
    } catch (e) { result.errors.push('Company list: ' + e.message); }
    try { await kv.set('ban', await nse.foBan()); } catch (e) { result.errors.push('F&O ban list: ' + e.message); }
    try { await kv.set('asm', await nse.asmList()); } catch (e) { result.errors.push('ASM list: ' + e.message); }
    try { const f = await nse.fiiDii(); if (f.fii_cr !== undefined) await kv.set('flows', f); } catch (e) { result.errors.push('FII/DII: ' + e.message); }
    if (!result.errors.length) await kv.set('sync.lists', today);
  }

  // 2. Daily files
  const cands = candidateDays(Math.round(days * 1.12) + 10);
  let okCount = cands.filter(d => status[nse.iso(d)] === 'ok').length;
  const todo = [];
  for (const d of cands) {
    const k = nse.iso(d);
    if (status[k] === 'ok' || status[k] === 'holiday') continue;
    todo.push(d);
  }
  // Stop once we have enough trading days in total.
  const need = Math.max(0, days - okCount);
  const queue = todo.slice(0, need + 12).reverse(); // oldest first
  if (!queue.length) { onProgress({ phase: 'Up to date', done: 1, total: 1 }); await kv.set('sync.last', Date.now()); return { ...result, upToDate: true }; }

  const recs = new Map(await idb.all('bars'));
  const recent = new Set(cands.slice(0, 35).map(nse.iso));   // F&O OI for the last ~30 sessions
  const recentIdx = new Set(cands.slice(0, 90).map(nse.iso)); // index history for the market filter
  const nifty = await kv.get('index.NIFTY', []);
  const vixHist = await kv.get('index.VIX', []);
  let n = 0, consecutiveFail = 0;

  for (const d of queue) {
    const k = nse.iso(d);
    onProgress({ phase: 'Daily files', done: n, total: queue.length, note: k });
    let eq = null;
    try { eq = await retry(() => nse.equityBhavcopy(d)); }
    catch (e) {
      if (e.status === 404) { status[k] = 'holiday'; result.holidays++; n++; consecutiveFail = 0; continue; }
      result.errors.push(`${k}: ${e.message}`);
      if (++consecutiveFail >= 3) { result.errors.push('Stopped: NSE is not answering. Try again later.'); break; }
      n++; continue;
    }
    consecutiveFail = 0;
    for (const [sym, b] of eq) addBar(recs, sym, k, b);
    if (recent.has(k)) {
      try {
        const oi = await nse.foBhavcopy(d);
        for (const [sym, v] of oi) setOi(recs, sym, k, v);
      } catch (e) { if (e.status !== 404) log.push(`F&O ${k}: ${e.message}`); }
      await nse.gentle();
    }
    if (recentIdx.has(k)) {
      try {
        const idx = await nse.indexClose(d);
        if (idx['Nifty 50']) upsert(nifty, idx['Nifty 50']);
        if (idx['India VIX']) upsert(vixHist, idx['India VIX']);
      } catch (e) { if (e.status !== 404) log.push(`Index ${k}: ${e.message}`); }
      await nse.gentle();
    }
    status[k] = 'ok';
    result.added++;
    n++;
    if (n % 20 === 0) await save(recs, status, nifty, vixHist);
    await nse.gentle();
  }
  await save(recs, status, nifty, vixHist);
  await kv.set('sync.last', Date.now());
  await kv.set('sync.log', [...result.errors, ...log].slice(0, 30));
  onProgress({ phase: 'Done', done: queue.length, total: queue.length });
  return result;
}

async function retry(fn) {
  try { return await fn(); }
  catch (e) { if (e.status === 404) throw e; await new Promise(r => setTimeout(r, 2500)); return fn(); }
}

function upsert(list, bar) {
  const i = list.findIndex(b => b.date === bar.date);
  if (i >= 0) list[i] = bar; else { list.push(bar); list.sort((a, b) => (a.date < b.date ? -1 : 1)); }
  if (list.length > 400) list.splice(0, list.length - 400);
}

function addBar(recs, sym, date, b) {
  let r = recs.get(sym);
  if (!r) { r = { symbol: sym, date: [], o: [], h: [], l: [], c: [], v: [], dl: [], oi: [] }; recs.set(sym, r); }
  let i = r.date.length;
  if (i && r.date[i - 1] >= date) {
    const j = r.date.indexOf(date);
    if (j >= 0) { r.o[j] = b.open; r.h[j] = b.high; r.l[j] = b.low; r.c[j] = b.close; r.v[j] = b.volume; r.dl[j] = b.dl; return; }
    i = r.date.findIndex(x => x > date);
  }
  r.date.splice(i, 0, date); r.o.splice(i, 0, b.open); r.h.splice(i, 0, b.high); r.l.splice(i, 0, b.low);
  r.c.splice(i, 0, b.close); r.v.splice(i, 0, b.volume); r.dl.splice(i, 0, b.dl); r.oi.splice(i, 0, 0);
  r.touched = true;
}

function setOi(recs, sym, date, v) {
  const r = recs.get(sym);
  if (!r) return;
  const j = r.date.lastIndexOf(date);
  if (j >= 0) { r.oi[j] = v; r.touched = true; }
}

async function save(recs, status, nifty, vixHist) {
  const entries = [];
  for (const [sym, r] of recs) {
    if (!r.touched) continue;
    if (r.date.length > KEEP) for (const k of ['date', 'o', 'h', 'l', 'c', 'v', 'dl', 'oi']) r[k] = r[k].slice(-KEEP);
    delete r.touched;
    entries.push([sym, r]);
  }
  for (let i = 0; i < entries.length; i += 400) await idb.setMany('bars', entries.slice(i, i + 400));
  await kv.set('sync.days', status);
  await kv.set('index.NIFTY', nifty);
  await kv.set('index.VIX', vixHist);
  if (vixHist.length) await kv.set('vix', vixHist[vixHist.length - 1].close);
}

export async function syncInfo() {
  const [status, last, logs, count, nifty] = await Promise.all([kv.get('sync.days', {}), kv.get('sync.last', null), kv.get('sync.log', []), idb.count('bars'), kv.get('index.NIFTY', [])]);
  const ok = Object.entries(status).filter(([, v]) => v === 'ok').map(([k]) => k).sort();
  return { days: ok.length, first: ok[0] || null, latest: ok[ok.length - 1] || null, last, errors: logs, symbols: count, nifty_days: nifty.length };
}

export async function clearData() {
  await idb.clear('bars');
  for (const k of ['sync.days', 'sync.last', 'sync.log', 'sync.lists', 'index.NIFTY', 'index.VIX', 'index.SENSEX', 'vix', 'live.today', 'filings', 'seen.filings']) await kv.del(k);
}

// ---------------------------------------------------------------- fundamentals CSV (Multibagger DNA)
const NUM = ['mcap_cr', 'promoter_pct', 'promoter_change_4q', 'pledge_pct', 'sales_cagr3', 'profit_cagr3', 'sales_yoy_q1', 'sales_yoy_q2',
  'roce', 'roce3y', 'de', 'icr', 'pe', 'sector_pe', 'ttm_sales_cr', 'results_in_days'];
const FUND = ['sales_cagr3', 'profit_cagr3', 'roce', 'roce3y', 'de', 'icr', 'pe', 'sector_pe', 'ttm_sales_cr'];

export async function importFundamentals(text) {
  const rows = nse.parseCsv(text);
  const fund = await kv.get('fund', {});
  let n = 0;
  for (const row of rows) {
    const sym = String(row.symbol || row.Symbol || row.SYMBOL || '').trim().toUpperCase();
    if (!sym) continue;
    const v = {};
    for (const k of NUM) if (row[k] !== undefined && row[k] !== '') { const x = parseFloat(row[k]); if (isFinite(x)) v[k] = x; }
    const rec = {};
    for (const k of ['mcap_cr', 'promoter_pct', 'promoter_change_4q', 'pledge_pct']) if (k in v) rec[k] = v[k];
    if ('results_in_days' in v) rec.results_in_days = Math.round(v.results_in_days);
    rec.fundamentals = {};
    for (const k of FUND) if (k in v) rec.fundamentals[k] = v[k];
    rec.fundamentals.sales_yoy_q = [v.sales_yoy_q1 || 0, v.sales_yoy_q2 || 0];
    if (row.name) rec.name = row.name.trim();
    if (row.sector) rec.sector = row.sector.trim();
    fund[sym] = rec;
    n++;
  }
  await kv.set('fund', fund);
  return n;
}
