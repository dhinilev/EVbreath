// Tiny IndexedDB wrapper. Works in the page and in the engine worker (same database).
// Stores: "bars" (one record per symbol, column arrays) and "kv" (settings, lists, caches).
const DB_NAME = 'evbreath';
const VERSION = 1;
let dbp = null;
const mem = { bars: new Map(), kv: new Map() }; // fallback when IndexedDB is unavailable

function open() {
  if (dbp) return dbp;
  dbp = new Promise(resolve => {
    try {
      const req = indexedDB.open(DB_NAME, VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('bars')) db.createObjectStore('bars');
        if (!db.objectStoreNames.contains('kv')) db.createObjectStore('kv');
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
      req.onblocked = () => resolve(null);
    } catch { resolve(null); }
  });
  return dbp;
}

function wrap(req) {
  return new Promise((resolve, reject) => { req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error); });
}

async function tx(store, mode, fn) {
  const db = await open();
  if (!db) return fn(null);
  const t = db.transaction(store, mode);
  const os = t.objectStore(store);
  const out = await fn(os);
  if (mode === 'readwrite') await new Promise((res, rej) => { t.oncomplete = res; t.onerror = () => rej(t.error); t.onabort = () => rej(t.error); });
  return out;
}

export const idb = {
  async get(store, key) {
    return tx(store, 'readonly', os => (os ? wrap(os.get(key)) : mem[store].get(key)));
  },
  async set(store, key, value) {
    return tx(store, 'readwrite', os => { if (os) os.put(value, key); else mem[store].set(key, value); });
  },
  async setMany(store, entries) {
    return tx(store, 'readwrite', os => { for (const [k, v] of entries) { if (os) os.put(v, k); else mem[store].set(k, v); } });
  },
  async del(store, key) {
    return tx(store, 'readwrite', os => { if (os) os.delete(key); else mem[store].delete(key); });
  },
  async all(store) {
    return tx(store, 'readonly', async os => {
      if (!os) return [...mem[store].entries()];
      const [keys, vals] = await Promise.all([wrap(os.getAllKeys()), wrap(os.getAll())]);
      return keys.map((k, i) => [k, vals[i]]);
    });
  },
  async count(store) {
    return tx(store, 'readonly', os => (os ? wrap(os.count()) : mem[store].size));
  },
  async clear(store) {
    return tx(store, 'readwrite', os => { if (os) os.clear(); else mem[store].clear(); });
  },
};

export const kv = {
  get: async (k, dflt = null) => { try { const v = await idb.get('kv', k); return v === undefined ? dflt : v; } catch { return dflt; } },
  set: (k, v) => idb.set('kv', k, v).catch(() => {}),
  del: k => idb.del('kv', k).catch(() => {}),
};
