// Broker connectors for MARKET DATA ONLY: HDFC Sky and Sharekhan.
// EV Breath is a watch-only app. These connectors log in and read prices; there is no order code here.
// Keys stay on this phone (app storage) and are sent only to the broker's own servers.
import { http, UA } from './http.js';
import { kv } from './idb.js';
import { unzipText } from './zip.js';
import { parseCsv } from './nse.js';

export const REDIRECT_URL = 'https://localhost/callback.html';
const istDate = () => new Date(Date.now() + 5.5 * 3600e3).toISOString().slice(0, 10);

export const BROKERS = [
  {
    id: 'hdfcsky', name: 'HDFC Sky', product: 'HDFC Sky Open API', portal: 'https://developer.hdfcsky.com',
    docs: 'https://developer.hdfcsky.com/sky-docs/docs/intro',
    fields: [['client_id', 'Client ID'], ['api_key', 'API key'], ['api_secret', 'API secret']],
    steps: ['Open developer.hdfcsky.com › My Apps › + Create.', `Redirect URL: ${REDIRECT_URL}`, 'Static IP fields: SEBI requires them for orders. This app never places orders; enter your current IP if the form insists.',
      'Create, then switch the app to Active and copy the API key and secret here.'],
    feed: 'Live prices: REST every 5 seconds for your watchlist and open stock',
  },
  {
    id: 'sharekhan', name: 'Sharekhan', product: 'Sharekhan API', portal: 'https://api.sharekhan.com',
    docs: 'https://github.com/Sharekhan-API/shareconnectnodejs',
    fields: [['customer_id', 'Customer ID'], ['api_key', 'API key'], ['secret_key', 'Secret key'], ['vendor_key', 'Vendor key (optional)'], ['version_id', 'Version ID (optional)']],
    steps: ['Create an API app in your Sharekhan API account.', `Redirect URL: ${REDIRECT_URL}`, 'Copy the API key and secret key here.'],
    feed: 'Live prices: Sharekhan streaming (websocket)',
  },
];
export const BY_ID = Object.fromEntries(BROKERS.map(b => [b.id, b]));

export async function getCfg(id) { return (await kv.get('broker.' + id, {})) || {}; }
export async function saveCfg(id, vals) { const c = { ...(await getCfg(id)), ...vals }; await kv.set('broker.' + id, c); return c; }
export async function forget(id) { await kv.del('broker.' + id); if ((await kv.get('broker.active')) === id) await kv.del('broker.active'); }
export async function active() {
  const id = await kv.get('broker.active');
  if (!id) return null;
  const c = await getCfg(id);
  return { id, cfg: c, connected: !!c.token && c.token_date === istDate() };
}
export async function statusAll() {
  const act = await kv.get('broker.active');
  const out = {};
  for (const b of BROKERS) {
    const c = await getCfg(b.id);
    out[b.id] = { saved: !!c.api_key, connected: !!c.token && c.token_date === istDate(), expired: !!c.token && c.token_date !== istDate(), active: act === b.id, token_date: c.token_date || null, error: c.error || null };
  }
  return out;
}

// ---------------------------------------------------------------- login
export async function loginUrl(id) {
  const c = await getCfg(id);
  if (!c.api_key) throw new Error('Save your API key first');
  if (id === 'hdfcsky') return `https://developer.hdfcsky.com/oapi/v1/login?api_key=${encodeURIComponent(c.api_key)}&state=evbreath`;
  let u = `https://api.sharekhan.com/skapi/auth/login.html?api_key=${encodeURIComponent(c.api_key)}`;
  if (c.vendor_key) u += `&vendor_key=${encodeURIComponent(c.vendor_key)}`;
  u += '&state=12345';
  if (c.version_id) u += `&version_id=${encodeURIComponent(c.version_id)}`;
  return u;
}

// Pull the request token out of the redirect address (works for a pasted link too).
export function tokenFromUrl(text) {
  try {
    const u = new URL(String(text).trim());
    const p = u.searchParams;
    return p.get('request_token') || p.get('requestToken') || p.get('request-token') || p.get('code') || null;
  } catch { return null; }
}

export async function finishLogin(id, requestToken) {
  const c = await getCfg(id);
  if (!requestToken) throw new Error('No request token in the link');
  let token;
  if (id === 'hdfcsky') {
    const r = await http('https://developer.hdfcsky.com/oapi/v1/access-token', {
      method: 'POST', params: { api_key: c.api_key, request_token: requestToken },
      headers: { 'User-Agent': UA, Accept: 'application/json', 'Content-Type': 'application/json' }, body: { apiSecret: c.api_secret },
    });
    const d = r.data || {};
    token = d.accessToken || d.access_token || (d.data && (d.data.accessToken || d.data.access_token));
    if (!token) throw new Error('HDFC Sky did not return a token: ' + JSON.stringify(d).slice(0, 160));
  } else {
    const enc = await sharekhanSwap(decodeURIComponent(requestToken), c.secret_key);
    const body = { apiKey: c.api_key, requestToken: enc, state: '12345' };
    if (c.version_id) body.versionId = c.version_id;
    const r = await http('https://api.sharekhan.com/skapi/services/access/token', {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'api-key': c.api_key, ...(c.vendor_key ? { 'vendor-key': c.vendor_key } : {}) }, body,
    });
    const d = r.data || {};
    token = (d.data && (d.data.token || d.data.accessToken)) || d.token || d.accessToken;
    if (!token) throw new Error('Sharekhan did not return a token: ' + JSON.stringify(d).slice(0, 160));
  }
  await saveCfg(id, { token, token_date: istDate(), error: null });
  await kv.set('broker.active', id);
  return true;
}

// Sharekhan: AES-256-GCM (zero IV) decrypt the request token, swap "a|b" to "b|a", encrypt again (base64url).
const b64urlToBytes = s => { s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; const b = atob(s); return Uint8Array.from(b, c => c.charCodeAt(0)); };
const bytesToB64url = u => { let s = ''; for (const x of u) s += String.fromCharCode(x); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };
export async function sharekhanSwap(requestToken, secret) {
  if (!secret || new TextEncoder().encode(secret).length !== 32) throw new Error('The Sharekhan secret key must be 32 characters');
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), 'AES-GCM', false, ['encrypt', 'decrypt']);
  const iv = new Uint8Array(16);
  const plain = new TextDecoder().decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv, tagLength: 128 }, key, b64urlToBytes(requestToken)));
  const [a, b] = plain.split('|');
  const enc = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv, tagLength: 128 }, key, new TextEncoder().encode(`${b}|${a}`)));
  return bytesToB64url(enc);
}

// ---------------------------------------------------------------- instrument tokens
// HDFC Sky: public security master (zip, ~17 MB). Kept for a week.
export async function hdfcTokens(force = false) {
  const cached = await kv.get('hdfc.tokens');
  if (cached && !force && Date.now() - cached.at < 7 * 86400e3) return cached;
  const r = await http('https://hdfcsky.com/api/v1/contract/Compact?info=download', { type: 'bytes', headers: { 'User-Agent': UA }, timeout: 120000 });
  const rows = parseCsv(await unzipText(r.data));
  const NSE = {}, BSE = {}, idx = {};
  for (const x of rows) {
    const ex = String(x.exchange || '').toUpperCase(), ts = String(x.trading_symbol || ''), seg = String(x.segment || '').toUpperCase();
    if (ex === 'NSE' && seg === 'INDICES') {
      if (/^NIFTY( 50)?$/i.test(ts) || /^NIFTY 50$/i.test(x.company_name || '')) idx.NIFTY = { exchange: 'NSE_INDEX', token: x.exchange_token };
    } else if (ex === 'BSE' && seg === 'IDX') {
      if (/^SENSEX$/i.test(ts) || /^SENSEX$/i.test(x.company_name || '')) idx.SENSEX = { exchange: 'BSE_INDEX', token: x.exchange_token };
    } else if (ex === 'NSE' && ts.endsWith('-EQ')) NSE[ts.slice(0, -3)] = x.exchange_token;
    else if (ex === 'NSE' && /-(BE|BZ|SM|ST)$/.test(ts)) { const s = ts.replace(/-(BE|BZ|SM|ST)$/, ''); if (!NSE[s]) NSE[s] = x.exchange_token; }
    else if (ex === 'BSE' && seg && ts.endsWith('-' + seg)) BSE[ts.slice(0, -(seg.length + 1))] = x.exchange_token;
  }
  const out = { at: Date.now(), NSE, BSE, idx };
  await kv.set('hdfc.tokens', out);
  return out;
}

// Sharekhan: scrip master for NSE cash ("NC").
export async function sharekhanCodes(force = false) {
  const cached = await kv.get('sk.codes');
  if (cached && !force && Date.now() - cached.at < 7 * 86400e3) return cached;
  const c = await getCfg('sharekhan');
  const r = await http('https://api.sharekhan.com/skapi/services/master/NC', { headers: { 'api-key': c.api_key, 'access-token': c.token, Authorization: c.token, 'Content-Type': 'application/json' }, timeout: 90000 });
  const list = Array.isArray(r.data) ? r.data : (r.data && (r.data.data || r.data.message)) || [];
  const NC = {};
  for (const x of Array.isArray(list) ? list : []) {
    const sym = String(x.tradingSymbol || x.TradingSymbol || x.symbol || '').replace(/-EQ$/, '').toUpperCase();
    const code = x.scripCode ?? x.ScripCode ?? x.scripcode;
    if (sym && code !== undefined && !(sym in NC)) NC[sym] = String(code);
  }
  const out = { at: Date.now(), NC };
  await kv.set('sk.codes', out);
  return out;
}

// ---------------------------------------------------------------- live prices
// HDFC Sky: PUT /oapi/v1/fetch-ltp, at most 10 instruments per call.
export async function hdfcLtp(symbols, withIndex = true) {
  const c = await getCfg('hdfcsky');
  const t = await hdfcTokens();
  const items = [];
  for (const s of symbols) if (t.NSE[s]) items.push({ key: s, exchange: 'NSE', token: String(t.NSE[s]) });
  if (withIndex) for (const n of ['NIFTY', 'SENSEX']) if (t.idx[n]) items.push({ key: n, exchange: t.idx[n].exchange, token: String(t.idx[n].token) });
  const out = {};
  for (let i = 0; i < items.length; i += 10) {
    const batch = items.slice(i, i + 10);
    const r = await http('https://developer.hdfcsky.com/oapi/v1/fetch-ltp', {
      method: 'PUT', params: { api_key: c.api_key }, headers: { Authorization: c.token, 'User-Agent': UA, Accept: 'application/json', 'Content-Type': 'application/json' },
      body: { data: batch.map(b => ({ exchange: b.exchange, token: b.token })) },
    });
    for (const row of (r.data && r.data.data) || []) {
      const hit = batch.find(b => b.token === String(row.token) && b.exchange === String(row.exchange).toUpperCase()) || batch.find(b => b.token === String(row.token));
      if (hit && row.ltp) out[hit.key] = { ltp: +row.ltp, prev: row.prev_close ? +row.prev_close : null };
    }
  }
  return out;
}

// Sharekhan streaming: JSON over websocket.
export function sharekhanStream(token, codes, onTick, onStatus) {
  const rev = Object.fromEntries(Object.entries(codes).map(([s, c]) => ['NC' + c, s]));
  let ws = null, closed = false, retry = 0, ping = null;
  const open = () => {
    ws = new WebSocket(`wss://stream.sharekhan.com/skstream/api/stream?ACCESS_TOKEN=${encodeURIComponent(token)}`);
    ws.onopen = () => {
      retry = 0; onStatus('live');
      ws.send(JSON.stringify({ action: 'subscribe', key: ['feed'], value: [''] }));
      const keys = Object.keys(rev);
      for (let i = 0; i < keys.length; i += 50) ws.send(JSON.stringify({ action: 'feed', key: ['ltp'], value: [keys.slice(i, i + 50).join(',')] }));
      ping = setInterval(() => { try { ws.send('ping'); } catch { /* closed */ } }, 25000);
    };
    ws.onmessage = ev => {
      let m; try { m = JSON.parse(ev.data); } catch { return; }
      const rows = Array.isArray(m) ? m : Array.isArray(m.data) ? m.data : m.data ? [m.data] : [m];
      for (const x of rows) {
        const code = x.scripCode ?? x.ScripCode ?? x.scripcode ?? x.token;
        const ex = x.exchange || x.Exchange || 'NC';
        const sym = rev[`${ex}${code}`] || rev[`NC${code}`];
        const ltp = +(x.ltp ?? x.lastTradedPrice ?? x.LTP ?? x.lastPrice);
        if (sym && ltp) onTick({ symbol: sym, ltp });
      }
    };
    ws.onerror = () => onStatus('error');
    ws.onclose = () => { clearInterval(ping); if (closed) return; onStatus('reconnecting'); setTimeout(open, Math.min(30000, 2000 * 2 ** retry++)); };
  };
  open();
  return () => { closed = true; clearInterval(ping); try { ws.close(); } catch { /* already closed */ } };
}
