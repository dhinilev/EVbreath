// Minimal ZIP reader: returns the text of the first file (or the first .csv) in an archive.
// Uses the browser's built-in DecompressionStream, so no library is needed.
export async function unzipText(bytes, want = /\.csv$/i) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  // Find the end-of-central-directory record.
  let eocd = -1;
  for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('Not a zip file');
  const count = dv.getUint16(eocd + 10, true);
  let p = dv.getUint32(eocd + 16, true);
  const entries = [];
  for (let n = 0; n < count; n++) {
    if (dv.getUint32(p, true) !== 0x02014b50) break;
    const method = dv.getUint16(p + 10, true);
    const csize = dv.getUint32(p + 20, true);
    const nlen = dv.getUint16(p + 28, true), xlen = dv.getUint16(p + 30, true), clen = dv.getUint16(p + 32, true);
    const local = dv.getUint32(p + 42, true);
    const name = new TextDecoder().decode(bytes.subarray(p + 46, p + 46 + nlen));
    entries.push({ name, method, csize, local });
    p += 46 + nlen + xlen + clen;
  }
  const e = entries.find(x => want.test(x.name)) || entries[0];
  if (!e) throw new Error('Empty zip file');
  const lnlen = dv.getUint16(e.local + 26, true), lxlen = dv.getUint16(e.local + 28, true);
  const start = e.local + 30 + lnlen + lxlen;
  const data = bytes.subarray(start, start + e.csize);
  if (e.method === 0) return new TextDecoder().decode(data);
  if (e.method !== 8) throw new Error('Unsupported zip compression');
  const stream = new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
  return new Response(stream).text();
}
