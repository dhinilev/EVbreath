// Live market data controller (runs in the page).
// Feed priority: 1) your connected broker (HDFC Sky REST / Sharekhan stream) for watchlist + open stock,
//                2) NSE / BSE public live data for the whole market, 3) demo ticker in demo mode.
// Also polls NSE filings for Buzz Alerts and keeps the daily files in sync.
import * as B from './brokers.js';
import { kv } from './idb.js';
import * as nse from './nse.js';
import { nowIst, syncAll } from './sync.js';

const listeners = new Set();
export const onLive = fn => { listeners.add(fn); return () => listeners.delete(fn); };
const emit = ev => listeners.forEach(fn => { try { fn(ev); } catch { /* listener error */ } });

export const feeds = {
  broker: { id: 'broker', name: 'Your broker', kind: 'HDFC Sky / Sharekhan · watchlist + open stock', state: 'NOT CONNECTED', ticks: 0, last: null, error: null },
  nse: { id: 'nse', name: 'NSE live (public)', kind: '~750 stocks · NIFTY · India VIX · every 60 s', state: 'STANDBY', ticks: 0, last: null, error: null },
  bse: { id: 'bse', name: 'BSE live (public)', kind: 'SENSEX', state: 'STANDBY', ticks: 0, last: null, error: null },
  filings: { id: 'filings', name: 'NSE announcements', kind: 'Filings for Buzz Alerts · every 2 min', state: 'STANDBY', ticks: 0, last: null, error: null },
  demo: { id: 'demo', name: 'Demo ticker', kind: 'Sample prices', state: 'STANDBY', ticks: 0, last: null, error: null },
};
export const lastPrices = new Map();
let focus = new Set();        // symbols on screen right now
export function setFocus(symbols) { focus = new Set(symbols); }

export function marketOpen(t = nowIst()) {
  const wd = t.getUTCDay(), m = t.getUTCHours() * 60 + t.getUTCMinutes();
  return wd >= 1 && wd <= 5 && m >= 9 * 60 + 15 && m <= 15 * 60 + 32;
}
const filingHours = (t = nowIst()) => { const wd = t.getUTCDay(), h = t.getUTCHours(); return wd >= 1 && wd <= 5 && h >= 7 && h < 22; };

let engine = null; // {send(msg)} from api.js
let timers = [];
let stopStream = null;
let mode = 'demo';
let today = null;

export async function startLive(engineApi, wantedMode) {
  stopLive();
  engine = engineApi;
  mode = wantedMode;
  if (mode === 'demo') { startDemo(); return; }
  feeds.demo.state = 'STANDBY';
  today = (await kv.get('live.today')) || null;
  const d = nse.iso(nowIst());
  if (!today || today.date !== d) today = { date: d, quotes: {}, index: {} };
  await connectBroker();
  every(60000, pollNse, true);
  every(120000, pollFilings, true);
  every(5000, pollBroker, true);
  every(30 * 60000, autoSync, false);
  setTimeout(autoSync, 4000);
}

export function stopLive() {
  timers.forEach(clearInterval); timers = [];
  if (stopStream) { stopStream(); stopStream = null; }
}

function every(ms, fn, now) { if (now) fn(); timers.push(setInterval(fn, ms)); }

function tick(symbol, ltp, src) {
  const prev = lastPrices.get(symbol);
  lastPrices.set(symbol, ltp);
  if (prev !== ltp) emit({ type: 'tick', symbol, ltp, feed: src });
}

// ---------------------------------------------------------------- NSE / BSE
async function pollNse() {
  if (!marketOpen() && today && Object.keys(today.quotes).length) { if (feeds.nse.state === 'ACTIVE') feeds.nse.state = 'MARKET CLOSED'; return; }
  const t = nowIst(), wd = t.getUTCDay(), m = t.getUTCHours() * 60 + t.getUTCMinutes();
  if (wd === 0 || wd === 6 || m < 9 * 60 + 15) { feeds.nse.state = 'MARKET CLOSED'; return; }
  try {
    const [tm, ix] = await Promise.all([nse.liveTotalMarket(), nse.liveIndices()]);
    const d = nse.iso(nowIst());
    if (today.date !== d) today = { date: d, quotes: {}, index: {} };
    for (const [sym, q] of Object.entries(tm.quotes)) {
      today.quotes[sym] = { ...today.quotes[sym], ...q };
      tick(sym, q.ltp, 'nse');
    }
    if (ix.NIFTY) { today.index.NIFTY = ix.NIFTY; tick('NIFTY', ix.NIFTY.ltp, 'nse'); }
    if (ix.VIX) today.vix = ix.VIX.ltp;
    // Watchlist stocks outside the 750 list: one quote each.
    const watch = (await kv.get('watchlist', [])).filter(s => !tm.quotes[s]).slice(0, 15);
    for (const s of watch) {
      try { const q = await nse.quoteEquity(s); if (q.ltp) { today.quotes[s] = { ...today.quotes[s], ltp: q.ltp, open: q.open, high: q.high, low: q.low, prev: q.prev }; tick(s, q.ltp, 'nse'); } }
      catch { /* skip this one */ }
    }
    feeds.nse.state = 'ACTIVE'; feeds.nse.ticks += Object.keys(tm.quotes).length; feeds.nse.last = Date.now(); feeds.nse.error = null;
  } catch (e) { feeds.nse.state = 'DOWN'; feeds.nse.error = e.message; }
  try {
    const s = await nse.sensexLive();
    if (s.ltp) {
      today.index.SENSEX = s; tick('SENSEX', s.ltp, 'bse');
      if (s.prev) await kv.set('index.SENSEX', [{ date: 'prev', open: s.prev, high: s.prev, low: s.prev, close: s.prev, volume: 0 }, { date: today.date, open: s.open || s.ltp, high: s.high || s.ltp, low: s.low || s.ltp, close: s.ltp, volume: 0 }]);
      feeds.bse.state = 'ACTIVE'; feeds.bse.ticks++; feeds.bse.last = Date.now(); feeds.bse.error = null;
    }
  } catch (e) { feeds.bse.state = 'DOWN'; feeds.bse.error = e.message; }
  await kv.set('live.today', today);
  if (engine) {
    await engine.send({ type: 'quotes', today });
    await recomputeAndAlert();
  }
  emitStatus();
}

let lastRecompute = 0;
async function recomputeAndAlert(force = false) {
  if (!force && Date.now() - lastRecompute < 5 * 60000) return;
  lastRecompute = Date.now();
  const res = await engine.send({ type: 'recompute' });
  const seen = new Set(await kv.get('seen.alerts', []));
  const watch = new Set(await kv.get('watchlist', []));
  const fresh = (res.alerts || []).filter(a => !seen.has(a.id));
  if (fresh.length) {
    fresh.forEach(a => seen.add(a.id));
    await kv.set('seen.alerts', [...seen].slice(-500));
    for (const a of fresh) emit({ type: 'alert', alert: { ...a, watched: watch.has(a.symbol) } });
  }
}

async function pollFilings() {
  if (!filingHours()) { feeds.filings.state = 'OFF HOURS'; return; }
  try {
    const items = await nse.announcements();
    const store = await kv.get('filings', {});
    const seenIds = new Set(await kv.get('seen.filings', []));
    let added = 0;
    const { classify, parseValueCr } = await import('../engine/alerts.js');
    for (const a of items) {
      if (seenIds.has(a.id)) continue;
      seenIds.add(a.id);
      const text = `${a.subject} ${a.detail}`;
      const f = { id: String(a.id), date: a.date, time: a.time, kind: classify(text), subject: (a.subject + (a.detail && a.detail !== a.subject ? ' · ' + a.detail : '')).slice(0, 220),
        value_cr: parseValueCr(text), material: false, url: a.url, source: 'NSE' };
      store[a.symbol] = [f, ...(store[a.symbol] || [])].slice(0, 10);
      added++;
    }
    feeds.filings.state = 'ACTIVE'; feeds.filings.last = Date.now(); feeds.filings.ticks += added; feeds.filings.error = null;
    if (added) {
      await kv.set('filings', store);
      await kv.set('seen.filings', [...seenIds].slice(-3000));
      if (engine) { await engine.send({ type: 'reload' }); await recomputeAndAlert(true); }
    }
  } catch (e) { feeds.filings.state = 'DOWN'; feeds.filings.error = e.message; }
  emitStatus();
}

// ---------------------------------------------------------------- broker
let brokerKind = null;
async function connectBroker() {
  const a = await B.active();
  brokerKind = null;
  if (!a) { feeds.broker.state = 'NOT CONNECTED'; feeds.broker.name = 'Your broker'; return; }
  feeds.broker.name = B.BY_ID[a.id].name;
  if (!a.connected) { feeds.broker.state = 'LOGIN NEEDED'; feeds.broker.error = 'Daily login needed (Settings › broker › Log in)'; return; }
  brokerKind = a.id;
  if (a.id === 'sharekhan') {
    try {
      const { NC } = await B.sharekhanCodes();
      const want = new Set([...(await kv.get('watchlist', [])), ...focus]);
      const codes = Object.fromEntries([...want].filter(s => NC[s]).map(s => [s, NC[s]]));
      stopStream = B.sharekhanStream(a.cfg.token, codes, t => { feeds.broker.ticks++; feeds.broker.last = Date.now(); tick(t.symbol, t.ltp, 'sharekhan'); },
        st => { feeds.broker.state = st === 'live' ? 'ACTIVE' : st === 'error' ? 'DOWN' : 'RECONNECTING'; emitStatus(); });
    } catch (e) { feeds.broker.state = 'DOWN'; feeds.broker.error = e.message; }
  } else feeds.broker.state = 'STANDBY';
}

let brokerBusy = false;
async function pollBroker() {
  if (brokerKind !== 'hdfcsky' || brokerBusy) return;
  if (!marketOpen()) { feeds.broker.state = 'MARKET CLOSED'; return; }
  brokerBusy = true;
  try {
    const syms = [...new Set([...focus, ...(await kv.get('watchlist', []))])].slice(0, 40);
    const q = await B.hdfcLtp(syms);
    for (const [s, v] of Object.entries(q)) {
      tick(s, v.ltp, 'hdfcsky');
      if (s === 'NIFTY' || s === 'SENSEX') today.index[s] = { ...(today.index[s] || {}), ltp: v.ltp, prev: v.prev ?? (today.index[s] || {}).prev };
      else today.quotes[s] = { ...(today.quotes[s] || {}), ltp: v.ltp };
    }
    feeds.broker.state = 'ACTIVE'; feeds.broker.ticks += Object.keys(q).length; feeds.broker.last = Date.now(); feeds.broker.error = null;
    if (engine) engine.send({ type: 'ticks', ticks: Object.entries(q).map(([symbol, v]) => ({ symbol, ltp: v.ltp })) });
  } catch (e) {
    feeds.broker.state = 'DOWN'; feeds.broker.error = e.message;
    if (e.status === 401 || e.status === 403) { await B.saveCfg('hdfcsky', { error: 'Session expired or IP not allowed: ' + e.message }); }
  } finally { brokerBusy = false; emitStatus(); }
}

export async function reconnectBroker() { if (stopStream) { stopStream(); stopStream = null; } if (mode === 'live') await connectBroker(); emitStatus(); }

// ---------------------------------------------------------------- daily sync
async function autoSync() {
  const t = nowIst(), m = t.getUTCHours() * 60 + t.getUTCMinutes();
  const last = await kv.get('sync.last', 0);
  const auto = await kv.get('sync.auto', true);
  if (!auto) return;
  // After 6:30 PM IST on weekdays (new files), or if never synced.
  if (last && !(t.getUTCDay() >= 1 && t.getUTCDay() <= 5 && m >= 18 * 60 + 40 && Date.now() - last > 3 * 3600e3)) return;
  if (!last) return; // the first big sync starts only when you press Sync in Market data
  try {
    const r = await syncAll({ onProgress: p => emit({ type: 'sync', p }) });
    if (r.added && engine) { await engine.send({ type: 'reload' }); emit({ type: 'scores' }); }
  } catch { /* try again later */ }
}

// ---------------------------------------------------------------- demo
function startDemo() {
  feeds.demo.state = 'ACTIVE';
  for (const k of ['broker', 'nse', 'bse', 'filings']) feeds[k].state = k === 'broker' ? feeds.broker.state : 'STANDBY';
  const base = new Map();
  timers.push(setInterval(async () => {
    if (!base.size) {
      try { const d = await engine.send({ path: '/api/scanner?preset=breath' }); for (const r of d.rows) base.set(r.symbol, r.price); } catch { return; }
    }
    const syms = [...base.keys()];
    const s = syms[Math.floor(Math.random() * syms.length)];
    const ltp = +(base.get(s) * (1 + (Math.random() - 0.5) * 0.002)).toFixed(2);
    feeds.demo.ticks++; feeds.demo.last = Date.now();
    tick(s, ltp, 'demo');
  }, 700));
  emitStatus();
}

export function liveState() {
  if (mode === 'demo') return 'demo';
  if (feeds.broker.state === 'ACTIVE' || feeds.nse.state === 'ACTIVE') return 'live';
  if (!marketOpen()) return 'closed';
  return 'reconnecting';
}
function emitStatus() { emit({ type: 'status', state: liveState() }); }
