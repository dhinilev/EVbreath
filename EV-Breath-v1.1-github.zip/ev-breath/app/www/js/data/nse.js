// NSE / BSE public data, fetched directly from the phone.
// Exchanges change these addresses from time to time; every caller handles failures and keeps the last good data.
// For your own use only; respect the exchanges' terms.
import { http, sleep, UA } from './http.js';
import { unzipText } from './zip.js';

const ARCH = 'https://nsearchives.nseindia.com';
const WWW = 'https://www.nseindia.com';
const H = { 'User-Agent': UA, Accept: '*/*', 'Accept-Language': 'en-IN,en;q=0.9' };
const API_H = { ...H, Accept: 'application/json, text/plain, */*', Referer: WWW + '/' };
const BSE_H = { ...H, Accept: 'application/json, text/plain, */*', Referer: 'https://www.bseindia.com/', Origin: 'https://www.bseindia.com' };

const pad = n => String(n).padStart(2, '0');
const ddmmyyyy = d => `${pad(d.getUTCDate())}${pad(d.getUTCMonth() + 1)}${d.getUTCFullYear()}`;
const yyyymmdd = d => `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}`;
export const iso = d => d.toISOString().slice(0, 10);
const num = x => { const v = parseFloat(String(x ?? '').replace(/,/g, '').trim()); return isFinite(v) ? v : null; };

// ---------------------------------------------------------------- CSV
export function parseCsv(text) {
  const lines = text.replace(/\r/g, '').split('\n').filter(l => l.trim());
  if (!lines.length) return [];
  const split = l => {
    const out = []; let cur = '', q = false;
    for (let i = 0; i < l.length; i++) {
      const c = l[i];
      if (c === '"') { if (q && l[i + 1] === '"') { cur += '"'; i++; } else q = !q; }
      else if (c === ',' && !q) { out.push(cur); cur = ''; }
      else cur += c;
    }
    out.push(cur);
    return out.map(x => x.trim());
  };
  const head = split(lines[0]).map(h => h.replace(/^﻿/, ''));
  return lines.slice(1).map(l => { const v = split(l); const o = {}; head.forEach((h, i) => { o[h] = v[i] ?? ''; }); return o; });
}

// ---------------------------------------------------------------- cookies for NSE's JSON API
let cookie = '', warmedAt = 0;
async function warm() {
  if (Date.now() - warmedAt < 5 * 60 * 1000 && cookie) return;
  try {
    const r = await http(WWW + '/', { type: 'text', headers: H });
    const sc = r.headers['set-cookie'];
    if (sc) cookie = String(sc).split(/,(?=\s*[A-Za-z0-9_\-]+=)/).map(c => c.split(';')[0].trim()).filter(Boolean).join('; ');
    warmedAt = Date.now();
  } catch { warmedAt = Date.now() - 4 * 60 * 1000; }
}
async function nseApi(path) {
  await warm();
  const headers = cookie ? { ...API_H, Cookie: cookie } : API_H;
  try { return (await http(WWW + '/api/' + path, { headers })).data; }
  catch (e) {
    if (e.status === 401 || e.status === 403) { warmedAt = 0; cookie = ''; await warm(); return (await http(WWW + '/api/' + path, { headers: cookie ? { ...API_H, Cookie: cookie } : API_H })).data; }
    throw e;
  }
}

// ---------------------------------------------------------------- daily files
const SERIES_RANK = { EQ: 0, BE: 1, BZ: 2, SM: 3, ST: 4 };
export async function equityBhavcopy(day) {
  const r = await http(`${ARCH}/products/content/sec_bhavdata_full_${ddmmyyyy(day)}.csv`, { type: 'text', headers: H });
  const out = new Map();
  for (const row of parseCsv(r.data)) {
    const series = row.SERIES;
    if (!(series in SERIES_RANK)) continue;
    const sym = row.SYMBOL;
    const prev = out.get(sym);
    if (prev && SERIES_RANK[prev.series] <= SERIES_RANK[series]) continue;
    const close = num(row.CLOSE_PRICE);
    if (!close) continue;
    out.set(sym, { series, open: num(row.OPEN_PRICE) || close, high: num(row.HIGH_PRICE) || close, low: num(row.LOW_PRICE) || close, close,
      volume: Math.round(num(row.TTL_TRD_QNTY) || 0), dl: num(row.DELIV_PER) });
  }
  if (!out.size) throw new Error('Empty bhavcopy');
  return out;
}

// Total stock-futures open interest per underlying.
export async function foBhavcopy(day) {
  const r = await http(`${ARCH}/content/fo/BhavCopy_NSE_FO_0_0_0_${yyyymmdd(day)}_F_0000.csv.zip`, { type: 'bytes', headers: H });
  const text = await unzipText(r.data);
  const oi = new Map();
  for (const row of parseCsv(text)) {
    if (row.FinInstrmTp !== 'STF') continue;
    oi.set(row.TckrSymb, (oi.get(row.TckrSymb) || 0) + Math.round(num(row.OpnIntrst) || 0));
  }
  return oi;
}

// Daily OHLC of every NSE index (keys like "Nifty 50", "India VIX").
export async function indexClose(day) {
  const r = await http(`${ARCH}/content/indices/ind_close_all_${ddmmyyyy(day)}.csv`, { type: 'text', headers: H });
  const out = {};
  for (const row of parseCsv(r.data)) {
    const name = (row['Index Name'] || '').trim();
    const close = num(row['Closing Index Value']);
    if (!name || !close) continue;
    out[name] = { date: iso(day), open: num(row['Open Index Value']) || close, high: num(row['High Index Value']) || close,
      low: num(row['Low Index Value']) || close, close, volume: 0 };
  }
  return out;
}

// Company names and sectors for about 750 stocks (NIFTY Total Market).
export async function companyList() {
  const r = await http(`${ARCH}/content/indices/ind_niftytotalmarket_list.csv`, { type: 'text', headers: H });
  const out = {};
  for (const row of parseCsv(r.data)) if (row.Symbol) out[row.Symbol] = { name: row['Company Name'], sector: row.Industry || 'Other', isin: row['ISIN Code'] };
  return out;
}

export async function foBan() {
  const r = await http(`${ARCH}/content/fo/fo_secban.csv`, { type: 'text', headers: H });
  return r.data.split('\n').slice(1).map(l => l.split(',').pop().trim()).filter(Boolean);
}

// ---------------------------------------------------------------- JSON APIs
export async function asmList() {
  const d = await nseApi('reportASM');
  const syms = new Set();
  for (const k of ['longterm', 'shortterm']) for (const row of ((d && d[k]) || {}).data || []) if (row.symbol) syms.add(row.symbol);
  return [...syms];
}

export async function fiiDii() {
  const d = await nseApi('fiidiiTradeReact');
  const out = {};
  for (const row of Array.isArray(d) ? d : []) {
    const cat = String(row.category || '').toUpperCase();
    if (cat.includes('FII') || cat.includes('FPI')) out.fii_cr = num(row.netValue);
    else if (cat.includes('DII')) out.dii_cr = num(row.netValue);
    if (row.date) out.date = row.date;
  }
  return out;
}

const MON = { JAN: '01', FEB: '02', MAR: '03', APR: '04', MAY: '05', JUN: '06', JUL: '07', AUG: '08', SEP: '09', OCT: '10', NOV: '11', DEC: '12' };
function nseDate(s) { // "08-Oct-2026 17:42:10"
  const m = /^(\d{2})-([A-Za-z]{3})-(\d{4})\s+(\d{2}:\d{2})/.exec(s || '');
  return m ? { date: `${m[3]}-${MON[m[2].toUpperCase()]}-${m[1]}`, time: m[4] } : { date: null, time: null };
}

export async function announcements() {
  const d = await nseApi('corporate-announcements?index=equities');
  return (Array.isArray(d) ? d : []).map(a => {
    const { date, time } = nseDate(a.an_dt || a.sort_date);
    return { id: a.seq_id || `${a.symbol}|${a.an_dt}|${a.desc}`, symbol: a.symbol, subject: a.desc || '', detail: a.attchmntText || '',
      date, time, url: a.attchmntFile || null, source: 'NSE' };
  }).filter(a => a.symbol);
}

// Live prices of ~750 stocks in one call.
export async function liveTotalMarket() {
  const d = await nseApi('equity-stockIndices?index=' + encodeURIComponent('NIFTY TOTAL MARKET'));
  const out = {};
  for (const r of (d && d.data) || []) {
    if (!r.symbol || r.priority === 1 || r.symbol === 'NIFTY TOTAL MARKET') continue;
    const ltp = num(r.lastPrice);
    if (!ltp) continue;
    out[r.symbol] = { ltp, open: num(r.open), high: num(r.dayHigh), low: num(r.dayLow), prev: num(r.previousClose), volume: Math.round(num(r.totalTradedVolume) || 0) };
  }
  return { quotes: out, time: d && d.timestamp };
}

export async function liveIndices() {
  const d = await nseApi('allIndices');
  const out = {};
  for (const r of (d && d.data) || []) {
    const name = r.index || r.indexSymbol;
    if (name === 'NIFTY 50' || name === 'INDIA VIX') out[name === 'NIFTY 50' ? 'NIFTY' : 'VIX'] = { ltp: num(r.last), open: num(r.open), high: num(r.high), low: num(r.low), prev: num(r.previousClose) };
  }
  return out;
}

// One stock's live quote (for stocks outside the 750 list, e.g. pennies on your watchlist).
export async function quoteEquity(symbol) {
  const d = await nseApi('quote-equity?symbol=' + encodeURIComponent(symbol));
  const p = (d && d.priceInfo) || {};
  const hl = p.intraDayHighLow || {};
  const ltp = num(p.lastPrice);
  return {
    ltp, open: num(p.open), high: num(hl.max), low: num(hl.min), prev: num(p.previousClose),
    name: d && d.info && d.info.companyName, sector: d && d.industryInfo && (d.industryInfo.industry || d.industryInfo.sector),
    pe: num(d && d.metadata && d.metadata.pdSymbolPe), sector_pe: num(d && d.metadata && d.metadata.pdSectorPe),
    mcap_cr: d && d.securityInfo && ltp ? Math.round((num(d.securityInfo.issuedSize) * ltp) / 1e7) : null,
  };
}

// SENSEX live from BSE.
export async function sensexLive() {
  const r = await http('https://api.bseindia.com/RealTimeBseIndiaAPI/api/GetSensexData/w', { headers: BSE_H });
  const rows = Array.isArray(r.data) ? r.data : (r.data && (r.data.Table || r.data.data)) || [];
  const s = rows.find(x => /SENSEX/i.test(x.indxnm || x.IndexName || '')) || rows[0];
  if (!s) throw new Error('No SENSEX data');
  const ltp = num(s.ltp ?? s.CurrValue), chg = num(s.chg ?? s.Chg);
  return { ltp, prev: ltp !== null && chg !== null ? ltp - chg : null, open: num(s.open ?? s.Open), high: num(s.high ?? s.High), low: num(s.low ?? s.Low) };
}

export const gentle = () => sleep(350);
