// Network calls. On the phone they go through Capacitor's native HTTP (no browser CORS limits, so
// NSE, BSE and broker APIs can be called directly from the app). In a desktop browser it falls back to fetch.
const native = () => (globalThis.Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform() && Capacitor.Plugins && Capacitor.Plugins.CapacitorHttp) || null;

export const UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/537.36';

export class HttpError extends Error {
  constructor(status, msg, data) { super(msg || `HTTP ${status}`); this.status = status; this.data = data; }
}

function b64ToBytes(b64) {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

// opts: {method, headers, params, body (object -> JSON), type: 'json'|'text'|'bytes', timeout}
export async function http(url, opts = {}) {
  const method = opts.method || 'GET';
  const type = opts.type || 'json';
  const headers = { ...(opts.headers || {}) };
  if (opts.params) {
    const qs = new URLSearchParams(Object.entries(opts.params).filter(([, v]) => v !== undefined && v !== null)).toString();
    if (qs) url += (url.includes('?') ? '&' : '?') + qs;
  }
  let body = opts.body;
  if (body !== undefined && typeof body !== 'string') { body = JSON.stringify(body); headers['Content-Type'] = headers['Content-Type'] || 'application/json'; }
  const N = native();
  if (N) {
    const res = await N.request({
      url, method, headers, data: body === undefined ? undefined : opts.body,
      responseType: type === 'bytes' ? 'arraybuffer' : type === 'json' ? 'json' : 'text',
      connectTimeout: opts.timeout || 20000, readTimeout: opts.timeout || 30000,
    });
    let data = res.data;
    if (type === 'bytes' && typeof data === 'string') data = b64ToBytes(data);
    if (type === 'json' && typeof data === 'string') { try { data = JSON.parse(data); } catch { /* keep text */ } }
    if (res.status >= 400) throw new HttpError(res.status, errText(res.status, data), data);
    return { status: res.status, data, headers: lower(res.headers || {}) };
  }
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), opts.timeout || 30000);
  try {
    const res = await fetch(url, { method, headers, body, signal: ctl.signal, credentials: 'include' });
    let data;
    if (type === 'bytes') data = new Uint8Array(await res.arrayBuffer());
    else if (type === 'json') { const t = await res.text(); try { data = JSON.parse(t); } catch { data = t; } }
    else data = await res.text();
    const h = {}; res.headers.forEach((v, k) => { h[k] = v; });
    if (!res.ok) throw new HttpError(res.status, errText(res.status, data), data);
    return { status: res.status, data, headers: h };
  } finally { clearTimeout(timer); }
}

function lower(h) { const o = {}; for (const [k, v] of Object.entries(h)) o[k.toLowerCase()] = v; return o; }
function errText(status, data) {
  const m = data && typeof data === 'object' ? (data.message || data.error || (data.meta && data.meta.displayMessage)) : '';
  return `HTTP ${status}${m ? ' · ' + m : ''}`;
}

export const sleep = ms => new Promise(r => setTimeout(r, ms));
export const isNative = () => !!native();
