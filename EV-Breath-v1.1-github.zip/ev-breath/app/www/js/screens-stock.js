// Stock Check, Buzz Alert view and Watchlist. Watch-only: nothing here places orders.
import { api, cfg, reloadEngine, watch } from './api.js';
import { band, bar, cls, demoRibbon, dnaTiles, esc, icon, inr, sgn, signalBadge, spark, toast, verdictBadge, watchOnlyNote } from './ui.js';

const RECENT_KEY = 'evb.recent';
const recent = () => { try { return JSON.parse(localStorage.getItem(RECENT_KEY) || '[]'); } catch { return []; } };
const remember = s => { try { localStorage.setItem(RECENT_KEY, JSON.stringify([s, ...recent().filter(x => x !== s)].slice(0, 6))); } catch { /* ignore */ } };

const PARTS = [['trend', 'Trend', 25], ['rs', 'Rel. strength', 20], ['participation', 'Participation', 20], ['oi', 'OI confirm', 15], ['entry', 'Entry setup', 20]];
const VWHY = { 'Calm Buy Zone': 'Trend, money and news agree', 'Wait for the Breath': 'Good stock · let the entry come', 'Not yet': 'Rules not lined up', 'Avoid': 'Blocked by a safety gate' };

function watchBtn(sym, on) {
  return `<button class="btn ${on ? '' : 'ghost'}" data-watch="${esc(sym)}" style="display:flex;align-items:center;justify-content:center;gap:8px">${icon('star', 18, on)}${on ? 'Watching' : 'Watch'}</button>`;
}
function mountWatch(root) {
  root.querySelectorAll('[data-watch]').forEach(b => b.onclick = async () => {
    const sym = b.dataset.watch;
    const on = await watch.toggle(sym);
    b.outerHTML = watchBtn(sym, on);
    mountWatch(root);
    toast(on ? `<b>${esc(sym)}</b> added to your watchlist. You get an alert when its news lands.` : `<b>${esc(sym)}</b> removed from your watchlist`, 3500);
  });
}

export async function check(params) {
  const sym = (params[0] || '').toUpperCase();
  let r = null, err = null;
  if (sym) {
    try { r = await api(`/api/check/${encodeURIComponent(sym)}`); remember(sym); } catch (e) { err = e; }
  }
  const watching = r ? await watch.has(r.symbol) : false;
  const rec = recent().length ? recent() : (cfg.demo ? ['CORALPH', 'AARAVSTL', 'SAGARCEM', 'RAVIPOLY'] : ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY']);
  return {
    tab: 'home',
    html: `${demoRibbon()}${band('Stock Check', 'Enter any NSE stock · full EV Breath report')}
    <div class="page">
      <form class="row" id="chk"><label class="search grow">${icon('scan', 18)}<input id="sym" value="${esc(sym)}" placeholder="Symbol, e.g. RELIANCE" autocapitalize="characters" autocomplete="off" style="text-transform:uppercase"></label><button class="btn">Check</button></form>
      <div id="sugg"></div>
      <div class="chips"><span class="small muted" style="align-self:center">Recent</span>${rec.map(s => `<a class="chip" href="#/check/${esc(s)}" style="display:inline-flex;align-items:center">${esc(s)}</a>`).join('')}</div>
      ${err ? `<div class="warn">${esc(err.message)}</div>` : ''}
      ${r ? report(r, watching) : (sym ? '' : '<div class="empty">Type a symbol and tap Check</div>')}
    </div>`,
    mount(root) {
      const inp = root.querySelector('#sym');
      root.querySelector('#chk').onsubmit = e => { e.preventDefault(); const v = inp.value.trim().toUpperCase(); if (v) location.hash = `#/check/${encodeURIComponent(v)}`; };
      let t;
      inp.oninput = () => {
        clearTimeout(t);
        t = setTimeout(async () => {
          const q = inp.value.trim();
          const box = root.querySelector('#sugg');
          if (q.length < 2) { box.innerHTML = ''; return; }
          const s = await api('/api/search?q=' + encodeURIComponent(q));
          box.innerHTML = s.rows.length ? `<div class="card list" style="gap:0;padding:4px 14px">${s.rows.map(x => `<a class="between" href="#/check/${esc(x.symbol)}" style="padding:10px 0;color:var(--text)"><span class="col"><b class="small">${esc(x.symbol)}</b><span class="xs muted">${esc(x.name)}</span></span><span class="small">₹${inr(x.price)}</span></a>`).join('')}</div>` : '';
        }, 250);
      };
      mountWatch(root);
    },
  };
}

function report(r, watching) {
  const b = r.breath;
  const ring = b.score >= 75 ? 'var(--green)' : b.score >= 60 ? 'var(--gold)' : 'var(--muted)';
  const checks = [
    ['Delivery vs 20-day avg', r.delivery_x ? r.delivery_x + '×' : '—', (r.delivery_x || 0) >= 1.2 ? 'up' : ''],
    ['OI (latest session)', b.oi_signal || 'Cash only', ['LB', 'SC'].includes(b.oi_signal) ? 'up' : b.oi_signal === 'SB' ? 'dn' : ''],
    ['ASM / GSM list', r.asm ? 'LISTED' : 'NOT LISTED', r.asm ? 'dn' : 'up'],
    ['Promoter pledge', r.has_fundamentals || cfg.demo ? (r.pledge_pct ?? 0) + '%' : '— (import fundamentals)', (r.pledge_pct ?? 0) > 20 ? 'dn' : r.has_fundamentals || cfg.demo ? 'up' : 'muted'],
    ['Next results', r.results_in_days == null ? '—' : `in ${r.results_in_days} days`, r.gates.entry_blocked ? 'orange' : ''],
    ['Data', `${r.bar_date}${r.provisional ? ' · live today' : ' · daily close'}`, r.provisional ? 'up' : 'muted'],
  ];
  return `
  <div class="card">
    <div class="between" style="align-items:flex-start"><div class="col"><span class="b" style="font-size:20px">${esc(r.symbol)}</span><span class="small muted">${esc(r.name !== r.symbol ? r.name + ' · ' : '')}${esc(r.sector)}${r.mcap_cr ? ' · MCAP ₹' + inr(r.mcap_cr, 0) + 'cr' : ''} · ${r.fno ? 'F&amp;O' : 'Cash only'}</span></div>
      <div class="col" style="align-items:flex-end"><span class="b" style="font-size:18px" data-ltp="${esc(r.symbol)}">₹${inr(r.price)}</span><span class="small ${cls(r.chg_pct)}">${sgn(r.chg_pct)}%</span></div></div>
    <div style="display:flex;justify-content:center">${spark(r.spark, 300, 54)}</div>
    <div class="between inner" style="background:${{ 'Calm Buy Zone': 'var(--green)', 'Wait for the Breath': 'var(--gold)', 'Avoid': 'var(--red)' }[r.verdict] || 'var(--muted)'};color:#1A1020"><b>${esc(r.verdict.toUpperCase())}</b><span class="small">${esc(r.gates.pass ? VWHY[r.verdict] : r.gates.fails[0])}</span></div>
  </div>
  <div class="card row" style="flex-direction:row;align-items:center;gap:14px">
    <div class="ring" style="border-color:${ring}"><b>${b.score}</b><span>BREATH</span></div>
    <div class="col grow" style="gap:6px">${PARTS.map(([k, l, max]) => `<div style="display:grid;grid-template-columns:92px 1fr 40px;gap:6px;align-items:center" class="xs"><span class="muted">${l}</span>${bar(b.parts[k] == null ? 0 : b.parts[k] / max * 100)}<span style="text-align:right">${b.parts[k] == null ? '—' : b.parts[k]}/${max}</span></div>`).join('')}
    <span class="xs muted">${esc(b.setup.note)}</span></div>
  </div>
  <div class="grid2">
    <div class="card" style="gap:8px"><span class="xs gold sb">MULTIBAGGER DNA</span>${dnaTiles(r.dna.tests)}<span class="small">${r.dna.passed}/6 pass${r.dna.stage ? ' · ' + r.dna.stage : ''}</span></div>
    <div class="card" style="gap:8px"><span class="xs orange sb">BLAST FUSE</span>${bar(r.fuse.score, 'orange')}<span class="small orange">${r.fuse.score}% · ${esc(r.fuse.status)}</span></div>
  </div>
  ${r.penny ? `<div class="card"><span class="xs muted sb">BUZZ VS SUBSTANCE</span><div style="display:grid;grid-template-columns:74px 1fr 34px;gap:8px;align-items:center" class="xs"><span class="orange">BUZZ</span>${bar(r.penny.buzz, 'orange')}<span>${r.penny.buzz}</span><span class="blue">SUBSTANCE</span>${bar(r.penny.substance, 'blue')}<span>${r.penny.substance}</span></div>${verdictBadge(r.penny.verdict)}</div>` : ''}
  <div class="card list" style="gap:0">${checks.map(([k, v, c]) => `<div class="between" style="padding:9px 0"><span class="dim small">${k}</span><span class="small ${c}">${esc(v)}</span></div>`).join('')}</div>
  ${planCard(r)}
  ${r.filings.length ? `<div class="card"><span class="xs muted sb">LATEST FILINGS</span>${r.filings.map(x => `<div class="row small" style="align-items:flex-start"><span class="muted" style="white-space:nowrap">${esc(x.date ? x.date.slice(5) + ' ' : '')}${esc(x.time || '')}</span><span>${esc(x.subject)}</span></div>`).join('')}</div>` : ''}
  <div class="grid2">${watchBtn(r.symbol, watching)}<a class="btn ghost" href="#/alert/${esc(r.symbol)}" style="display:flex;align-items:center;justify-content:center">News &amp; alert</a></div>
  ${watchOnlyNote()}
  <div class="xs muted" style="text-align:center">A screen, not a recommendation.</div>`;
}

function planCard(r) {
  return `<div class="card hl"><span class="xs gold sb">PLAN BEFORE YOU BUY · FOR YOUR BROKER APP</span><div class="grid3">
    <div class="col"><span class="xs muted">Entry zone</span><b>₹${inr(r.plan.entry)}</b></div><div class="col"><span class="xs muted">Stop-loss</span><b class="dn">₹${inr(r.plan.stop)}</b></div><div class="col"><span class="xs muted">Qty (rules)</span><b>${r.plan.qty}</b></div></div>
    <span class="xs muted">Risk ₹${inr(r.plan.risk_rupees, 0)} (${r.plan.risk_pct_of_capital}% of capital) · value ₹${inr(r.plan.value, 0)}. Set the capital in Settings › Rules.</span></div>`;
}

export async function alert(params) {
  const sym = (params[0] || '').toUpperCase();
  const d = await api(`/api/alert/${encodeURIComponent(sym)}`);
  const a = d.alert, r = d.row;
  const watching = await watch.has(r.symbol);
  return {
    tab: 'news',
    html: `${demoRibbon()}${band(a ? '<span class="dn">●</span> Buzz Alert' : esc(r.symbol), a ? esc(a.time || '') + ' · ' + esc(a.kind) : 'News &amp; rules')}
    <div class="page">
      ${a ? `<div class="card"><div class="between"><span class="row"><span class="tag" style="border-color:var(--green);color:var(--green)">${esc(a.kind.toUpperCase())}</span><span class="tag">${a.material ? 'MATERIAL' : 'NOT MATERIAL'}</span></span>${signalBadge(a.signal)}</div>
        <div class="b" style="font-size:16px;line-height:1.35">${esc(a.subject)}</div><div class="small muted">${esc(a.reason)}</div></div>` : '<div class="card small muted">No new filing today for this stock.</div>'}
      <div class="card">
        <div class="between"><span><b style="font-size:16px">${esc(r.symbol)}</b> <span data-ltp="${esc(r.symbol)}">₹${inr(r.price)}</span> <span class="${cls(r.chg_pct)}">${sgn(r.chg_pct)}%</span></span>${verdictBadge(r.penny ? r.penny.verdict : r.verdict)}</div>
        ${r.penny ? `<div style="display:grid;grid-template-columns:74px 1fr 34px;gap:8px;align-items:center" class="xs"><span class="orange">BUZZ</span>${bar(r.penny.buzz, 'orange')}<span>${r.penny.buzz}</span><span class="blue">SUBSTANCE</span>${bar(r.penny.substance, 'blue')}<span>${r.penny.substance}</span></div>` : ''}
        <div class="chips">${(r.penny ? r.penny.flags : [r.verdict, `BREATH ${r.breath.score}`, `FUSE ${r.fuse.score}`]).map(x => `<span class="tag">${esc(x)}</span>`).join('')}${r.gates.fails.map(x => `<span class="tag" style="border-color:var(--red);color:var(--red)">${esc(x)}</span>`).join('')}</div>
        <a class="small" href="#/check/${esc(r.symbol)}">Full Stock Check →</a>
      </div>
      ${r.filings.length ? `<div class="card"><span class="xs muted sb">FILINGS</span>${r.filings.map(x => `<div class="col small" style="gap:2px"><span class="xs muted">${esc(x.date || '')} ${esc(x.time || '')} · ${esc(x.kind)}</span><span>${esc(x.subject)}</span>${x.url ? `<a class="xs" href="#" data-open="${esc(x.url)}">Open filing (PDF) →</a>` : ''}</div>`).join('')}</div>` : ''}
      ${planCard(r)}
      <div class="grid2">${watchBtn(r.symbol, watching)}<button class="btn ghost" data-back>Close</button></div>
      ${watchOnlyNote()}
    </div>`,
    mount(root) {
      mountWatch(root);
      root.querySelectorAll('[data-open]').forEach(x => x.onclick = e => { e.preventDefault(); openExternal(x.dataset.open); });
    },
  };
}

export function openExternal(url) {
  const B = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Browser;
  if (B) B.open({ url }); else window.open(url, '_blank');
}

export async function watchlist() {
  const list = await watch.list();
  const d = list.length ? await api('/api/watchlist?symbols=' + encodeURIComponent(list.join(','))) : { rows: [] };
  return {
    tab: 'home',
    html: `${demoRibbon()}${band('Watchlist', `${list.length} stock${list.length === 1 ? '' : 's'} · live prices · alerts on news`)}
    <div class="page">
      <form class="row" id="add"><label class="search grow">${icon('star', 18)}<input id="addsym" placeholder="Add a stock, e.g. TATAMOTORS" autocapitalize="characters" autocomplete="off" style="text-transform:uppercase"></label><button class="btn">Add</button></form>
      <div id="sugg"></div>
      <div class="list">${d.rows.map(r => r.missing ? `<div class="item"><div class="between"><b>${esc(r.symbol)}</b><button class="btn sm ghost" data-del="${esc(r.symbol)}">Remove</button></div><span class="xs muted">${cfg.demo ? 'Not in the demo market' : 'Not in your NSE data yet (sync in Market data)'}</span></div>` : `
        <div class="item">
          <a class="between" href="#/check/${esc(r.symbol)}" style="color:var(--text)"><span class="col"><b>${esc(r.symbol)}</b><span class="xs muted">${esc(r.name)}</span></span>${spark(r.spark, 80, 26)}<span class="col" style="align-items:flex-end"><span class="b" data-ltp="${esc(r.symbol)}">₹${inr(r.price)}</span><span class="small ${cls(r.chg_pct)}">${sgn(r.chg_pct)}%</span></span></a>
          <div class="between"><span class="row wrap">${verdictBadge(r.is_penny && r.penny ? r.penny.verdict : r.verdict)}<span class="tag">BREATH ${r.score}</span><span class="tag">FUSE ${r.fuse}</span><span class="tag">DNA ${r.dna}/6</span></span><button class="back" data-del="${esc(r.symbol)}" aria-label="Remove ${esc(r.symbol)}" style="margin:0">${icon('x', 18)}</button></div>
          ${r.alert ? `<a class="inner small" href="#/alert/${esc(r.symbol)}" style="color:var(--text)"><span class="dn">●</span> ${esc(r.alert.subject)}</a>` : `<span class="xs muted">${esc(r.setup)}</span>`}
        </div>`).join('') || '<div class="empty">Your watchlist is empty. Add stocks here or tap ★ Watch on any Stock Check.</div>'}</div>
      ${watchOnlyNote()}
    </div>`,
    mount(root, rerender) {
      const inp = root.querySelector('#addsym');
      root.querySelector('#add').onsubmit = async e => {
        e.preventDefault();
        const v = inp.value.trim().toUpperCase();
        if (!v) return;
        if (!(await watch.has(v))) await watch.toggle(v);
        if (!cfg.demo) await reloadEngine();
        rerender();
      };
      let t;
      inp.oninput = () => {
        clearTimeout(t);
        t = setTimeout(async () => {
          const q = inp.value.trim();
          const box = root.querySelector('#sugg');
          if (q.length < 2) { box.innerHTML = ''; return; }
          const s = await api('/api/search?q=' + encodeURIComponent(q));
          box.innerHTML = s.rows.length ? `<div class="chips">${s.rows.map(x => `<button class="chip" data-pick="${esc(x.symbol)}">${esc(x.symbol)}</button>`).join('')}</div>` : '';
          box.querySelectorAll('[data-pick]').forEach(b => b.onclick = async () => { if (!(await watch.has(b.dataset.pick))) await watch.toggle(b.dataset.pick); rerender(); });
        }, 250);
      };
      root.querySelectorAll('[data-del]').forEach(b => b.onclick = async e => { e.preventDefault(); await watch.toggle(b.dataset.del); rerender(); });
    },
  };
}
