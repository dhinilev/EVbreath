# EV Breath · Trade Calm. (v1.1, watch-only)

Equity stock app by **Erulenkattil Veettil Group**. Sister app of EV Pulse (options).

**Watch-only.** EV Breath scans, scores, watches and alerts. It never places, changes or cancels an order.
Place any order yourself in your broker's app.

Everything runs on the phone. No server is needed.

- **Screens:** Home, Scanner, Multibagger Radar, Blast Watch, News, Penny Buzz, Buzz Alert, Stock Check,
  Watchlist, Settings, API Hub, Market Data, Rules (sliders + backtest), About.
- **Rule engine:** Breath Score, Multibagger DNA, Blast Fuse, Penny Buzz vs Substance, Buzz Alerts, plan card.
  It runs in a background worker on the phone.
- **Data:**
  - NSE daily files: price, delivery %, F&O OI, NIFTY, India VIX. About a year is kept on the phone.
  - NSE live prices for about 750 stocks.
  - BSE SENSEX.
  - NSE announcements (filings) for Buzz Alerts.
  - ASM, F&O ban and FII/DII flows.
- **Brokers (live prices only):** HDFC Sky Open API and Sharekhan API.

## Build the APK (GitHub)

1. In the repo, **delete the old zip** (EV-Breath-v1.0-github.zip).
2. Upload **EV-Breath-v1.1-github.zip**. Keep `.github/workflows/main.yml`.
3. Open **Actions › Build EV Breath APK**. When it is green, download **Artifacts › EV-Breath-APK**.
4. Install the APK over the old app.

## First use

1. **Settings › Market data › Live NSE / BSE**.
2. **Market data › Download history.** About 300 small NSE files; a few minutes on Wi-Fi. Keep the app open.
3. After that, the day's files are added automatically after 6:30 PM IST while the app is open.

## Connect HDFC Sky (prices only)

1. Go to developer.hdfcsky.com › My Apps › + Create.
2. Set the Redirect URL to `https://localhost/callback.html`.
3. Fill the Static IP fields. SEBI requires them for orders; this app sends no orders. If the form insists, enter
   your current IP.
4. Activate the app, then copy the API key and secret.
5. In EV Breath, go to **Settings › Broker › HDFC Sky**. Enter your Client ID, API key and secret, then tap
   **Save & log in**.
6. Log in again each day: broker sessions last one day.

If the login page does not come back to the app, use **Login page did not come back?**: log in in the browser
and paste the final address.

## Connect Sharekhan (prices only)

Use the same Redirect URL. Enter your Customer ID, API key and secret key (32 characters), then tap **Save & log in**.

## Fundamentals for Multibagger DNA

NSE files have no sales, ROCE, debt or promoter data. Import a CSV in **Market data › Fundamentals** with these
columns: symbol, name, sector, mcap_cr, promoter_pct, promoter_change_4q, pledge_pct, sales_cagr3, profit_cagr3,
sales_yoy_q1, sales_yoy_q2, roce, roce3y, de, icr, pe, sector_pe, ttm_sales_cr, results_in_days

## Notes

- NSE and BSE change their public addresses from time to time. If a feed shows DOWN in Market data, the app
  keeps the last good data.
- Exchange and broker data are for your own use.
- EV Breath is an information tool, not investment advice.
